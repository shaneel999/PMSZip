import { RouteInfo } from './sidebar.metadata';

export const ROUTES: RouteInfo[] = [
  //patient menu start
  {
    path: '',
    title: 'Patient Profile',
    moduleName: 'patient',
    icon: 'menu-icon ti-home',
    class: 'menu-toggle',
    groupTitle: false,
    role: 'Patient',
    submenu: [
      {
        path: '/dashboard/patient',
        title: 'Patient Dashboard',
        moduleName: 'patient',
        icon: '',
        class: 'ml-menu',
        groupTitle: false,
        role: 'Patient',
        submenu: []
      },
      {
        path: '/patient/patientdetails',
        title: 'Patient Details',
        moduleName: 'patient',
        icon: '',
        class: 'ml-menu',
        groupTitle: false,
        role: 'Patient',
        submenu: []
      }, 
      {
        path: '/patient/bookappointment',
        title: 'Book Appointment',
        moduleName: 'patient',
        icon: '',
        class: 'ml-menu',
        groupTitle: false,
        role: 'Patient',
        submenu: []
      },
      // {
      //   path: '/patient/patientvisit',
      //   title: 'Patient Visit',
      //   moduleName: 'patient',
      //   icon: '',
      //   class: 'ml-menu',
      //   groupTitle: false,
      //   role: 'Patient',
      //   submenu: []
      // }
    ]
  },
  //patient menu end
  //Admin Menu start
  {
    path: '',
    title: 'Admin',
    moduleName: 'admin',
    icon: 'menu-icon ti-face-smile',
    class: 'menu-toggle',
    groupTitle: false,
    role: 'Admin',
    submenu: [
      {
        path: '/dashboard/main',
        title: 'Dashboard',
        moduleName: 'admin',
        icon: '',
        class: 'ml-menu',
        groupTitle: false,
        role: 'Admin',
        submenu: []
      },
      {
        path: '/dashboard/CreateStaff',
        title: 'Create Hospital User',
        moduleName: 'admin',
        icon: '',
        class: 'ml-menu',
        groupTitle: false,
        role: 'Admin',
        submenu: []
      }
    ]
  },
  //Admin Menu End
  //Physician Menu Start
  {
    path: '',
    title: 'Physician',
    moduleName: 'appointment',
    icon: 'menu-icon ti-face-smile',
    class: 'menu-toggle',
    groupTitle: false,
    role: 'Physician',
    submenu: [
      {
        path: '/dashboard/physician',
        title: 'Physician Dashboard',
        moduleName: 'admin',
        icon: '',
        class: 'ml-menu',
        groupTitle: false,
        role: 'Physician',
        submenu: []
      },
      {
      path: '/inbox/appointments',
      title: 'Appointment Calender',
      moduleName: 'appointment',
      icon: '',
      class: 'ml-menu',
      groupTitle: false,
      role: 'Physician',
      submenu: []
    },
    // {
    //   path: '/patient/profile/:id',
    //   title: 'Patient Profile Summary',
    //   moduleName: 'patient',
    //   icon: '',
    //   class: 'ml-menu',
    //   groupTitle: false,
    //   role: 'Physician',
    //   submenu: []
    // }
   ]
  },
  //Physician Menu End
  //Nurse Menu Start
  {
    path: '',
    title: 'Nurse',
    moduleName: 'appointment',
    icon: 'menu-icon ti-face-smile',
    class: 'menu-toggle',
    groupTitle: false,
    role: 'Nurse',
    submenu: [
      {
        path: '/dashboard/nurse',
        title: 'Nurse Dashboard',
        moduleName: 'admin',
        icon: '',
        class: 'ml-menu',
        groupTitle: false,
        role: 'Nurse',
        submenu: []
      },
      {
      path: '/inbox/appointments',
      title: 'Appointment Calender',
      moduleName: 'appointment',
      icon: '',
      class: 'ml-menu',
      groupTitle: false,
      role: 'Nurse',
      submenu: []
    },
    // {
    //   path: '/patient/profile/:id',
    //   title: 'Patient Profile Summary',
    //   moduleName: 'patient',
    //   icon: '',
    //   class: 'ml-menu',
    //   groupTitle: false,
    //   role: 'Nurse',
    //   submenu: []
    // }
   ]
  },
  //Nurse Menu End
  // {
  //   path: '',
  //   title: 'Profile Settings',
  //   moduleName: 'profile',
  //   icon: 'menu-icon ti-home',
  //   class: 'menu-toggle',
  //   groupTitle: false,
  //   role: '',
  //   submenu: [
  //     {
  //       path: '/patient/patientdetails',
  //       title: 'Patient Details',
  //       moduleName: 'profile',
  //       icon: '',
  //       class: 'ml-menu',
  //       groupTitle: false,
  //       role: '',
  //       submenu: []
  //     }, 
  //     {
  //       path: '/patient/bookappointment',
  //       title: 'Book Appointment',
  //       moduleName: 'patient',
  //       icon: '',
  //       class: 'ml-menu',
  //       groupTitle: false,
  //       role: '',
  //       submenu: []
  //     },
  //     {
  //       path: '/patient/patientvisit',
  //       title: 'Patient Visit',
  //       moduleName: 'patient',
  //       icon: '',
  //       class: 'ml-menu',
  //       groupTitle: false,
  //       role: '',
  //       submenu: []
  //     }
  //   ]
  // },
  //  {
  //   path: '',
  //   title: 'Admin',
  //   moduleName: 'admin',
  //   icon: 'menu-icon ti-face-smile',
  //   class: 'menu-toggle',
  //   groupTitle: false,
  //   role: 'Admin',
  //   submenu: [
  //     {
  //       path: '/dashboard/main',
  //       title: 'Dashboard',
  //       moduleName: 'admin',
  //       icon: '',
  //       class: 'ml-menu',
  //       groupTitle: false,
  //       role: '',
  //       submenu: []
  //     },
  //     {
  //       path: '/dashboard/nurse',
  //       title: 'Nurse Dashboard',
  //       moduleName: 'admin',
  //       icon: '',
  //       class: 'ml-menu',
  //       groupTitle: false,
  //       role: '',
  //       submenu: []
  //     },
  //     {
  //       path: '/dashboard/physician',
  //       title: 'Physician Dashboard',
  //       moduleName: 'admin',
  //       icon: '',
  //       class: 'ml-menu',
  //       groupTitle: false,
  //       role: '',
  //       submenu: []
  //     },
  //     {
  //       path: '/dashboard/CreateStaff',
  //       title: 'Create Staff User',
  //       moduleName: 'admin',
  //       icon: '',
  //       class: 'ml-menu',
  //       groupTitle: false,
  //       role: '',
  //       submenu: []
  //     }
  //   ]
  // },
  //  {
  //   path: '',
  //   title: 'View Appointment',
  //   moduleName: 'appointment',
  //   icon: 'menu-icon ti-face-smile',
  //   class: 'menu-toggle',
  //   groupTitle: false,
  //   role: '',
  //   submenu: [
  //     {
  //     path: '/inbox/appointments',
  //     title: 'Appointment Calender',
  //     moduleName: 'appointment',
  //     icon: '',
  //     class: 'ml-menu',
  //     groupTitle: false,
  //     role: '',
  //     submenu: []
  //   },
  //   {
  //     path: '/patient/profile',
  //     title: 'Patient Profile Summary',
  //     moduleName: 'patient',
  //     icon: '',
  //     class: 'ml-menu',
  //     groupTitle: false,
  //     role: '',
  //     submenu: []
  //   }
  //  ]
  // }
];