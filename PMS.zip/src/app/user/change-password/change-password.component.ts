import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../core/service/auth.service';
import { ConfirmedValidator } from '../../authentication/confirmed.validator';
import { Users } from '../../core/models/Users';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.sass']
})
export class ChangePasswordComponent implements OnInit {

  changePasswordForm: FormGroup;
  submitted = false;
  error = '';
  hide = true;
  user: Users[];
  existingUser: Users;
  public usersObservable: Observable<Users[]>;
  public userObservable: Observable<Users>;
  public userList: Users[] = null;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private toaster: ToastrService
  ) { }
  ngOnInit() {
    this.changePasswordForm = this.formBuilder.group({
      opassword: ['', Validators.required],
      password: [
        '',
        [Validators.required, Validators.minLength(5)]
      ],
      confirmpassword: ['', Validators.required]
    }, {
      validator: ConfirmedValidator('password', 'confirmpassword')
    });
  }
  get f() {
    return this.changePasswordForm.controls;
  }

  onSubmit() {
    this.submitted = true;
     console.log(this.authService.currentUserValue.password);
    // console.log(this.f.opassword.value);
    if (this.f.opassword.value != this.authService.currentUserValue.password) {
      this.toaster.error("old password doesn't match with the records", "Error");
      return;
    }

    if (this.changePasswordForm.invalid) {
      //this.error = 'Username and Password not valid !';
      return;
    } else {
      // console.log("Id" + this.authService.currentUserValue.id);
      // this.user = new User[1];

      this.existingUser = new Users();

      // this.existingUser.id = this.authService.currentUserValue.id;
      // this.existingUser.title = this.authService.currentUserValue.title;
      // this.existingUser.firstName = this.authService.currentUserValue.firstName;
      // this.existingUser.lastName = this.authService.currentUserValue.lastName;
      // this.existingUser.dob = this.authService.currentUserValue.dob;
      // this.existingUser.contactnumber = this.authService.currentUserValue.contactnumber;
      this.existingUser.email = this.authService.currentUserValue.email;
      this.existingUser.password = this.f.password.value;
      this.existingUser.userPassword = this.f.password.value;
      // this.existingUser.token = "";
      // this.existingUser.status = this.authService.currentUserValue.status;

      this.userObservable = this.authService.UpdatePassword(this.existingUser)
      this.userObservable.subscribe(
        (user: Users) => {
          // this.existingUser = user;
          console.log(user.email);
          if (user.email != null) {
            console.log("Inside changepassword success");
            this.authService.logout();
            this.toaster.success("Password Changed Successfully. Please login again!!", "Success");
            this.router.navigate(['./authentication/signin']);
          }
          else {
            this.toaster.error('Invalid Credentials', "Error");
          }
        },
        (error) => {
          this.error = error;
          this.submitted = false;
        }
      );
    }
  }
}