import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { AppointmentService } from 'src/app/core/service/appointment.service';

@Component({
  selector: 'app-delete-dialog',
  templateUrl: './delete-dialog.component.html',
  styleUrls: ['./delete-dialog.component.sass']
})
export class DeleteDialogComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<DeleteDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private appointmentService:AppointmentService,  private toastr:ToastrService
      ) {}

  ngOnInit(): void {
  }

  onNoClick(): void {
    this.dialogRef.close('no');
  }
  confirmDelete(): void {
    this.dialogRef.close('yes'); 
  }
  

}
