export class patientprocedure {
    procedureId:number;
    procedureCode:string;
    procedureDescription:string;
    procedureIsDepricated:boolean;
    visitDetails:[]
}