export class Relationship {
    relationshipId :number;
    relationshipName:string;
    isActive:Boolean;
}