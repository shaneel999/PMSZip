export class NotificationDetails
{
    notificationId:number; 
    description:string;
    userId:number; 
    isSeen:boolean 
    createdDate:string;
    modifiedDate:string;
    userName:string; 
}