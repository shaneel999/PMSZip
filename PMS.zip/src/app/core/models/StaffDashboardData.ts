export class StaffDashboardData{
    staffId:number; 
    staffName:string;
    contactNumber:string; 
    totalAppointments:number; 
    pendingAppointments:number; 
    scheduledAppointments:number;
    rejectedAppointments:number; 
}