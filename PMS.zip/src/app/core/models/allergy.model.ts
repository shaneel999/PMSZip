export class Allergy {
    allergyType :number;
    allergyIsFatal:boolean;
    allergyDescription:string;
    allergyName:string;
    allergyClinicalInformation:string;
}