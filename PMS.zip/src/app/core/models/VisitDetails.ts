export class VisitDetails {
    visitId: number;
    patientId: number;
    staffId: number;
    visitTitle: string;
    visitDate: Date;
    visitTime: string;
    visitStatus: string;
    reason: string;
    isPatientScheduled: Boolean;
    isNurseScheduled: Boolean;
    createdBy: number;
    isActive: Boolean;
    visitDescription: string;
    createdDate: Date;
    physicianName: string;
    patientName: string;
}