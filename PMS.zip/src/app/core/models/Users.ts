export class Users{
    patientId:number;
    staffId:number;
    title:string;
    firstName:string;
    lastName:string;
    dob:string;
    contactNumber:string;
    email:string;
    password: string;
    token:string;
    status: string;
    role:string;
    userPassword: string;
    errorMessage: string;
    loginFailedAttempts: number;
}

