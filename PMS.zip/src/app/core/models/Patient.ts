export class Patient
{
    Title:string;
    id:number;
    FirstName:string;
    LastName:string;
    Dob:Date;
    Age:number;
    Gender:number;
    ContactNumber:string;
    Email:string;
    RaceId:number;
    EthnicityId:number;
    LanguagesKnown:string;    
    HomeAddress:string;
    token:string;
}