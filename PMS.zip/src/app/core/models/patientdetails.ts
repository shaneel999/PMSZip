export class patientdetails
{
    FirstName:string;
    LastName:string;
    Email:string;
    ContactNumber:number;
    RelationshipId:number;
    Address:string;
    token:string;
}