export class PieChartData
{
    pendingAppointments:number;
    confirmedAppointments:number;
    rejectedAppointments:number; 
}