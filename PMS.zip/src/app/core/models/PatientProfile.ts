export class PatientProfile
{
    title:string;
    id:number;
    firstName:string;
    lastName:string;
    dob:Date;
    age:number;
    gender:number;
    contactNumber:string;
    email:string;
    languagesKnown:string;    
    homeAddress:string;
}