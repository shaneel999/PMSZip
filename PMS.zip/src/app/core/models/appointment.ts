import { date } from "ngx-custom-validators/src/app/date/validator";

export class Appointment {
   /* appointmentTitle: string;
    appointmentPhysician :number;
    appointmentDate: Date;
    appointmentTime: string;
    appointmentDetails:string;
    appointmentReason:string;
    appointmentStatus:string;
    action:string;
    id:number;*/

    visitId: number;
    patientId: number;
    staffId: number;
    visitTitle: string;
    visitDate: Date;
    visitTime: string;
    visitStatus: string;
    reason: string;
    isPatientScheduled: Boolean;
    isNurseScheduled: Boolean;
    createdBy: number;
    isActive: Boolean;
    visitDescription: string;
    createdDate: Date;
    action:string;
}