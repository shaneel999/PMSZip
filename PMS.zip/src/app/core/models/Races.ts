export class Races {
    raceId :number;
    name:string;
    isActive:Boolean;
}