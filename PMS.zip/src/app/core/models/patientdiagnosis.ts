export class patientdiagnosis {
    dignosisId:Number;
    diagnosisCode :string;
    diagnosisIsDepricated:boolean;
    diagnosisDescription:string;
    visitDetails:[]
}