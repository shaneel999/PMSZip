export class patientdashboard{
    patientId:number;
    patientName:string;
    patientAddress:string;
    contactNumber:string;
    height:number;
    weight:number;
    bloodPressure:number;
    totalVisits:number;
    upcomingAppointment:string;
    visitHistory: string[];
    patientEmergencyContactName:string;
    relationName:string;
    patientEmergencyContactAddress:string;
    patientEmergencyContactNumber:string;
}