export class Ethnicity {
    ethinicityId :number;
    name:string;
    isActive:Boolean;
}