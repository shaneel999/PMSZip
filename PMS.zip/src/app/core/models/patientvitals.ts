export class patientvitals
{
Height:number;
Weight:number;
BloodPressure:number;
BodyTemerpature:number;
RespirationRate:number;
}