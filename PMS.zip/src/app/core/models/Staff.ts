export class Staff
{
    staffId:number;
    employeeId:string;
    firstName:string;
    lastName:string;
    contactNumber:string;
    email:string;
    password:string;
    roleId:number;
    dateOfBirth:Date;
    dateOfJoining:Date;
    employeeCode:string;
    status: string;
    title: string;
}