import { formatDate } from '@angular/common';
export class Calendar {
  id: number;
  title: string;
  start: Date;
  end: Date;
  className: string;
  groupId: string;
  details: string;
  backgroundColor:string;

  constructor(calendar) {
    {
      console.log('calendar');
      console.log(calendar);
      this.id = calendar.id || '' ;
      this.title = calendar.appointmentTitle || '';
      this.start = new Date(), 'yyyy-MM-dd', 'en' || '';
      this.end =  new Date(), 'yyyy-MM-dd', 'en' || '';
      this.className = calendar.className || '';
      this.groupId = calendar.groupId || '';
      this.details = calendar.appointmentDetails || '';
      this.backgroundColor = calendar.backgroundColor || '';
      console.log("testing cal the values" + calendar.appointmentTitle);
    }
  }
}


/*

import { formatDate } from '@angular/common';
export class Calendar {
  id: number;
  appointmentTitle: string;
  appointmentPhysician: string;
  appointmentDate: string;
  appointmentTime: string;
  appointmentDetails: string;
  appointmentReason: string;

  constructor(calendar) {
    {
      this.id = calendar.id;
      this.appointmentTitle = calendar.title || '';
      this.appointmentPhysician = calendar.appointmentPhysician || 0;
      this.appointmentDate = formatDate(new Date(), 'yyyy-MM-dd', 'en') || '';
      this.appointmentTime = calendar.appointmentTime || '';
      this.appointmentDetails = calendar.appointmentDetails || '';
      this.appointmentReason = calendar.appointmentReason || '';
    }
  }
}*/