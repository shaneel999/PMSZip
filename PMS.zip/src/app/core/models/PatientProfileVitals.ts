
export class PatientProfileVitals
{
   height:number;
   weight:number;
   bloodPressure:number;
   bodyTemerpature:number;
   respirationRate:number;
}