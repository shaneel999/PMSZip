export const SignInLocale = {
    siteName : "Natural Health Clinic",
    siteCaption : "Empowering People to Improve Their Lives",
  
    //Sign In Component
    signinHeader : "Already a registered user.",
    signinTokenError : "Error in web service, make sure service server is up and running",
    signinInvalidCredentials : "Email or Password is incorrrect",
    signinUsernameLabel : "Username/Email",
    signinUsernamePlaceholder : "Please Enter Username/Email",
    signinEmailRequired : "Email is required",
    signinEmialValid : "Email must be a valid email address",
    signinEmailMinLength : "Length of email should be atlest 5",
    signinEmailMaxLength : "Length of email address should not exceed 20 chars",
    signinPasswordLabel : "Password",
    signinPasswordPlaceholder : "Enter Password",
    signinPasswordRequired : "Password is required",
    signinRememberMe : "Remember me",
    signinForgetPassword : "Forgot Password?",
    signinLogin : "Login",
    signinRegisterLink : "New to CT General Hospital? ",
    signinRegister : "Register",
    signinBlockedUser: "User is blocked/inactive, Contact Admin!"
}