export enum Language {
    English=1,
    Spanish=2,
    Chinese=3,
    French=4,
    German=5,
    Arabic=6
}