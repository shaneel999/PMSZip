export enum Status {
    Active = 1,
    DeActivate = 2,
    Block = 3,
    Activate = 4,
    InActive = 5,
    Blocked = 6
}