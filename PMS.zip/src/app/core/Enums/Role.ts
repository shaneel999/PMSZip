export enum Role{
    Patient = 1,
    Physician = 2,
    Nurse = 3,
    Admin = 4
}