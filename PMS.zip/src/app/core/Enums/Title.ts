export enum Title{
    Mr = 1,
    Mrs = 2
}