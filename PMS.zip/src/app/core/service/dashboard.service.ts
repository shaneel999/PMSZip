import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { StaffDashboardData } from '../models/StaffDashboardData';
import { environment } from '../../../environments/environment';
import { patientdashboard } from '../models/patientdashboard';
import { NotificationDetails } from '../models/NotificationDetails';
import { Users } from '../../core/models/Users';
import { PieChartData } from '../models/PieChartData';
import { BarChartData } from '../models/BarChartData';


@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private http: HttpClient) { }

  getPatientDashboardData(patientId: number) {
    return this.http.get<patientdashboard>(`${environment.apiTokenUrl}/api/dashboard/GetPatientDashboardDetails?patientId=` + patientId);
  }

  getNurseDashboardData(nurseId: number) {
    return this.http.get<StaffDashboardData>(`${environment.apiTokenUrl}/api/dashboard/GetNurseDashboardDetails?nurseId=` + nurseId);
  }

  public GetUsers(): Observable<Users[]> {
    return this.http.get<Users[]>(`${environment.apiAdminUrl}/api/admin`);
  }

  getPhysicianDashboardData(physicianId: number) {
    return this.http.get<StaffDashboardData>(`${environment.apiTokenUrl}/api/dashboard/GetPhysicianDashboardDetails?physicianId=` + physicianId);
  }

  fetchNotifications(userId: number) {
    return this.http.get<NotificationDetails[]>('https://localhost:44339/api/Appointment/GetAllNotifications?userId=' + userId);
  }

  MarkNotificationSeen(notificationId: number) {
    return this.http.get<any>('https://localhost:44339/api/Appointment/MarkNotificationAsSeen?notificationId=' + notificationId);
  }

  getPieChartData()
  {
     return this.http.get<PieChartData>(`${environment.apiAdminUrl}/api/Admin/GetPieChartData`);
  }
  
  getBarChartData()
  {
    return this.http.get<BarChartData>(`${environment.apiAdminUrl}/api/Admin/GetBarChartData`);
  }
}
