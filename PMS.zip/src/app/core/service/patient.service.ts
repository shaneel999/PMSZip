import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Allergy } from '../../core/models/allergy.model';
import { BehaviorSubject, Observable, of } from 'rxjs';
import {patientvitals} from '../../core/models/patientvitals';
import {patientdiagnosis} from '../../core/models/patientdiagnosis';
import {patientprocedure} from '../../core/models/patientprocedure';
import {Races} from '../../core/models/Races';
import {Ethnicity} from '../../core/models/Ethnicity';
import {Relationship} from '../../core/models/Relationship';
import { environment } from '../../../environments/environment';
import { VisitDetails } from '../../core/models/VisitDetails';
@Injectable({
  providedIn: 'root'
})
export class PatientService {

  constructor(private http:HttpClient) { }

  //   public AddappointmentDetails(appointmentDetails:Appointment){
  //   return this.http.post<Allergy>('http://localhost:3000/AppointmentDetails',appointmentDetails);
  // }
  public AddallergyDetails(allergyDetails:Allergy){
    return this.http.post<Allergy>(`${environment.apiTokenUrl}/api/PatientDetails/PatientAllergy`,allergyDetails);
  }

  public GetappointmentDetails(): Observable<VisitDetails[]>{
    return this.http.get<VisitDetails[]>(`${environment.patientappointmentURL}/api/Appointment/GetAllPatientAppointments`);
  }
//GetAllAppointmentsForPhysicianDashboard
public GetAppointmentDetailsByPhysician(physicianId: number): Observable<VisitDetails[]>{
  return this.http.get<VisitDetails[]>(`${environment.patientappointmentURL}/api/Appointment/GetAllAppointmentsForPhysicianDashboard?physicianId=` + physicianId);
}


  public GetallergyDetails(): Observable<Allergy[]>{
    return this.http.get<Allergy[]>(`${environment.apiTokenUrl}/api/PatientDetails/GetAllPatientAllergy`);
  }
  public GetraceDetails(): Observable<Races[]>{
    return this.http.get<Races[]>(`${environment.apiTokenUrl}/api/PatientDetails/GetAllRaceDetails`);
  }
  
  public GetethnicityDetails(): Observable<Ethnicity[]>{
    return this.http.get<Ethnicity[]>(`${environment.apiTokenUrl}/api/PatientDetails/GetAllEthinicityDetails`);
  }
  public GetrelationshipDetails(): Observable<Relationship[]>{
    return this.http.get<Relationship[]>(`${environment.apiTokenUrl}/api/PatientDetails/GetAllRelationshipDetails`);
  }
  public AddpatientVitals(patientvitals:patientvitals){
    return this.http.post<patientvitals>(`${environment.apiTokenUrl}/api/PatientDetails`,patientvitals);
  }
  public AddpatientDiagnosis(patientdiagnosis:patientdiagnosis){
    return this.http.post<patientdiagnosis>(`${environment.apiTokenUrl}/api/PatientDetails/PatientDiagnosis`,patientdiagnosis);
  }
  // http://localhost:44375/api/PatientDetails/GetAllPatientDiagnosis
  
  public GetDiagnosis(){
    return this.http.get<patientdiagnosis[]>(`${environment.apiTokenUrl}/api/PatientDetails/GetAllPatientDiagnosis`);
  }
  
  public AddpatientProcedure(patientprocedure:patientprocedure){
    return this.http.post<patientdiagnosis>(`${environment.apiTokenUrl}/api/PatientDetails/PatientProcedure`,patientprocedure);
  }
  
  public GetProcedure(){
    return this.http.get<patientprocedure[]>(`${environment.apiTokenUrl}/api/PatientDetails/GetAllPatientProcedure`);
  }

  public DeleteDiagnosis(id: number){  
    return this.http.delete(`${environment.apiTokenUrl}/api/PatientDetails/`+id);  
  } 
  public DeleteProcedure(id: number){  
    return this.http.delete(`${environment.apiTokenUrl}/api/PatientDetails/RemoveProcedureById/`+id);  
  } 
}
