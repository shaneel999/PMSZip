import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Users } from '../../core/models/Users';
import { Observable } from 'rxjs';
import { Patient } from '../../core/models/Patient';
import { patientdetails } from '../../core/models/patientdetails';
import { environment } from '../../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class RegisterService {


  constructor(private httpsvc: HttpClient) { }

  createUser(patientInfo) {
    console.log(patientInfo);
    return this.httpsvc.post<Users[]>(`${environment.apiTokenUrl}/api/patient`, patientInfo, {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    })
  }
  GetUser(email: string): Observable<Users[]> {
    return this.httpsvc.get<Users[]>(`${environment.apiUrl}/users?email=` + email);
  }
  PatientDetails(Patient) {
    return this.httpsvc.post<Patient[]>(`${environment.apiTokenUrl}/api/PatientDetails/PatientDetails`, Patient);
  }
  PatientEmergencyDetails(PatientDetail) {
    return this.httpsvc.post<patientdetails[]>(`${environment.apiTokenUrl}/api/PatientDetails/PatientEmergencyDetails`, PatientDetail);
  }
}
