import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Staff} from '../../core/models/Staff';
import { environment } from '../../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class StaffService {

  constructor(private http:HttpClient) { }
  public AddStaffUser(staffDetails:Staff){
    return this.http.post<Staff>(`${environment.apiAdminUrl}/api/Admin`,staffDetails);
  }
}
