import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { Users } from '../../core/models/Users';
import { Staff } from '../../core/models/Staff';
import { environment } from '../../../environments/environment';
import { Patient } from '../models/Patient';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject: BehaviorSubject<Users>;
  public currentUser: Observable<Users>;
  public loggedInUser: Users[];
  public logedUser : Users;

  constructor(private http: HttpClient) {
    this.currentUserSubject = new BehaviorSubject<Users>(
      JSON.parse(localStorage.getItem('currentUser'))
    );
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): Users {
    return this.currentUserSubject.value;
  }

  public GenerateJwtToken(email: string, password: string, role: string): Observable<Users> {
    const login: any = { email, password, role };

    const credentials = JSON.stringify(login);
    // console.log("cred" + credentials);
    return this.http.post<Users>(`${environment.apiTokenUrl}/api/Login`, credentials, {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    }).pipe(
      map((result) => {
        this.logedUser = result;
        // if (this.loggedInUser?.length > 0) {
        //   console.log(this.loggedInUser[0]);
          console.log(JSON.stringify(this.logedUser));
          localStorage.setItem('currentUser', JSON.stringify(this.logedUser));
          this.currentUserSubject.next(this.logedUser);
          // this.loggedInUser[0].token = "qwertyuioplkjnmbhgvfcdxsza";
        // }
        return this.logedUser;
      })
    );
  }


  public GetUserByUsername(username: string, password: string): Observable<Users[]> {
    // console.log('http://localhost:3000/Users?email=' + username + '&password=' + password);
    return this.http.get<Users[]>(`${environment.apiUrl}/Users?email=` + username + '&password=' + password)
      .pipe(
        map((result) => {
          this.loggedInUser = result;
          if (this.loggedInUser?.length > 0) {
            // console.log(this.loggedInUser[0]);
            // console.log(JSON.stringify(this.loggedInUser[0]));
            localStorage.setItem('currentUser', JSON.stringify(this.loggedInUser[0]));
            this.currentUserSubject.next(this.loggedInUser[0]);
            // this.loggedInUser[0].token = "qwertyuioplkjnmbhgvfcdxsza";
          }
          return this.loggedInUser;
        })
      );
  }
  public GetUserDetails(email: string): Observable<Users> {
    return this.http.get<Users>(`${environment.apiTokenUrl}/api/PatientDetails/` +email);
  }

  public GetUsers(): Observable<Users[]> {
    return this.http.get<Users[]>(`${environment.apiAdminUrl}/api/admin`);
  }

  public GetStaffUsers(): Observable<Staff[]> {
    return this.http.get<Staff[]>(`${environment.apiAdminUrl}/api/admin/Staff`);
  }

  public UpdatePassword(user: Users): Observable<Users> {
    // console.log(user.id); //{headers : new HttpHeaders({'Content-Type': 'application/json'})}
    return this.http.put<Users>(`${environment.apiTokenUrl}/api/patient`, user)
  }

  public UpdateStaff(staff: Staff): Observable<Staff> {
    // console.log(user.id); //{headers : new HttpHeaders({'Content-Type': 'application/json'})}
    return this.http.put<Staff>(`${environment.apiAdminUrl}/api/Admin`, staff)
  }

  public UpdateStatus(user: Users): Observable<Users> {
    // console.log(user.id); //{headers : new HttpHeaders({'Content-Type': 'application/json'})}
    // console.log(user.email + " fHGAFSD " + user.status);
    return this.http.patch<Users>(`${environment.apiAdminUrl}/api/admin`, user)
  }
  public UpdatestaffStatus(staff:Staff ): Observable<Staff> {
    // console.log(user.id); //{headers : new HttpHeaders({'Content-Type': 'application/json'})}
    // console.log(staff.Email + " fHGAFSD " + staff.status);
    return this.http.patch<Staff>(`${environment.apiAdminUrl}/api/admin/StaffStatus`, staff)
  }
  public CheckUserExistsByEmail(username: string): Observable<Users> {
    console.log(`${environment.apiTokenUrl}/api/Login?/email=` + username);
    return this.http.get<Users>(`${environment.apiTokenUrl}/api/Login?email=` + username)
      .pipe(
        map((result) => {
          this.logedUser = result;
          // console.log(this.loggedInUser?.length);
          // if (this.logedUser?.length > 0) {
            // console.log(JSON.stringify(this.loggedInUser[0].firstName));
            // localStorage.setItem('currentUser', JSON.stringify(this.loggedInUser[0]));
            // this.currentUserSubject.next(this.loggedInUser[0]);
          // }
          return this.logedUser;
        })
      );
  }

  login(username: string, password: string) {
    // console.log(password);
    return this.http
      .post<any>(`${environment.apiUrl}/authenticate`, {
        username,
        password
      })
      .pipe(
        map((user) => {
          // store user details and jwt token in local storage to keep user logged in between page refreshes
          localStorage.setItem('currentUser', JSON.stringify(user));
          this.currentUserSubject.next(user);
          return user;
        })
      );
  }

  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    localStorage.removeItem('access_token');
    // localStorage.removeItem("remember");
    this.currentUserSubject.next(null);
    return of({ success: false });
  }
}