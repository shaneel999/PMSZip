import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { Appointment } from '../../core/models/appointment';
import { VisitDetails } from '../../core/models/VisitDetails';
import { Calendar } from '../models/calendar.model';
import { Observable } from 'rxjs';
import { Patient } from '../models/Patient';
import { PatientProfileVitals } from '../models/PatientProfileVitals';
import { environment } from '../../../environments/environment';
import { Staff } from '../models/Staff';
import { AuthService } from '../service/auth.service';
import { PatientProfile } from '../models/PatientProfile';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {

  appointmentDetails:Appointment;
  userId:number;
  //visitData:VisitDetails;
  serverURL=(`${environment.appointmentURL}/api/Appointment`);

  dataChange: BehaviorSubject<Calendar[]> = new BehaviorSubject<Calendar[]>([]);
  appointmentStatus:string;
  patientProfileId:number;
   
  constructor(private http:HttpClient, private authService: AuthService) { }

  get data(): Calendar[] {
    return this.dataChange.value;
  }

  getDetails(appointment: Appointment): void {

    this.appointmentDetails = appointment;
    console.log(this.appointmentDetails);
    this.appointmentDetails.visitDate = appointment.visitDate;
    this.appointmentDetails.patientId= this.authService.currentUserValue.patientId;
    this.appointmentDetails.visitStatus = appointment.visitStatus == null ?'Pending':appointment.visitStatus;
    this.appointmentDetails.isPatientScheduled = true;
    this.appointmentDetails.isNurseScheduled = false;
    this.appointmentDetails.createdBy = 1;
    this.appointmentDetails.isActive = true;
    this.appointmentDetails.createdDate = new Date();  
    this.appointmentDetails.isActive = true;
  }
  
  getDialogData() {
    return this.appointmentDetails;
  }

  AddAppointmentDetails(visitData:Appointment){
    // this.visitData = this.mapModelData(appointmentData);
    return this.http.post<VisitDetails>(this.serverURL, visitData);
  }
  
  UpdateAppointmentDetails(visitData:Appointment, id:number){
    visitData.visitId=id;
    return this.http.put<Appointment>(this.serverURL, visitData);
  }

  /*    old method 
  GetAppointments(){
    return this.http.get<Appointment[]>(this.serverURL);
  }*/

  //new method
  GetAppointments(userId: number): Observable<VisitDetails[]>{
    // console.log('http://localhost:44339/api/Appointment?userId='+ userId);
    return this.http.get<VisitDetails[]>(this.serverURL + '?userId='+ userId);
  }

  GetAllAppointments(): Observable<VisitDetails[]>{
    // console.log('http://localhost:44339/api/Appointment?userId='+ userId);
    return this.http.get<VisitDetails[]>(this.serverURL);
  }

  GetAllPhysicians(): Observable<Staff[]>{
    return this.http.get<Staff[]>(this.serverURL + '/GetAllPhysicians');
  }

  GetCalenderAppointments(): Observable<Appointment[]>{
    return this.http.get<Appointment[]>(this.serverURL + '/GetNurseCalendar');
  }

  GetCalenderAppointmentsByPhysician(physicianId: number): Observable<Appointment[]>{
    return this.http.get<Appointment[]>(this.serverURL + '/GetPhysicianCalendar?physicianId='+ physicianId);
  }

  GetUserId(id:number)
  {
    return this.userId=id;
  }

  DeleteAppointment(id: number){  
    return this.http.delete<number>('https://localhost:44339/api/Appointment?appointmentId=' +id);  
  } 

/*
  getAppointmentDataByDate(appointmentDate:Date)
  {
    return this.http.get<Appointment[]>(this.serverURL).pipe(filter(x=>x.ApointmentDate==appointmentDate));
  }
*/

 ModifyAppoitmentStatus(data:Appointment)
 {
   return this.http.put<Appointment>('https://localhost:44339/api/Appointment/ModifyAppointmentStatus/', data);
 }

//  getPatientDemographicInformationById(id:number)
//  {
//   return this.http.get<Patient>('http://localhost:3000/PatientDetails/1');
//  }

//  getPatientHealthInformationById(id:number)
//  {
//   return this.http.get<patientvitals>('http://localhost:3000/PatientVitals/1');
//  }

  getNurseDashboardData(){
    return this.http.get<VisitDetails[]>(this.serverURL +'/GetAllAppointmentsForNurseDashboard');
  }

  getPhysicianDashboardData(physicianId:number){
    return this.http.get<VisitDetails[]>(this.serverURL + '/GetAllAppointmentsForPhysicianDashboard/?physicianId='+ physicianId);
  }

  getPatientDataById(patientId:number)
  {
    return this.http.get<PatientProfile>(this.serverURL + '/GetPatientDetailsByID/?patientId='+ patientId);
  }

  getHealthInformationById(patientId:number)
  {
    return this.http.get<PatientProfileVitals>(this.serverURL + '/GetPatientHealthInformationByID/?patientId='+ patientId);
  }

}
