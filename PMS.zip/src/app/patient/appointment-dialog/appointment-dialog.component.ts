import { Component, DoCheck, ElementRef, HostListener, Inject, OnChanges, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AppointmentService } from '../../core/service/appointment.service';
import { Appointment } from '../../core/models/appointment';
import { ToastrService } from 'ngx-toastr';
import AppointmentPicker from 'appointment-picker';
import { VisitDetails } from 'src/app/core/models/VisitDetails';
import { NumberLiteralType } from 'typescript';
import { Staff } from 'src/app/core/models/Staff';
import { Router } from '@angular/router';
import { AuthService } from '../../core/service/auth.service';

@Component({
  selector: 'app-appointment-dialog',
  templateUrl: './appointment-dialog.component.html',
  styleUrls: ['./appointment.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppointmentDialogComponent implements OnInit,DoCheck {


  appointmentModalForm: FormGroup;
  appointmentData: Appointment;
  appointmentList: Appointment[];
  visitList: VisitDetails[];
  minDate = new Date();
  filledSlots: string[] = [];
  PhysicianList: Staff[];
  ModalTitle: string;
  IsReasonControlVisible: boolean;
  @ViewChild('pickerInput', { static: true }) input: ElementRef;
  picker: AppointmentPicker;
  todayDate = new Date();
  BookedAppointments = []
  IsPhysican: Boolean;
  panelOpenState = false;
  IsTimeControlEnable:Boolean=false;
  time:String;
  PhysicianValue:number
  isDateChanged:boolean;
  patientId:number;

  public myFilter = (d: Date): boolean => {
    if (d != null) {
      const day = d.getDay();
      return day !== 0;
    }
  }

  addEvent(event) {
    console.log('asdasf')
    this.filledSlots = [];
    // this.picker.close();
    this.GetAppointmentsByDate(event.target.value);
    this.isDateChanged = true;
    // this.appointmentModalForm.controls['visitTime'].setValue('');
  }

  constructor(private authService: AuthService, private formBuilder: FormBuilder, private router: Router, public dialogRef: MatDialogRef<AppointmentDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Appointment, private appointmentService: AppointmentService, private toastr: ToastrService) {
      this.minDate.setDate(this.minDate.getDate() + 1); // adds one day in date to disable today date
      if (data.action == 'Add') {
      this.appointmentData = new Appointment();
      this.ModalTitle = 'Book';
      this.IsReasonControlVisible = true;
    }
    else if (data.action == 'Update') {
      this.ModalTitle = 'Update';
      this.appointmentData = data;
      this.IsReasonControlVisible = false;
      this.IsTimeControlEnable=false;
      this.GetAppointmentsByDate(data.visitDate);
      this.appointmentService.GetUserId(data.visitId);
      this.patientId=Number(data.patientId);
      console.log(data);
      let date = new Date(this.appointmentData.visitDate);
      this.PhysicianValue=this.appointmentData.staffId;
      if (this.todayDate > date) {
        this.toastr.error("Appointment date overlapped please select valid date", "Error");
      }
    }
    this.IsPhysican = localStorage.getItem("role") == "Physician" ? true : false;
  }


  @HostListener('change.appo.picker', ['$event'])
  onChangeTime(event: any) {
  // console.log('change.appo.picker', event.time);
   this.time= event.time;
  }

  GetAppointmentsByDate(AppointmentDate: Date) {
    //this.appointmentService.GetAppointments().pipe(filter((x:Appointment[])=>);
   // this.appointmentModalForm.controls['appointmentTime'].reset;
    this.appointmentService.GetAppointments(this.authService.currentUserValue.patientId).subscribe((data: VisitDetails[]) => {
      // console.log("Actual " +new Date(AppointmentDate).toLocaleString("en-US") + "Format " + (new Date(AppointmentDate).getDate() + 1));
      //const dateForFilter = AppointmentDate;
      //const selectedDate  = dateForFilter.setDate(AppointmentDate.getDate() + 1);
      // console.log(AppointmentDate.toUTCString());
      //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
      // console.log( 'input date' + new Date(AppointmentDate).valueOf() +'  '+ new Date(appointment[1].appointmentDate).valueOf());
      // console.log(new Date(AppointmentDate).getTime() === new Date(appointment[1].appointmentDate).getTime());
      //this.appointmentList = appointment.filter( x=> console.log('Output Date ' + new Date(x.appointmentDate).toLocaleDateString()));
      this.visitList = data.filter(x => new Date(x.visitDate).toLocaleString("en-US") == new Date(AppointmentDate).toLocaleString("en-US"));

      //  console.log("Count " + this.appointmentList.length);
      // let timeSlots: string = "";
      for (var i = 0; i < this.visitList.length; i++) {
        if (this.visitList[i].visitTime !== null) {
          // timeSlots = timeSlots + ", " + this.appointmentList[i].appointmentTime.toString();
          const index = this.filledSlots.findIndex(role => role === this.visitList[i].visitTime.toString());
          if (index == -1) {
            this.filledSlots.push(this.visitList[i].visitTime.toString());
          }
        }
      }
      // console.log("Time " + timeSlots.slice(1) + "hagsf " + this.filledSlots);
      // this.picker.destroy();
      // this.picker.close();
      this.setTimePicker();
    },
      (error) => { console.log("Error In Appointment List"); });

    //  console.log(this.appointmentList);
    //this.BookedAppointments=;
    // console.log(this.appointmentList.filter(x=>console.log((new Date(x.appointmentDate).toDateString()))));
    //(x=> (new Date(x.appointmentDate)) == (new Date(AppointmentDate)));
    //this.BookedAppointments=this.appointmentList.map(x=>(new Date(x.appointmentDate)) == (new Date(AppointmentDate)));
    //(x=>(new Date(x.appointmentDate)) == (new Date(AppointmentDate))).appointmentTime.toString();
    //  console.log(this.BookedAppointments);
  }

  GetAllPhysiciansList()
  {
    this.appointmentService.GetAllPhysicians().subscribe((data:Staff[])=>{
      this.PhysicianList=data;
    })
  }
  ngOnInit() {
    console.log(this.appointmentData);
    this.appointmentModalForm = this.formBuilder.group({
      visitTitle: [this.appointmentData.visitTitle, [Validators.required, Validators.maxLength(50)]],
      staffId: [this.appointmentData.staffId, Validators.required],
      visitDate: [this.appointmentData.visitDate, Validators.required],
      visitTime: [this.appointmentData.visitTime],
      visitDescription: [this.appointmentData.visitDescription, [Validators.required, Validators.maxLength(30)]],
      visitStatus: [this.appointmentData.visitStatus],
      reason: [this.appointmentData.reason, [Validators.required, Validators.maxLength(30)]]
    });

    this.GetAllPhysiciansList();
    if(this.data.action='Update')
    {
       this.appointmentModalForm.controls['staffId'].setValue(this.appointmentData.staffId, {onlySelf: true});
       //this.setTimePicker();
      // this.picker.setTime(this.appointmentData.visitTime);
      // console.log("jHFGjhgfa" + this.appointmentData.visitTime);
      // this.appointmentModalForm.controls['visitTime'].setValue(this.appointmentData.visitTime);
    }
  }

  ngDoCheck(){
    if(this.IsTimeControlEnable) {
      this.appointmentModalForm.controls['visitTime'].enable();
    }
    else{
      this.appointmentModalForm.controls['visitTime'].disable();
    }  
  }

  setTimePicker() {
    // let BookedAppointments = ['09:30', '14:00', '15:30'];
    console.log("booked " + this.filledSlots);    //['15:30', '14:00'];

    this.picker = new AppointmentPicker(this.input.nativeElement, {
      interval: 30,
      mode: '24h',
      minTime: '09',
      maxTime: '18',
      startTime: '09',
      endTime: '18',
      disabled: this.filledSlots,
      title: "Pick Your Time Slot",
      allowReset: true
      // templateInner: '<li class="appo-picker-list-item {{disabled}}"><input type="button" value="{{time}}" {{disabled}}></li>',
      // templateOuter: '<div class="your-wrapper"><span class="your-title">Custom Markup</span><ul class="appo-picker-list">{{innerHtml}}</ul></div>'
    });
    this.IsTimeControlEnable=true;   
    if(this.data.action=='Update')
    {
     this.picker.setTime(this.appointmentData.visitTime);
     this.appointmentModalForm.controls['visitTime'].setValue(this.appointmentData.visitTime);
    }
    if(this.isDateChanged){
      this.appointmentModalForm.controls['visitTime'].setValue('');
    }
    //this.appointmentModalForm.controls['visitTime'].setValue(' ');
  }

  closePicker() {
    this.picker.close();
  }

  SaveDetails(): void {
    if (this.data.action = 'Add') {
     //console.log(this.appointmentModalForm.getRawValue())
     //console.log(this.appointmentModalForm)
      this.time['m']  = this.time['m'] =='0'?'00':'30'
      this.appointmentModalForm.controls['visitTime'].setValue(this.time['h'] +':'+ this.time['m']);
      //console.log(this.appointmentModalForm);
      //console.log('VALUE' + this.appointmentModalForm.value.appointmentTime);
      this.appointmentService.getDetails(this.appointmentModalForm.getRawValue());
      // console.log("Before dialog close");
      this.dialogRef.close('submit');
      // console.log("after dialog close");
      this.router.navigate(['./patient/bookappointment']);
    }
  }


  PerformPhysicianOperations(action: string): void {
    if (this.appointmentModalForm.value.reason == "") {
      this.toastr.error("Please Enter Appointment Reason", "Error");
    }
    else {
      this.appointmentService.getDetails(this.appointmentModalForm.value);
      this.dialogRef.close(action);
    }
  }
}
