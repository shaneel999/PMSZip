import { AfterViewInit, ChangeDetectorRef, Component, DoCheck, OnChanges, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppointmentDialogComponent } from '../appointment-dialog/appointment-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { Appointment } from '../../core/models/appointment';
import { AppointmentService } from 'src/app/core/service/appointment.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material/table';
import AppointmentPicker from 'appointment-picker';
import { VisitDetails } from 'src/app/core/models/VisitDetails';
import { DeleteDialogComponent } from 'src/app/shared/delete-dialog/delete-dialog.component';
import { Staff } from '../../core/models/Staff';
import { AuthService } from '../../core/service/auth.service';
import Swal from 'sweetalert2';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.scss']
})
export class AppointmentComponent implements OnInit {

  PhysicianList: Staff[];
  appointmentDetails: Appointment;
  appointmentData: Appointment[] = null;
  visitData: VisitDetails[] = null;
  displayedColumns: string[] = ['Appointment Title', 'Physician Name', 'Appointment Date', 'Appointment Time', 'Appointment Status', 'Action'];
  dataSource: MatTableDataSource<VisitDetails>;
  physicianName: string = null;

  constructor(private authService: AuthService, private formBuilder: FormBuilder, private dialog: MatDialog, private appointmentService: AppointmentService,
    private toastr: ToastrService, private router: Router, private changeDetectorRefs: ChangeDetectorRef,private spinner: NgxSpinnerService) {
      this.spinner.show();
  }

  ngOnInit(): void {
    this.GetAllPhysiciansList();
    this.reloadData();
  }

  addNewAppointment() {
    const dialogRef = this.dialog.open(AppointmentDialogComponent, {
      width: '50%',
      data: {
        appointmentDetails: this.appointmentDetails,
        action: 'Add'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      let data: Appointment = this.appointmentService.getDialogData();
      if (data != undefined) {
        this.appointmentService.AddAppointmentDetails(this.appointmentService.getDialogData()).
          subscribe(() => {
            this.toastr.success("Appointment Added Sucessfully", "Success");
            this.router.navigate(['./patient/bookappointment']);
          });
      }
      this.reloadData();
    });
  }

  ngAfterViewInit(): void { 
    this.spinner.show();
     setTimeout(() => 
     {
      this.spinner.hide();
     }, 1500);
  }

  UpdateAppointment(mode: string, obj: Appointment) {
    obj.action = mode;
    console.log('obj' + obj)
    const dialogRef = this.dialog.open(AppointmentDialogComponent, {
      width: '50%',
      data: obj
    });


    dialogRef.afterClosed().subscribe(result => {
      let data: Appointment = this.appointmentService.getDialogData();
      if (data != undefined) {
        data.visitId = this.appointmentService.userId;
        if (data.reason != undefined) {
          this.appointmentService.UpdateAppointmentDetails(data, data.visitId).
            subscribe(() => {
              this.toastr.success("Appointment Updated Sucessfully", "Success");
              this.router.navigate(['./patient/bookappointment']);
            });
        }
        this.reloadData();
      }
    });
  }

    DeleteAppointment(mode:string,data:any){

      Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then(result => {
        if (result.value) {
          if(data.visitId!=undefined)
          {
           this.toastr.success("Appointment Deleted Sucessfully","Success");
              this.appointmentService.DeleteAppointment(data.visitId).
             subscribe(()=>
             {
               this.toastr.success("Appointment Deleted Sucessfully","Success");
               this.reloadData();
             });
          }
        }
      });


      // const dialogRef = this.dialog.open(DeleteDialogComponent, {
      //   width: '40%',
      //   data: data
      // });

      // dialogRef.afterClosed().subscribe(result => {
      //   if(result == 'yes')
      //   {
         
      //   }
      // });

   }

   GetAllPhysiciansList() {
    this.appointmentService.GetAllPhysicians().subscribe((data: Staff[]) => {
      this.PhysicianList = data;
      console.log(data)
    })
  }


  //   reloadData(){
  //     this.appointmentService.GetAppointments().subscribe((data:VisitDetails[])=>
  //       {
  //         console.log('reload')
  //          this.visitData = data;
  //          this.dataSource = new MatTableDataSource<VisitDetails>(this.visitData);
  //          this.changeDetectorRefs.detectChanges();
  //       },
  //      (error) => {
  //         console.log("Error In Appointment List");
  //       }
        
  //     );
  //   }
  // }

  reloadData() {
    console.log(this.authService.currentUserValue);
    this.appointmentService.GetAppointments(this.authService.currentUserValue.patientId)
      .subscribe((data: VisitDetails[]) => {
        // console.log('reload')
        this.visitData = data;
        // console.log(data);
        // console.log(this.PhysicianList);
        for (var i = 0; i < this.visitData.length; i++) {
          this.visitData[i].physicianName =
            (this.PhysicianList.find(e => e.staffId == this.visitData[i].staffId).firstName + " " +
              this.PhysicianList.find(e => e.staffId == this.visitData[i].staffId).lastName)
              // console.log("First" + this.visitData[i].staffId);
        }
        // console.log("First" + this.visitData[0].staffId);
        this.dataSource = new MatTableDataSource<VisitDetails>(this.visitData);
        this.changeDetectorRefs.detectChanges();
      },
        (error) => {
          console.log("Error In Appointment List");
        }

      );
  }

  /*  Old Method
      reloadData(){
    this.appointmentService.GetAppointments().subscribe((appointment:Appointment[])=>
      {
        console.log('reload')
         this.appointmentData =appointment;
         this.dataSource = new MatTableDataSource<Appointment>(this.appointmentData);
         this.changeDetectorRefs.detectChanges();
      },
     (error) => {
        console.log("Error In Appointment List");
      }
      
    );
  }

  */

  CheckAppointmentValidity(appointment) {
    let StartTime = appointment.visitTime.split(':');
    let year = new Date(appointment.visitDate).getFullYear();
    let month = new Date(appointment.visitDate).getMonth();
    let day = new Date(appointment.visitDate).getDate();
    let resultDate = new Date(year, month, day, Number(StartTime[0]), Number(StartTime[1]))
    let currentDate = new Date();
    if (resultDate < currentDate) {
      return true;
    }
    else {
      return false;
    }
  }

}
