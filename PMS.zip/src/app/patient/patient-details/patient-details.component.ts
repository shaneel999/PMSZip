import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { RegisterService } from '../../core/service/register.service';
import { PatientService } from '../../core/service/patient.service';
import { MatTableDataSource } from '@angular/material/table';
import { Allergy } from 'src/app/core/models/allergy.model';
import { Races } from 'src/app/core/models/Races';
import { Ethnicity } from 'src/app/core/models/Ethnicity';
import { AuthService } from 'src/app/core/service/auth.service';
import { from, Observable } from 'rxjs';
import { Users } from '../../core/models/Users';
import { PatientDetails } from '../../core/Common/Locales/PatientDetails';
import { Relationship } from '../../core/models/Relationship';
import { Title } from '../../core/Enums/Title';
import { Language } from '../../core/Enums/Language';
import { Patient } from '../../core/models/Patient';
import { date } from 'ngx-custom-validators/src/app/date/validator';

@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.component.html',
  styleUrls: ['./patient-details.component.sass']
})
export class PatientDetailsComponent implements OnInit {
  TitleList = Title;
  titleKeys = [];
  public birthdate: Date;
  public age: number;

  public CalculateAge(): void {
    if (this.birthdate) {
      var timeDiff = Math.abs(Date.now() - new Date(this.birthdate).getTime());
      this.age = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
    }
  }

  LanguageList = Language;
  languageKeys = [];
  PatientData: Patient[] = null;
  public usersObservable: Observable<Users[]>;
  AllergyDetails: Allergy;
  RaceData: Races[] = null;
  relationshipData: Relationship[] = null;
  EthinicityData: Ethnicity[] = null;
  AllergyData: Allergy[] = null;
  datasource: MatTableDataSource<Allergy>;
  displayedColumns: string[] = ['Allergy Type', 'Allergy Name', 'Allergy Is Fatal', "Allergy Description", 'Allergy Clinical Information'];
  Allergy: FormGroup;
  maxDate = new Date();
  patientdetails: FormGroup;
  patientemergencydetails: FormGroup;
  submitted = false;
  error = '';
  hide = true;
  chide = true;
  lang: string = '';
  user: Users[];
  patientDetails = PatientDetails;
  constructor(private formBuilder: FormBuilder, private registerservice: AuthService, private patientService: PatientService, private router: Router, private httpregister: RegisterService) {
    this.titleKeys = Object.keys(this.TitleList).filter(f => !isNaN(Number(f)));
    this.languageKeys = Object.keys(this.LanguageList).filter(f => !isNaN(Number(f)));
  }

  PatientDetails() {
    this.submitted = true;
    if (this.patientdetails.invalid) {
      return;

    } else {
      for (let i = 0; i < this.f.LanguagesKnown.value.length; i++) {
        this.lang = this.lang + ',' + this.f.LanguagesKnown.value[i];
      }
      this.patientdetails.value.LanguagesKnown = this.lang.substring(1);
      this.httpregister.PatientDetails(this.patientdetails.value).subscribe((response) => {
        this.router.navigate(['/authentication/signin']);
      })
    }
  }

  PatientEmergencyDetails() {
    this.submitted = true;
    if (this.patientemergencydetails.invalid) {
      return;

    } else {
      this.httpregister.PatientEmergencyDetails(this.patientemergencydetails.value).subscribe((response) => {
        this.router.navigate(['/authentication/signin']);
      })
    }
  }
  ngOnInit(): void {

    var userDetails = JSON.parse(localStorage.getItem('currentUser'));
    this.registerservice.GetUserDetails(userDetails.email).subscribe((x: Users) => {
      this.patientdetails.controls['FirstName'].setValue(x.firstName);
      this.patientdetails.controls['LastName'].setValue(x.lastName);
      this.patientdetails.controls['Dob'].setValue(x.dob);
      this.patientdetails.controls['ContactNumber'].setValue(x.contactNumber);
      this.patientdetails.controls['Email'].setValue(x.email);
      this.patientdetails.controls['Age'].setValue(this.age);
      this.birthdate = new Date(x.dob);
      this.CalculateAge();
    })



    this.patientService.GetallergyDetails().subscribe(
      (user: Allergy[]) => {

        this.AllergyData = user;
        this.datasource = new MatTableDataSource<Allergy>(this.AllergyData);
      },
      (error) => {
        console.log("Error In AllergyData");
      }
    );
    this.patientService.GetraceDetails().subscribe(
      (race: Races[]) => {
        this.RaceData = race;
      }
    );
    this.patientService.GetethnicityDetails().subscribe(
      (ethnicity: Ethnicity[]) => {
        this.EthinicityData = ethnicity;
      }
    );
    this.patientService.GetrelationshipDetails().subscribe(
      (relationship: Relationship[]) => {
        this.relationshipData = relationship;
      }
    );

    this.patientdetails = this.formBuilder.group({
      Title: ['', Validators.required],
      FirstName: ['', [Validators.required, Validators.pattern('[a-zA-Z]*')]],
      LastName: ['', [Validators.required, Validators.pattern('[a-zA-Z]*')]],
      ContactNumber: ['', [Validators.required, Validators.pattern("^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$")]],
      Email: ['', [Validators.required, Validators.email]],
      HomeAddress: ['', [Validators.required, Validators.maxLength(50)]],
      LanguagesKnown: ['', Validators.required],
      Gender: ['', Validators.required],
      Age: ['', [Validators.required]],
      Dob: ['', [Validators.required]],
      EthnicityId: ['', Validators.required],
      RaceId: ['', Validators.required],
    });
    this.patientemergencydetails = this.formBuilder.group({
      FirstName: ['', [Validators.required, Validators.pattern('[a-zA-Z]*')]],
      LastName: ['', [Validators.required, Validators.pattern('[a-zA-Z]*')]],
      ContactNumber: ['', [Validators.required, Validators.pattern("^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$")]],
      Email: ['', [Validators.required, Validators.email]],
      Address: ['', [Validators.required, Validators.maxLength(50)]],
      addressIsChecked: [false],
      RelationshipId: ['', Validators.required],
    });
    this.Allergy = this.formBuilder.group({
      allergyType: ['', Validators.required],
      allergyName: ['', Validators.required],
      allergyClinicalInformation: ['', Validators.required],
      allergyIsFatal: [false],
      allergyDescription: ['', [Validators.required, Validators.maxLength(50)]]
    });
  }
  get f() {
    return this.patientdetails.controls;
  }
  get Emergency() {
    return this.patientemergencydetails.controls;
  }
  get AllergyDetail() {
    return this.Allergy.controls;
  }

  handleChange(e) {
    var isChecked = this.Emergency.addressIsChecked;
    if (isChecked) {
      this.patientemergencydetails.controls['Address'].setValue(this.f.HomeAddress.value);
      console.log(this.f.HomeAddress.value);
    }
    else {
      console.log("addressclicked");
      return;
    }
  }

  AddAllergy() {
    if (this.Allergy.invalid) {
      return;
    }
    else {
      const allergyDetails = this.Allergy.value;
      this.patientService.AddallergyDetails(allergyDetails).subscribe(
        () => {
          console.log('Allergy Added')
        });
      this.Allergy.reset(this.Allergy.value);
    }
  }

}
