import { Component, OnInit } from '@angular/core';
import { PatientProfile } from 'src/app/core/models/PatientProfile';
import { patientdashboard } from 'src/app/core/models/patientdashboard';
import { PatientProfileVitals } from 'src/app/core/models/PatientProfileVitals';
import { AppointmentService } from 'src/app/core/service/appointment.service';
import { DashboardService } from 'src/app/core/service/dashboard.service';
import { ActivatedRoute } from '@angular/router';
import { visitAll } from '@angular/compiler/src/render3/r3_ast';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.sass']
})
export class ProfileComponent implements OnInit {

  patientPeronalInformation:PatientProfile;
  patientHealthInformation:PatientProfileVitals;
  patientdashboardData:patientdashboard;
  id:number;
  constructor(private appointmentService:AppointmentService,private dashboardService:DashboardService,private route: ActivatedRoute) { }
 

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = Number(params['patientId']);
    });
    if(this.id !=undefined)
    {
      this.getDemoGraphicDetails(this.id);
      this.getPatientHealthDetails(this.id);
      this.getPatientInformation(this.id);
    }
  }


  getPatientInformation(patientId:number)
  {
    this.dashboardService.getPatientDashboardData(patientId).subscribe((data:patientdashboard)=>{
      console.log(data);
      this.patientdashboardData=data;
   });
  }

  getDemoGraphicDetails(patientId:number)
  {
    this.appointmentService.getPatientDataById(patientId).subscribe((data:PatientProfile)=>{
      console.log('patient' + data)
       this.patientPeronalInformation=data;
    })
  }

  getPatientHealthDetails(patientId:number)
  {
    this.appointmentService.getHealthInformationById(patientId).subscribe((data:PatientProfileVitals)=>{
      console.log('Vitals' + data);
       this.patientHealthInformation=data;
    })
  }
}
