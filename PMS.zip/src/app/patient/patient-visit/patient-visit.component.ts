import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { PatientService } from '../../core/service/patient.service';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { FormControl } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';
import { MatTableDataSource } from '@angular/material/table';
import { patientdiagnosis } from '../../core/models/patientdiagnosis';
import { patientprocedure } from '../../core/models/patientprocedure';
import { PatientVisit } from '../../core/Common/Locales/PatientVisit';

// interface Diagnosis {
//   value: string;
//   viewValue: string;
// }
// interface Procedure {
//   value: string;
//   viewValue: string;
// }

@Component({
  selector: 'app-patient-visit',
  templateUrl: './patient-visit.component.html',
  styleUrls: ['./patient-visit.component.sass']
})
export class PatientVisitComponent implements OnInit {
  diagnosisDetails: patientdiagnosis;
  diagnosisData: patientdiagnosis[] = null;
  displayedColumns: string[] = ['Diagnosis Code', 'Diagnosis Is Depricated', 'Diagnosis Description', 'Action'];
  dataSource: MatTableDataSource<patientdiagnosis>;

  procedureDetails: patientprocedure;
  procedureData: patientprocedure[] = null;
  procedureColumns: string[] = ['Procedure Code', 'Procedure Is Depricated', 'Procedure Description', 'Action'];
  proceduredataSource: MatTableDataSource<patientprocedure>;

  patientvitals: FormGroup;
  patientdiagnosis: FormGroup;
  patientprocedure: FormGroup;

  // Procedure: Procedure[] = [
  //   { value: '0', viewValue: 'Bypass Cerebral Ventricle to Nasopharynx with Autologous Tissue Substitute, Open Approach' },
  //   { value: '1', viewValue: 'Bypass Cerebral Ventricle to Mastoid Sinus with Autologous Tissue Substitute, Open Approach' },
  //   { value: '2', viewValue: 'Bypass Cerebral Ventricle to Atrium with Autologous Tissue Substitute, Open Approach' },
  //   { value: '3', viewValue: 'Bypass Cerebral Ventricle to Blood Vessel with Autologous Tissue Substitute, Open Approach' },
  // ];
  patientVisit = PatientVisit;
  filteredDiagnosis: Observable<patientdiagnosis[]>;
  filteredProcedure: Observable<patientprocedure[]>;
  constructor(private formBuilder: FormBuilder, private patientService: PatientService, private router: Router, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.DiagnosisData();
    this.ProcedureData();

    this.patientvitals = this.formBuilder.group({
      Height: ['', [Validators.required]],
      Weight: ['', [Validators.required]],
      bloodPressure: ['', [Validators.required]],
      bodyTemperature: ['', [Validators.required]],
      respirationRate: ['', Validators.required]
    });

    this.patientdiagnosis = this.formBuilder.group({
      diagnosisCode: ['', Validators.required],
      diagnosisDescription: ['', Validators.required],
      diagnosisIsDepricated: ['', Validators.required],
    })

    this.patientprocedure = this.formBuilder.group({
      procedureCode: ['', Validators.required],
      procedureDescription: ['', Validators.required],
      procedureIsDepricated: ['', Validators.required],
    })
  }

  private _filter(value: string): patientdiagnosis[] {
    const filterValue = value.toLowerCase();
    return this.diagnosisData.filter(option => option.diagnosisDescription.toLowerCase().indexOf(filterValue) === 0);
  }

  private _normalizeValue(value: string): string {
    return value.toLowerCase().replace(/\s/g, '');
  }

  onDescriptionSelected(event) {
    let obj = this.diagnosisData.find(obj => obj.diagnosisDescription == event.option.value);
    this.patientdiagnosis.controls["diagnosisCode"].setValue(obj.diagnosisCode);
  }

  onKeyUpEvent(event) {
    console.log("input jashdg " + event.target.value);
    let obj = this.diagnosisData.find(obj => obj.diagnosisCode == event.target.value);
    this.patientdiagnosis.controls["diagnosisDescription"].setValue(obj?.diagnosisDescription);
  }

  //Procedure
  private _filters(value: string): patientprocedure[] {
    const filterValue = value.toLowerCase();
    return this.procedureData.filter(option => option.procedureDescription.toLowerCase().indexOf(filterValue) === 0);
  }
  private _normalizeValues(value: string): string {
    return value.toLowerCase().replace(/\s/g, '');
  }
  onProcedureSelected(event) {
    let obj = this.procedureData.find(obj => obj.procedureDescription == event.option.value);
    this.patientprocedure.controls["procedureCode"].setValue(obj.procedureCode);
  }

  onKeyUpEvents(event) {
    let obj = this.procedureData.find(obj => obj.procedureCode == event.target.value);
    this.patientprocedure.controls["procedureDescription"].setValue(obj?.procedureDescription);
  }

  get f() {
    return this.patientvitals.controls;
  }

  get diagnosis() {
    return this.patientdiagnosis.controls;
  }

  get procedure() {
    return this.patientprocedure.controls;
  }

  PatientVitals() {
    if (this.patientvitals.invalid) {
      this.toastr.error("Something went wrong", "Error");
      return;
    }
    else {
      console.log(this.patientvitals);
      const patientvitals = this.patientvitals.value;
      this.patientService.AddpatientVitals(patientvitals).subscribe(
        () => {
          this.toastr.success("Patient Vitals Added", "Success");
          console.log('Patient Vitals Added')
          // this.router.navigate(['./dashboard/main']);
        });
    }
  }

  AddDiagnosis() {
    if (this.patientdiagnosis.invalid) {
      this.toastr.error("Something went wrong", "Error");
      return;
    }
    else {
      console.log(this.patientdiagnosis);
      const patientdiagnosis = this.patientdiagnosis.value;
      this.patientService.AddpatientDiagnosis(patientdiagnosis).subscribe(
        () => {
          this.toastr.success("Patient Diagnosis Added", "Success");
          console.log('Patient Vitals Added')
          // this.router.navigate(['./dashboard/main']);
        });
    }
  }

  //GetProcedure()
  AddProcedure() {
    if (this.patientprocedure.invalid) {
      this.toastr.error("Something went wrong", "Error");

      return;
    }
    else {
      console.log(this.patientprocedure);
      const patientprocedure = this.patientprocedure.value;
      this.patientService.AddpatientProcedure(patientprocedure).subscribe(
        () => {
          this.toastr.success("Patient Procedure Added", "Success");
          // this.router.navigate(['./dashboard/main']);
        });
    }
  }

  DiagnosisData() {
    this.patientService.GetDiagnosis().subscribe(
      (diagnosis: patientdiagnosis[]) => {
        this.diagnosisData = diagnosis;
        console.log(this.diagnosisData);
        this.dataSource = new MatTableDataSource<patientdiagnosis>(this.diagnosisData);

        this.filteredDiagnosis = this.diagnosis.diagnosisDescription.valueChanges.pipe(
          startWith<string | patientdiagnosis>(''),
          map(value => typeof value === 'string' ? value : value?.diagnosisDescription),
          map(name => name ? this._filter(name) : this.diagnosisData.slice())
        );

      },
      (error) => {
        console.log("Error In Diagnosis List");
      }
    );
  }

  ProcedureData() {
    this.patientService.GetProcedure().subscribe(
      (procedure: patientprocedure[]) => {
        this.procedureData = procedure;
        this.proceduredataSource = new MatTableDataSource<patientprocedure>(this.procedureData);
        console.log(this.procedureData);

        this.filteredProcedure = this.procedure.procedureDescription.valueChanges.pipe(
          startWith<string | patientprocedure>(''),
          map(value => typeof value === 'string' ? value : value?.procedureDescription),
          map(name => name ? this._filters(name) : this.procedureData.slice())
        );

      },
      (error) => {
        console.log("Error In Procedure List");
      }
    );
  }

  DeleteDiagnosis(data: any) {
    if (data.diagnosisId > 0) {
      console.log(data.diagnosisId);
      this.patientService.DeleteDiagnosis(data.diagnosisId).subscribe(() => {
        console.log("diagnosis diagnosis")
        this.toastr.success("Diagnosis Deleted Sucessfully", "Success");
      });
    }
    else {
      console.log(data.diagnosisId);
    }
    this.DiagnosisData();
  }

  DeleteProcedure(data: any) {
    if (data.procedureId > 0) {
      console.log(data.id);
      this.patientService.DeleteProcedure(data.procedureId).subscribe(() => {
        console.log("diagnosis diagnosis")
        this.toastr.success("Procedure Deleted Sucessfully", "Success");
      });
    }
    this.ProcedureData();
  }
}
