import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PatientDetailsComponent } from '../patient/patient-details/patient-details.component';
import { AppointmentComponent} from '../patient/appointment/appointment.component';
import { PatientVisitComponent } from '../patient/patient-visit/patient-visit.component';
import { ProfileComponent } from './profile/profile.component';
const routes: Routes = [
    {
      path: '',
      redirectTo: 'patient',
      pathMatch: 'full'
    },
    {
      path: 'patientdetails',
      component: PatientDetailsComponent
    },
    {
      path: 'bookappointment',
      component: AppointmentComponent
    },
    {
      path: 'patientvisit',
      component: PatientVisitComponent
    },
    {
      path: 'profile/:patientId',
      component: ProfileComponent
    }
]
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
  export class PatientRoutingModule{}