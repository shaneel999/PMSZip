import { Component, ViewChild, OnInit, TemplateRef } from '@angular/core';
import { FullCalendarComponent } from '@fullcalendar/angular';
import { EventInput } from '@fullcalendar/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import listPlugin from '@fullcalendar/list';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { formatDate } from '@angular/common';
import { Calendar } from '../../core/models/calendar.model'
import { MatRadioChange } from '@angular/material/radio';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AppointmentService } from '../../core/service/appointment.service';
import { Appointment } from '../../core/models/appointment';
import { Router } from '@angular/router';
import { AppointmentDialogComponent } from 'src/app/patient/appointment-dialog/appointment-dialog.component';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from '../../core/service/auth.service';

const d = new Date();
const day = d.getDate();
const month = d.getMonth();
const year = d.getFullYear();

@Component({
  selector: 'app-appointment-calender',
  templateUrl: './appointment-calender.component.html',
  styleUrls: ['./appointment-calender.component.sass']
})
export class AppointmentCalenderComponent implements OnInit {

  @ViewChild('calendar', { static: false })
  calendar: Calendar | null;
  public addCusForm: FormGroup;
  dialogTitle: string;
  filterOptions = 'All';
  calendarData: any;
  apointemtsCalendar: Calendar[] = [];
  details:Appointment;


  public filters = [
    { name: 'all', value: 'All', checked: 'true' },
    { name: 'work', value: 'Work', checked: 'false' },
    { name: 'personal', value: 'Personal', checked: 'false' },
    { name: 'important', value: 'Important', checked: 'false' },
    { name: 'travel', value: 'Travel', checked: 'false' },
    { name: 'friends', value: 'Friends', checked: 'false' }
  ];

  calendarVisible = true;
  calendarPlugins = [
    dayGridPlugin,
    timeGridPlugin,
    interactionPlugin,
    listPlugin
  ];
  calendarWeekends = true;
  @ViewChild('callAPIDialog', { static: false }) callAPIDialog: TemplateRef<
    any
  >;
  calendarEvents: EventInput[];
  tempEvents: EventInput[];
  todaysEvents: EventInput[];

  constructor(
    private fb: FormBuilder,
    private dialog: MatDialog,
    private appointmentService: AppointmentService,
    private snackBar: MatSnackBar,
    private toastr: ToastrService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private authService: AuthService 
  ) {
    this.dialogTitle = 'Add New Event';
    this.calendar = new Calendar({});
    this.addCusForm = this.createContactForm(this.calendar);
    localStorage.removeItem("role");
    localStorage.setItem("role", "Patient");
    this.spinner.show();
  }

  public ngOnInit() {
    if(this.authService.currentUserValue.role == "Physician")
    {
      this.appointmentService.GetCalenderAppointmentsByPhysician(this.authService.currentUserValue.staffId).subscribe((data: Appointment[]) => {
        this.calendarEvents = this.CreateEvents(data);
        this.tempEvents = this.calendarEvents;
        this.spinner.hide();
      },
        (error) => { console.log("Error In Appointment List"); });
    }
    else{
      this.appointmentService.GetCalenderAppointments().subscribe((data: Appointment[]) => {
        console.log(this.authService.currentUserValue.role);
        this.calendarEvents = this.CreateEvents(data);
        this.tempEvents = this.calendarEvents;
        this.spinner.hide();
      },
        (error) => { console.log("Error In Appointment List"); });
    }
  }

  CreateEvents(data: Appointment[]) {
    for (var i = 0; i < data.length; i++) {
      let year = new Date(data[i].visitDate).getFullYear();
      let month = new Date(data[i].visitDate).getMonth();
      let day = new Date(data[i].visitDate).getDate();
      console.log('Data' + data[i].visitTime)
      var StartTime = data[i].visitTime.split(':');
      console.log('start' + StartTime)
      var EndTime = this.calculateEndTime(data[i].visitTime);
      console.log('End' + EndTime)
      this.appointmentService.patientProfileId= data[i].patientId;
      this.apointemtsCalendar.push({
        id: Number(data[i].visitId),
        title: data[i].visitTitle,
        start: new Date(year, month, day, Number(StartTime[0]), Number(StartTime[1])),
        end: new Date(year, month, day, Number(EndTime[0]), Number(EndTime[1])),
        groupId: data[i].staffId.toString(), //consider as physician id as per calender plugin
        className: this.getClassNameValue(data[i].visitStatus),
        details: data[i].visitDescription,
        backgroundColor:data[i].patientId.toString() //consider as patient id as per calender plugin
      })
    }
    return this.apointemtsCalendar;
    console.log(this.apointemtsCalendar);
  }

  calculateEndTime(StartTime) {
    let EndTime = StartTime.split(':');
    console.log(EndTime);
    let result;
    if (EndTime[1] >= 30) {
      result = (Number(EndTime[0]) + 1) + ':00';
    }
    else {
      result = (Number(EndTime[0])) + ':30';
    }
    return result.split(':');
  }

  createContactForm(calendar): FormGroup {
    return this.fb.group({
      id: [calendar.id],
      title: [calendar.title, [Validators.required, Validators.pattern('[a-zA-Z]+([a-zA-Z ]+)*')]],
      category: [calendar.category],
      startDate: [calendar.startDate, [Validators.required]],
      endDate: [calendar.endDate, [Validators.required]],
      details: [calendar.details, [Validators.required, Validators.pattern('[a-zA-Z]+([a-zA-Z ]+)*')]]
    });
  }


  addNewEvent() {
    /*
    const dialogRef = this.dialog.open(FormDialogComponent, {
      data: {
        calendar: this.calendar,
        action: 'add'
      }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'submit') {
        this.calendarData = this.calendarService.getDialogData();
        this.calendarEvents = this.calendarEvents.concat({
          // add new event data. must create new array
          id: this.calendarData.id,
          title: this.calendarData.title,
          start: this.calendarData.startDate,
          end: this.calendarData.endDate,
          className: this.calendarData.category,
          groupId: this.calendarData.category,
          details: this.calendarData.details
        });
        this.addCusForm.reset();
        this.showNotification(
          'snackbar-success',
          'Add Record Successfully...!!!',
          'bottom',
          'center'
        );
      }
    });*/
  }


  eventClick(row) {
     console.log(row)
    const calendarData: any = {
      id: row.event.id,
      visitTitle: row.event.title,
      staffId: Number(row.event.groupId),
      visitDate: row.event.start,
      visitTime: String(row.event.start).substr(16,5),
      visitDescription: row.event.extendedProps.details,
      reason: '',
      action: 'Update',
      visitId:row.event.id,
      patientId:row.event.backgroundColor
    };

    //this.calendarData['appointmentTime']=  this.calendarData['appointmentTime'].toString().substr(11,4);
    localStorage.setItem("role", "Physician");
    console.log('data ' + calendarData)
    const dialogRef = this.dialog.open(AppointmentDialogComponent, {
      width: '50%',
      data: calendarData
    });

    dialogRef.afterClosed().subscribe((result) => {
      let data: Appointment = this.appointmentService.getDialogData();
      if (data != undefined) //Added Condition if we click on close button on modal data is not store in service variavle hence throw undefined error
      {
        result=this.appointmentService.appointmentStatus='submit'?result:this.appointmentService.appointmentStatus;
        data.visitId = this.appointmentService.userId;
        this.PerformPhysicianOperations(data, result);
      }
    });
    /*
    const dialogRef = this.dialog.open(AppointmentDialogComponent, {
      data: {
        calendar: calendarData,
        action: 'edit'
      }
    });
*
    dialogRef.afterClosed().subscribe((result) => {
      if (result === 'submit') {
        this.calendarData = this.calendarService.getDialogData();
        this.calendarEvents.forEach(function (element, index) {
          if (this.calendarData.id === element.id) {
            this.editEvent(index, this.calendarData);
          }
        }, this);
        this.showNotification(
          'black',
          'Edit Record Successfully...!!!',
          'bottom',
          'center'
        );
        this.addCusForm.reset();
      } else if (result === 'delete') {
        this.calendarData = this.calendarService.getDialogData();
        this.calendarEvents.forEach(function (element, index) {
          if (this.calendarData.id === element.id) {
            this.filterEvent(element);
          }
        }, this);
        this.showNotification(
          'snackbar-danger',
          'Delete Record Successfully...!!!',
          'bottom',
          'center'
        );
      }
    });
    
     dialogRef.afterClosed().subscribe(result => {
      let data:Appointment=this.appointmentService.getDialogData();
      data.id=this.appointmentService.userId;
     if(data.appointmentReason!=undefined)
     {
       this.appointmentService.UpdateAppointmentDetails(data,data.id).
       subscribe(()=>
       {
         this.toastr.success("Appointment Updated Sucessfully","Success");
         this.router.navigate(['./patient/bookappointment']);
       });
     }
    });
    
    
    */
  }

  editEvent(eventIndex, calendarData: Calendar) {
    const calendarEvents = this.calendarEvents.slice();
    const TargetData = Object.assign({}, Appointment[eventIndex]);
    TargetData.visitId = calendarData.id;
    TargetData.visitTitle = calendarData.title;
    TargetData.staffId = calendarData.groupId;
    TargetData.visitDate = calendarData.start;
    TargetData.visitTime = calendarData.end;
    TargetData.reason = calendarData.details;
    TargetData.VisitDetails = calendarData.details;
    if (TargetData.reason != undefined) {
      this.appointmentService.UpdateAppointmentDetails(TargetData, TargetData.visitId).
        subscribe(() => {
          this.toastr.success("Appointment Updated Sucessfully", "Success");
          this.router.navigate(['./patient/bookappointment']);
        });
    }
  }

  getClassNameValue(category) {
    let className: string;
    if (category === 'Confirmed') className = 'fc-event-success';
    else if (category === 'Rejected') className = 'fc-event-danger';
    else if (category === 'Pending' || category == null) className = 'fc-event-warning';
    return className;
  }

  PerformPhysicianOperations(data, mode) {
    if (mode == 'Update') {
      if (data.visitId != undefined) {
        this.appointmentService.UpdateAppointmentDetails(data, data.visitId).
          subscribe(() => {
            this.toastr.success("Appointment Updated Sucessfully", "Success");
          });
      }
    }
    else if (mode == 'Confirm' || mode == "Reject") {
      data.appointmentStatus = mode + 'ed';
      data.visitStatus=data.appointmentStatus;
      this.appointmentService.ModifyAppoitmentStatus(data).
        subscribe(() => {
          this.toastr.success("Appointment " + data.appointmentStatus + " Sucessfully", "Success");
        });
    }
    else { }
    this.router.navigate(['./inbox/appointments']);
  }
}
