import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { AuthService } from '../../core/service/auth.service';
import { ToastrService } from 'ngx-toastr';
import { Users   } from '../../core/models/Users';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;
  error = '';
  hide = true;
  user : Users;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService, 
    private toaster : ToastrService
  ) {}
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['',  [Validators.required, Validators.email, Validators.minLength(5)]]
    });
  }
  get f() {
    return this.loginForm.controls;
  }
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    } else {
      console.log(this.f.email.value);
      this.authService.CheckUserExistsByEmail(this.f.email.value).subscribe(
        (user : Users) => 
        {
          this.user = user;
          // console.log(this.user.length);
          if(this.user.email != null)
          {
            this.toaster.success("Reset Password Details Sent To Your Email", "Success");
            this.router.navigate(['./authentication/signin']);
          }
          else {
            this.error = 'Email/Username Not Found!';
          }
        },
          (error) => {
            this.error = error;
            this.submitted = false;
          }
        );
    }
    }
}