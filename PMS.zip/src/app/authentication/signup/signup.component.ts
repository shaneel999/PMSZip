import { Component, OnInit, HostListener } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterService } from '../../core/service/register.service';
import { from, Observable } from 'rxjs';
import { Users } from '../../core/models/Users';
import { Title } from '../../core/Enums/Title';
import { ConfirmedValidator } from '../confirmed.validator';
import { AuthService } from '../../core/service/auth.service';
import { ToastrService } from 'ngx-toastr';
import { SignUpLocale } from '../../core/Common/Locales/SignUpLocale';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})

export class SignupComponent implements OnInit {
  public usersObservable: Observable<Users>;
  loginForm: FormGroup;
  user: Users;
  submitted = false;
  error: string;
  hide = true;
  chide = true;
  newUser: Users;
  TitleList: Title;
  minDate = new Date(Date.now());
  maxDate = new Date(Date.now());
  titleKeys: Title[] = [
    Title.Mr, Title.Mrs
  ];
  signupLocales = SignUpLocale;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private httpregister: RegisterService,
    private registerservice: AuthService,
    private toastr: ToastrService
  ) { }


  public get getTitleName(): typeof Title {
    return Title;
  }
  @HostListener("input", ["$event"])
  onKeyDown(event: KeyboardEvent) {
    let elementId: string = (event.target as Element).id;
    if (elementId === "contact") {
      const input = event.target as HTMLInputElement;
      let trimmed = input.value.replace(/\s+/g, "");

      if (trimmed.length > 12) {
        trimmed = trimmed.substr(0, 14);
      }

      trimmed = trimmed.replace(/-/g, "");

      let numbers = [];
      numbers.push(trimmed.substr(0, 3));

      if (trimmed.substr(3, 3) !== "") numbers.push(trimmed.substr(3, 3));
      if (trimmed.substr(6, 4) != "") numbers.push(trimmed.substr(6, 4));
      input.value = numbers.join("-");
    }
  }


  validateUser() {
    this.usersObservable = this.registerservice.CheckUserExistsByEmail(this.f.email.value);
    this.usersObservable.subscribe(
      (user: Users) => {
        this.user = user;
        console.log(this.user);
        if (this.user?.email != null) {
          this.loginForm.controls.email.setErrors({emailExists : true});
          this.toastr.error("Email already Exists", "Warning");
        }
        else {
          this.error = '';
        }
      },
      (error) => {
        this.error = error;
        this.submitted = false;
      }
    );
  }


  addUser() {
    if (this.loginForm.invalid) {
      this.toastr.error("Something went wrong", "Error");
      console.log(this.loginForm.invalid);
      console.log(this.loginForm.value);
      return;

    } else {
      this.newUser = new Users();
      this.newUser.title = this.getTitleName[this.f.title.value];
      this.newUser.firstName = this.f.FirstName.value;
      this.newUser.lastName = this.f.LastName.value;
      this.newUser.dob = this.f.DOB.value;
      this.newUser.contactNumber = this.f.ContactNumber.value;
      this.newUser.email = this.f.email.value;
      this.newUser.password = this.f.userPassword.value;
      // this.newUser.status = "Active";
      console.log(this.newUser);
      
      this.httpregister.createUser(this.newUser).subscribe((response) => {
        console.log("User Has Been Added");
        //this.RegisterButtonCSS();
      
          this.toastr.success("Patient Registered Succesfully", "Success");
          this.router.navigate(['/authentication/signin']);
      
      })
    }
  }

SetDatesForCalendar(){
  let startDate =this.maxDate;
  
  // setting the min date and thus the max birth date allowing < 100 year old choosable birthdate
  this.minDate.setDate( this.minDate.getDate() );
  this.minDate.setFullYear( this.minDate.getFullYear() - 100 );
  
  // setting the calendar's start date and youngest birth dates for > 18 years old
  this.maxDate.setDate( this.maxDate.getDate() );
  this.maxDate.setFullYear( this.maxDate.getFullYear() - 18 );
  //this.minDate = this.maxDate;
}

  

  //maxDate = (new Date().getFullYear()-18);

  ngOnInit() {
   this.SetDatesForCalendar();
    this.loginForm = this.formBuilder.group({
      title: ['', Validators.required],

      FirstName: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(20), Validators.pattern('[a-zA-Z]*')]],
      LastName: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(20), Validators.pattern('[a-zA-Z]*')]],
      email: ['', [Validators.required, Validators.email, Validators.minLength(5), Validators.maxLength(50)]],
      userPassword: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(30), Validators.pattern('(?=\\D*\\d)(?=[^a-z]*[a-z])(?=[^A-Z]*[A-Z]).{8,30}')]],
      userConfirmPassword: ['', Validators.required],
      DOB: ['', [Validators.required]],

      ContactNumber: ['', [Validators.required, Validators.pattern("^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$")]]

    }, {
      validator: ConfirmedValidator('userPassword', 'userConfirmPassword')
    })
  }
  get f() {
    return this.loginForm.controls;
  }




  // RegisterButtonCSS(){
  //   let button = document.querySelector('.button');
  //   button.addEventListener('click', this.toggleClass);
  //   button.addEventListener('transitionend', this.toggleClass);
  //   button.addEventListener('transitionend', this.addClass);
  // }

  // toggleClass() {
  //   document.querySelector('.button').classList.toggle('active');
  // }
  
  //  addClass() {
  //   document.querySelector('.button').classList.add('finished');
  // }

}