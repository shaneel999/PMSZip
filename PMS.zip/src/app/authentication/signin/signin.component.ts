import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../core/service/auth.service';
import { Users } from '../../core/models/Users';
import { ToastrService } from 'ngx-toastr';
import { SignInLocale } from '../../core/Common/Locales/SignInLocale';
import { Status } from '../../core/Enums/Status';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;
  error = '';
  hide = true;
  user: Users;
  loginId: any;
  loginPassword: any;
  rememberMe: boolean = false;
  public usersObservable: Observable<Users[]>;
  public userList: Users[] = null;
  signinLocales = SignInLocale;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private toaster: ToastrService
  ) { }
  ngOnInit() {
    if (localStorage.getItem("remember") == "true") {
      this.rememberMe = true;

      console.log(localStorage.getItem("rememberMeId"));
      this.loginId = localStorage.getItem("rememberMeId");
      this.loginPassword = localStorage.getItem("rememberMePass");
    }
    this.loginForm = this.formBuilder.group({
      email: [
        (this.rememberMe ? this.loginId : 'dev1@gmail.com'),// default for testing
        [Validators.required, Validators.email, Validators.minLength(5), Validators.maxLength(50)]
      ],
      password: [(this.rememberMe ? this.loginPassword : 'password'), Validators.required], //default for testing
      Role : ['Patient', Validators.required],
      rememberMe: [(this.rememberMe ? true : false)]
    });
   
    this.CheckAccessTokenAndRedirect();

  }
  get formValues() {
    return this.loginForm.controls;
  }
  
  onSubmit() {
    this.submitted = true;
    // console.log(this.loginForm.controls);
    this.error = '';
    // console.log("Role " +this.formValues.Role.value);
    if (this.loginForm.invalid) {
      // this.error = 'Username and Password not valid !';
      return;
    } else {
      // console.log(this.f.rememberMe.value);
      this.authService.GenerateJwtToken(this.formValues.email.value, this.formValues.password.value, this.formValues.Role.value)
      .subscribe(
        (user: Users) => {
          this.user = user;
          console.log(this.user);
          if (this.user.email != null) {
            if (this.user.status != Status[1]) {
              this.toaster.error(this.signinLocales.signinBlockedUser, "Not Allowed");
              return;
            }
            localStorage.setItem("access_token", this.user.token);
            this.CheckAccessTokenAndRedirect();

            if (this.formValues.rememberMe.value) {
              localStorage.setItem("remember", "true");
              localStorage.setItem("rememberMeId", this.formValues.email.value);
              localStorage.setItem("rememberMePass", this.formValues.password.value);
            }
            else {
              localStorage.removeItem("remember");
            }
          }
          else {
            if(this.user.loginFailedAttempts > 0)
            {
              if(this.user.loginFailedAttempts == 3)
              {
                this.toaster.error(`User Is blocked. Contact Admin!!`, "User Blocked")
              }
              else
              {
                this.toaster.error(`${(3 - this.user.loginFailedAttempts)} more attemts remaining`, "Login Failed")
              }
            }
            else
            {
              this.toaster.error(this.signinLocales.signinInvalidCredentials, "Invalid Credentials");
            }
          }
        },
        (error) => {
          console.log(error);
          this.toaster.error(this.signinLocales.signinTokenError, "Services Down");
          this.submitted = false;
        }
      );
    }
  }

  private CheckAccessTokenAndRedirect() {
    if (localStorage.getItem('access_token')) {
      // console.log("Role " + this.authService.currentUserValue.role);
      if(this.authService.currentUserValue.role == "Patient")
      {
        this.router.navigate(['./dashboard/patient']);
      }
      if(this.authService.currentUserValue.role == "Admin")
      {
        this.router.navigate(['./dashboard/main']);
      }
      //Physician
      if(this.authService.currentUserValue.role == "Physician")
      {
        this.router.navigate(['./dashboard/physician']);
      }
      //Nurse
      if(this.authService.currentUserValue.role == "Nurse")
      {
        this.router.navigate(['./dashboard/nurse']);
      }
    }
  }  
}