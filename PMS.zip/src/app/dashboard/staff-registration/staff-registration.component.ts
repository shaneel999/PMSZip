import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Staff } from '../../core/models/Staff';
import { StaffService } from '../../core/service/staff.service';
import { ConfirmedValidator } from '../../authentication/confirmed.validator';
import { Title } from '../../core/Enums/Title';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-staff-registration',
  templateUrl: './staff-registration.component.html',
  styleUrls: ['./staff-registration.component.scss']
})
export class StaffRegistrationComponent implements OnInit {


  staffDetailsForm:any;
  submitted = false;
  error = '';
  hide = true;
  staffDetails : Staff[];
  public staffObservable: Observable<Staff[]>;
  public staffList : Staff[] = null;
  maxDate = new Date();
  TitleList=Title;
  titleKeys = [];

  RoleList: any[] = [
    {value: '', viewValue: ''},
    {value: '2', viewValue: 'Physician'},
    {value: '3', viewValue: 'Nurse'}
  ];

  constructor(private formBuilder: FormBuilder,private router: Router,private staffService:StaffService,private toastr:ToastrService) 
  {
    this.titleKeys = Object.keys(this.TitleList).filter(f => !isNaN(Number(f)));
    
  }

  //Password: ['', [Validators.required,Validators.minLength(3),Validators.maxLength(20)]],
 // ConfirmPassword: ['', Validators.required],
 
  ngOnInit() {
    this.staffDetailsForm = this.formBuilder.group({
      FirstName:  ['', [Validators.required,Validators.minLength(3),Validators.maxLength(20),Validators.pattern('[a-zA-Z]*')]],
      LastName :  ['', [Validators.required,Validators.minLength(3),Validators.maxLength(20),Validators.pattern('[a-zA-Z]*')]],
      ContactNumber:  ['', [Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      Email:['',[Validators.required, Validators.email,Validators.minLength(5), Validators.maxLength(30)]],
      DateOfBirth:['', [Validators.required]],
      DateOfJoining:['', [Validators.required]],
      Title:['',Validators.required],
      RoleId:['',Validators.required],
      employeeCode:['',Validators.required]
    });
  }
  get f() {
    return this.staffDetailsForm.controls;
  }

  AddStaff()
  {
    if (this.staffDetailsForm.invalid) {
      this.toastr.error("Something went wrong","Error");
      return;
    } 
    else 
    {
      console.log(this.staffDetailsForm);
      const staffDetails=this.staffDetailsForm.value;
      console.log(staffDetails);
      this.staffService.AddStaffUser(staffDetails)
      .subscribe(
        ()=>{
          this.toastr.success("Staff User Added","Success");
          this.router.navigate(['./dashboard/main']);
        });
    }
  }

}
