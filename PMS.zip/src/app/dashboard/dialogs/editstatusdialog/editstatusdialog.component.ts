import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {
  FormControl,
  Validators,
  FormGroup,
  FormBuilder
} from '@angular/forms';
import { Status } from '../../../core/Enums/Status';
import { Staff } from '../../../core/models/Staff';
import { AuthService } from '../../../core/service/auth.service';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-editstatusdialog',
  templateUrl: './editstatusdialog.component.html',
  styleUrls: ['./editstatusdialog.component.sass']
})
export class EditstatusdialogComponent implements OnInit {
  action: string;
  dialogTitle: string;
  staffData: Staff;
  statusStaffForm: FormGroup;
  public staffObservable: Observable<Staff>;
  constructor(public dialogRef: MatDialogRef<EditstatusdialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private statusStaffBuilder: FormBuilder,
    private authService: AuthService,
    private toaster: ToastrService) {
    this.action = data.action;

    this.dialogTitle = "Edit Staff Status";
    this.staffData = data.Staff;
  }

  public get getStatusName(): typeof Status {
    return Status;
  }

  get formValues() {
    return this.statusStaffForm.controls;
  }

  ngOnInit(): void {
    // console.log(this.data.userFirstName);
    this.statusStaffForm = this.statusStaffBuilder.group({
      staffstatus: ['', Validators.required]
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  public confirmAdd(): void {
    this.data.status = this.getStatusName[this.formValues.staffstatus.value];
    this.staffObservable = this.authService.UpdatestaffStatus(this.data)
    this.staffObservable.subscribe(
      (user: Staff) => {
        this.staffData = user;
        // console.log(this.staffData.email);
        if (this.staffData.email != null) {
          // console.log("Inside UpdateStatus success");
          this.toaster.success("Status Changed Successfully!!", "Status Updated");
          this.dialogRef.close();
        }
        else {
          this.toaster.error('Error in status updation!', "Error");
        }
      },
      (error) => {
        console.log("Update Status Error");
      }
    );
  }

}
