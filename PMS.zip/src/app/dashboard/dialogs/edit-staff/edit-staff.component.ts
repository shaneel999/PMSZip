import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../../../core/service/auth.service';
import { Staff } from '../../../core/models/Staff';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-edit-staff',
  templateUrl: './edit-staff.component.html',
  styleUrls: ['./edit-staff.component.sass']
})
export class EditStaffComponent implements OnInit {

  EditStaffForm: FormGroup;
  staffData: Staff;
  public staffObservable: Observable<Staff>;
  constructor(private formBuilder: FormBuilder, public dialogRef: MatDialogRef<EditStaffComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Staff, private toaster: ToastrService,
    private authService: AuthService, ) {
    this.staffData = data;
  }

  ngOnInit(): void {
    console.log(this.staffData);
    this.EditStaffForm = this.formBuilder.group({
      firstName: [this.staffData.firstName, [Validators.required, Validators.maxLength(20)]],
      lastName: [this.staffData.lastName, [Validators.required, Validators.maxLength(20)]],
      email:[this.staffData.email]
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
  public confirmAdd(): void {
    this.staffObservable = this.authService.UpdateStaff(this.EditStaffForm.getRawValue());
    this.staffObservable.subscribe(
        (staff: Staff) => {
          this.toaster.success("Status Changed Successfully!!", "Status Updated");
            this.dialogRef.close();
        },
        (error) => {
          console.log("Error In Staff Updation");
        }
      );
  }
}
