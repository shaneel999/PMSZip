import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import {
  FormControl,
  Validators,
  FormGroup,
  FormBuilder
} from '@angular/forms';
import { Status } from '../../../core/Enums/Status';
import { Users } from '../../../core/models/Users';
import { AuthService } from '../../../core/service/auth.service';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-editdialog',
  templateUrl: './editdialog.component.html',
  styleUrls: ['./editdialog.component.sass']
})
export class EditdialogComponent {
  action: string;
  dialogTitle: string;
  userData: Users;
  statusForm : FormGroup;
  public userObservable: Observable<Users>;
  constructor(public dialogRef: MatDialogRef<EditdialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private statusBuilder: FormBuilder, 
    private authService: AuthService,
    private toaster: ToastrService) {
    this.action = data.action;

    this.dialogTitle = "Edit Status";
    this.userData = data.Users;
  }

  public get getStatusName(): typeof Status {
    return Status;
  }

  get formValues() {
    return this.statusForm.controls;
  }

  ngOnInit(): void {
    this.statusForm = this.statusBuilder.group({
      status : ['', Validators.required]
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
  public confirmAdd(): void {
    console.log(this.formValues.status.value);
    this.data.status = this.getStatusName[this.formValues.status.value];
    this.userObservable = this.authService.UpdateStatus(this.data)
      this.userObservable.subscribe(
        (user: Users) => {
          this.userData = user;
          // console.log(this.userData.email);
          if (this.userData.email != null) {
            // console.log("Inside UpdateStatus success");
            this.toaster.success("Status Changed Successfully!!", "Status Updated");
            this.dialogRef.close();
          }
          else {
            this.toaster.error('Error in status updation!', "Error");
          }
        },
        (error) => {
          console.log("Update Status Error");
        }
      );
  }

}
