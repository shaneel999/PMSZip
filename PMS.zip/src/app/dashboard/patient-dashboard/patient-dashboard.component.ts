import { Component, OnInit } from '@angular/core';
import { patientdashboard } from '../../core/models/patientdashboard';
import { AuthService } from 'src/app/core/service/auth.service';
import { Users } from '../../core/models/Users';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {DashboardService} from '../../core/service/dashboard.service';

@Component({
  selector: 'app-patient-dashboard',
  templateUrl: './patient-dashboard.component.html',
  styleUrls: ['./patient-dashboard.component.sass']
})
export class PatientDashboardComponent implements OnInit {
  patientdashboardData: patientdashboard;
  selectedDate:Date;
  constructor(private registerservice: AuthService, private formBuilder: FormBuilder,private dasboardService: DashboardService) { }

  user: Users;
  ngOnInit(): void {

    var userDetails = JSON.parse(localStorage.getItem('currentUser'));
    // console.log(userDetails);
    
    this.dasboardService.getPatientDashboardData(userDetails.patientId).subscribe((data:patientdashboard)=>{
      console.log(data);
      let year = new Date(data.upcomingAppointment).getFullYear();
      let month = new Date(data.upcomingAppointment).getMonth();
      let day = new Date(data.upcomingAppointment).getDate();
      this.selectedDate = new Date(year, month, day);
      this.patientdashboardData=data;
      console.log(data);
   });

    // this.registerservice.GetUserDetails(userDetails.email).subscribe(
    //   (user: Users) => {
    //     this.user = user;
    //     console.log(user.ContactNumber)

    //   },
    //   (error) => {
    //     console.log("Error In AllergyData");
    //   }
    // );

  }
}
