import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Users } from '../../core/models/Users';
import { MatSort } from '@angular/material/sort';
import { AuthService } from '../../core/service/auth.service';
import { Staff } from '../../core//models/Staff';
import { Role } from '../../core/Enums/Role';
import { Title } from '../../core/Enums/Title';
import { EditdialogComponent} from '../dialogs/editdialog/editdialog.component';
import { MatDialog } from '@angular/material/dialog';
import { EditstatusdialogComponent } from '../dialogs/editstatusdialog/editstatusdialog.component';
import { TableUtil } from "../../core//models/tableUtil";
import * as XLSX from "xlsx";
import { EditStaffComponent } from '../dialogs/edit-staff/edit-staff.component'
import { EChartOption } from 'echarts';

import {
  ChartComponent,
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  ApexTitleSubtitle,
  ApexDataLabels,
  ApexPlotOptions,
  ApexYAxis,
  ApexLegend,
  ApexStroke,
  ApexFill,
  ApexTooltip
} from 'ng-apexcharts';
import { DashboardService } from 'src/app/core/service/dashboard.service';
import { PieChartData } from 'src/app/core/models/PieChartData';
import { BarChartData } from 'src/app/core/models/BarChartData';
import { BarChartModule } from '@swimlane/ngx-charts';

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  yaxis: ApexYAxis;
  xaxis: ApexXAxis;
  fill: ApexFill;
  tooltip: ApexTooltip;
  stroke: ApexStroke;
  legend: ApexLegend;
};


declare const ApexCharts: any;

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {
  usersData: Users[] = null;
  staffData: Staff[] = null;
  sortedData: Users[];
  sortedstaffData: Staff[];
  datasource: MatTableDataSource<Users>;
  datasourceStaff: MatTableDataSource<Staff>;
  displayedColumns: string[] = ['patientId', 'firstName', "createdDate", "status", "Edit Status"];
  displayedStaffColumns: string[] = ["firstName", "Role","staff status","Edit Staff Status", "Edit"];
  pieChartData:PieChartData;
  barChartData:BarChartData;

  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild('otherPaginator') paginatorStaff: MatPaginator;
  @ViewChild('sort') sort: MatSort;
  @ViewChild('sortStaff') sortStaff: MatSort;

  public barChart2Options: any;
  constructor(private authService: AuthService, private dialog: MatDialog,private dasboardService:DashboardService) { 
  }
  exportTable() {
    TableUtil.exportTableToExcel("ExampleMaterialTable");
  }
  public get getRoleName(): typeof Role {
    return Role; 
  }

  public get getTitleName(): typeof Title {
    return Title; 
  }

  public doFilter = (value: string) => {
    this.datasourceStaff.filter = value.trim().toLocaleLowerCase();
  }

  public doUserFilter = (value: string) => {
    this.datasource.filter = value.trim().toLocaleLowerCase();
  }

  ngOnInit() {
    
    // this.pieChartData.confirmedAppointments=0;
    // this.pieChartData.pendingAppointments=0;
    // this.pieChartData.rejectedAppointments=0;

    this.authService.GetUsers()
      .subscribe(
        (user: Users[]) => {

          this.usersData = user;
          // console.log(user[0]);
          this.datasource = new MatTableDataSource<Users>(this.usersData);
          this.datasource.paginator = this.paginator;
          this.datasource.sort = this.sort;
        },
        (error) => {
          console.log("Error In Patient List");
        }
      );

      this.authService.GetStaffUsers()
      .subscribe(
        (staff: Staff[]) => {

          this.staffData = staff;
          console.log(this.staffData);
          this.datasourceStaff = new MatTableDataSource<Staff>(this.staffData);
          // console.log("uyteqwutqwu" + this.datasource);
          this.datasourceStaff.paginator = this.paginatorStaff;
          this.datasourceStaff.sort = this.sortStaff;
        },
        (error) => {
          console.log("Error In Staff List");
        }
      );

      this.dasboardService.getPieChartData().subscribe((data:PieChartData)=>{
        this.pieChartData = data;
        this.pie_chart.series[0].data[0].value = data.pendingAppointments;
        this.pie_chart.series[0].data[1].value = data.rejectedAppointments;
        this.pie_chart.series[0].data[2].value = data.confirmedAppointments;
      });

      this.dasboardService.getBarChartData().subscribe((data:BarChartData)=>{
        this.barChartData=data;
        this.PopulateBarChart(data);
      });
    
  }


  editCall(row) {
    // this.id = row.id;
    const dialogRef = this.dialog.open(EditdialogComponent, {
      data: row
    });
  }

  editstatusCall(rows) {
    // this.id = row.id;
    const dialogRef = this.dialog.open(EditstatusdialogComponent, {
      data: rows
    });
  }

  editstaffCall(rows:Staff) {
    // this.id = row.id;
    const dialogRef = this.dialog.open(EditStaffComponent, {
      data: rows
    });
  }

  //Graph Data 
    /* Pie Chart */
    pie_chart: EChartOption = {
      tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} ({d}%)'
      },
      legend: {
        data: ['Pending', 'Rejected', 'Confirmed'],
        textStyle: {
          color: '#9aa0ac',
          padding: [0, 5, 0, 5]
        }
      },
      
      series: [
        {
          name: 'Chart Data',
          type: 'pie',
          radius: '65%',
          center: ['50%', '48%'],
          data: [
            {
              value: 23,//this.pieChartData.pendingAppointments,
              name: 'Pending'
            },
            {
              value:  30,//this.pieChartData.rejectedAppointments,
              name: 'Rejected'
            },
            {
              value: 43,//this.pieChartData.confirmedAppointments,
              name: 'Confirmed'
            }
          ]
        }
      ],
      color: ['#DFC126', '#DE725C','#575B7A' ]
    };

   
  private PopulateBarChart(data:BarChartData) {
    this.barChart2Options = {
      series: [
        {
          name: 'Patients',
          data:[data.january, data.february, data.march, data.april, data.may, data.june, data.july, data.august, data.september, data.october, data.november, data.december]
        }
      ],
      chart: {
        height: 232,
        type: 'bar',
        foreColor: '#9aa0ac'
      },
      plotOptions: {
        bar: {
          dataLabels: {
            position: 'top' // top, center, bottom
          }
        }
      },
      dataLabels: {
        enabled: true,
        formatter: function (val) {
          return val; 
        },
        offsetY: -20,
        style: {
          fontSize: '12px',
          colors: ['#9aa0ac']
        }
      },

      xaxis: {
        categories: [
          'Jan',
          'Feb',
          'Mar',
          'Apr',
          'May',
          'Jun',
          'Jul',
          'Aug',
          'Sep',
          'Oct',
          'Nov',
          'Dec'
        ],
        position: 'top',
        labels: {
          offsetY: -18,
          style: {
            colors: '#9aa0ac'
          }
        },
        axisBorder: {
          show: false
        },
        axisTicks: {
          show: false
        },
        crosshairs: {
          fill: {
            type: 'gradient',
            gradient: {
              colorFrom: '#D8E3F0',
              colorTo: '#D8E3F0',
              stops: [0, 100],
              opacityFrom: 0.4,
              opacityTo: 0.4
            }
          }
        },
        tooltip: {
          enabled: true,
          offsetY: -35
        }
      },
      fill: {
        type: 'gradient',
        gradient: {
          shade: 'light',
          type: 'horizontal',
          shadeIntensity: 0.25,
          gradientToColors: undefined,
          inverseColors: true,
          opacityFrom: 1,
          opacityTo: 1,
          stops: [50, 0, 100, 100]
        }
      },
      yaxis: {
        axisBorder: {
          show: false
        },
        axisTicks: {
          show: false
        },
        labels: {
          show: false,
          formatter: function (val) {
            return val;
          }
        }
      },
      title: {
        text: 'Number of patients registerd per month',
        floating: 0,
        offsetY: 320,
        align: 'center',
        style: {
          color: '#9aa0ac'
        }
      },
      tooltip: {
        theme: 'dark',
        marker: {
          show: true
        },
        x: {
          show: true
        }
      }
    };
  }
}

