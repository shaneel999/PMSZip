import { AfterViewInit, ChangeDetectorRef, Component, DoCheck, OnChanges, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { VisitDetails } from '../../core/models/VisitDetails';
import { AppointmentDialogComponent } from '../../patient/appointment-dialog/appointment-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { Appointment } from '../../core/models/appointment';
import { AppointmentService } from '../../core/service/appointment.service';
import { ToastrService } from 'ngx-toastr';
import { MatPaginator } from '@angular/material/paginator';
import { Router } from '@angular/router';
import AppointmentPicker from 'appointment-picker';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DashboardService } from '../../core/service/dashboard.service';
import { StaffDashboardData } from '../../core/models/StaffDashboardData';
import { PatientService } from '../../core/service/patient.service';
import { AuthService } from '../../core/service/auth.service';
import { Staff } from '../../core/models/Staff';
import { Users } from '../../core/models/Users';

@Component({
  selector: 'app-nurse-dashboard',
  templateUrl: './nurse-dashboard.component.html',
  styleUrls: ['./nurse-dashboard.component.scss']
})
export class NurseDashboardComponent implements OnInit {
  appointmentDetails: Appointment;
  appointmentData: Appointment[] = null;
  visitData: VisitDetails[] = null;
  displayedColumns: string[] = ['Appointment Title', 'Physician Name', 'Patient Name', 'Appointment Date', 'Appointment Time', 'Appointment Status'];
  dataSource: MatTableDataSource<VisitDetails>;
  staffDashboardData: StaffDashboardData;
  PhysicianList: Staff[];
  PatientsList : Users[];

  @ViewChild('paginator') paginator: MatPaginator;

  constructor(private formBuilder: FormBuilder, private authService: AuthService, private dialog: MatDialog, private appointmentService: AppointmentService, private patientService: PatientService,
    private toastr: ToastrService, private router: Router, private changeDetectorRefs: ChangeDetectorRef, private dasboardService: DashboardService) {
  }

  ngOnInit(): void {
    this.GetAllPhysiciansList();
    this.GetAllPatientsList();
    this.dasboardService.getNurseDashboardData(this.authService.currentUserValue.staffId).subscribe((data: StaffDashboardData) => {
      this.staffDashboardData = data;
    });

    this.reloadData();
  }

  GetAllPhysiciansList() {
    this.appointmentService.GetAllPhysicians().subscribe((data: Staff[]) => {
      this.PhysicianList = data;
      console.log(data)
    })
  }

  GetAllPatientsList() {
    this.dasboardService.GetUsers().subscribe((data: Users[]) => {
      this.PatientsList = data;
    })
  }

  UpdateAppointment(mode: string, obj: Appointment) {
    obj.action = mode;
    console.log('obj' + obj)
    const dialogRef = this.dialog.open(AppointmentDialogComponent, {
      width: '50%',
      data: obj
    });

    dialogRef.afterClosed().subscribe(result => {
      let data: Appointment = this.appointmentService.getDialogData();
      if (data != undefined) {
        data.visitId = this.appointmentService.userId;
        if (data.reason != undefined) {
          this.appointmentService.UpdateAppointmentDetails(data, data.visitId).
            subscribe(() => {
              this.toastr.success("Appointment Updated Sucessfully", "Success");
            });
        }
        this.reloadData();
      }
    });
  }
  DeleteAppointment(mode: string, data: any) {
    if (data.visitId != undefined) {
      this.appointmentService.DeleteAppointment(data.visitId).
        subscribe(() => {
          this.toastr.success("Appointment Deleted Sucessfully", "Success");
          this.reloadData();
        });
    }
  }

  reloadData() {
    this.patientService.GetappointmentDetails().subscribe((data: VisitDetails[]) => {
      console.log('reload')
      this.visitData = data;

      for (var i = 0; i < this.visitData.length; i++) {
        this.visitData[i].physicianName =
          (this.PhysicianList.find(e => e.staffId == this.visitData[i].staffId).firstName + " " +
            this.PhysicianList.find(e => e.staffId == this.visitData[i].staffId).lastName)
            // console.log("First" + this.visitData[i].staffId);
      }

      for (var i = 0; i < this.visitData.length; i++) {
        this.visitData[i].patientName =
          (this.PatientsList.find(e => e.patientId == this.visitData[i].patientId).firstName + " " +
            this.PatientsList.find(e => e.patientId == this.visitData[i].patientId).lastName)
            // console.log("First" + this.visitData[i].staffId);
      }

      this.dataSource = new MatTableDataSource<VisitDetails>(this.visitData);
      this.dataSource.paginator = this.paginator;
      this.changeDetectorRefs.detectChanges();
    },
      (error) => {
        console.log("Error In Appointment List");
      }

    );
  }
  CheckAppointmentValidity(appointment) {
    let StartTime = appointment.visitTime.split(':');
    let year = new Date(appointment.visitDate).getFullYear();
    let month = new Date(appointment.visitDate).getMonth();
    let day = new Date(appointment.visitDate).getDate();
    let resultDate = new Date(year, month, day, Number(StartTime[0]), Number(StartTime[1]))
    let currentDate = new Date();
    if (resultDate < currentDate) {
      return true;
    }
    else {
      return false;
    }
  }
}
