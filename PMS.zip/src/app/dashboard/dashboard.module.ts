import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { MainComponent } from './main/main.component';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { FullCalendarModule } from '@fullcalendar/angular';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { StaffRegistrationComponent } from './staff-registration/staff-registration.component';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FlexLayoutModule } from '@angular/flex-layout';
import { EditdialogComponent } from './dialogs/editdialog/editdialog.component';
import { EditstatusdialogComponent } from './dialogs/editstatusdialog/editstatusdialog.component';
import { PatientDashboardComponent } from './patient-dashboard/patient-dashboard.component';
import { NurseDashboardComponent } from './nurse-dashboard/nurse-dashboard.component';
import { PhysicianDashboardComponent } from './physician-dashboard/physician-dashboard.component';
import { EditStaffComponent } from './dialogs/edit-staff/edit-staff.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { NotificationComponent } from '../dashboard/notification/notification.component';

import { NgxEchartsModule } from 'ngx-echarts';
import { ChartsModule as chartjsModule } from 'ng2-charts';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgApexchartsModule } from 'ng-apexcharts';
import { GaugeModule } from 'angular-gauge';
import { NgxGaugeModule } from 'ngx-gauge';

@NgModule({
  declarations: [MainComponent, StaffRegistrationComponent, EditdialogComponent, EditstatusdialogComponent, PatientDashboardComponent, NurseDashboardComponent, PhysicianDashboardComponent, EditStaffComponent,NotificationComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatPaginatorModule,
    MatTableModule,
    DashboardRoutingModule,
    chartjsModule,
    MatMenuModule,
    MatIconModule,
    MatButtonModule,
    FullCalendarModule,
    PerfectScrollbarModule,
    MatInputModule,
    MatSelectModule,
    MatFormFieldModule,
    FlexLayoutModule, 
    MatSortModule,
    MatDatepickerModule,
   // ChartsRoutingModule,
    NgxEchartsModule.forRoot({
      echarts: () => import('echarts')
    }),
    NgxChartsModule,
    NgApexchartsModule,
    //NgxGaugeModule,
    //GaugeModule.forRoot()
  ]
})
export class DashboardModule { }
