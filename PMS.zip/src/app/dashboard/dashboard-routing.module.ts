import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './main/main.component';
import { NotificationComponent } from './notification/notification.component';
import { NurseDashboardComponent } from './nurse-dashboard/nurse-dashboard.component';
import { PatientDashboardComponent } from './patient-dashboard/patient-dashboard.component';
import { PhysicianDashboardComponent } from './physician-dashboard/physician-dashboard.component';
import { StaffRegistrationComponent } from './staff-registration/staff-registration.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'main',
    pathMatch: 'full'
  },
  {
    path: 'main',
    component: MainComponent
  },
  {
    path: 'CreateStaff',
    component: StaffRegistrationComponent
  },
  {
    path: 'patient',
    component: PatientDashboardComponent
  },
  {
    path: 'nurse',
    component: NurseDashboardComponent
  },
  {
    path: 'physician',
    component: PhysicianDashboardComponent
  },
  {
    path: 'notifications',
    component: NotificationComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule {}
