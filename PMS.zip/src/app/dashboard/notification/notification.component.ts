import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NotificationDetails } from 'src/app/core/models/NotificationDetails';
import { DashboardService } from 'src/app/core/service/dashboard.service';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss'],
  providers:[DatePipe]
})
export class NotificationComponent implements OnInit {
  notifications:NotificationDetails[];
  constructor( private dasboardService: DashboardService,private datepipe: DatePipe) { }

  ngOnInit(): void {
    this.fetchNotifications();
  }

  fetchNotifications()
  {
   this.dasboardService.fetchNotifications(2).subscribe((data:NotificationDetails[])=>{
    //  console.log(data);
     this.notifications=data;
   });
  }

  getNotificationTimeDiff(createdTime:string):string
  {
    // console.log(createdTime);
    var dateOneObj = new Date(createdTime).getTime();
    var dateTwoObj = new Date().getTime();

    var diff =(dateOneObj-dateTwoObj) / 1000;
    var minutes=Math. abs(Math. round(diff/60)).toString();
    // console.log(minutes);
    var hours=Math. abs(Math. round(diff/3600)).toString();
    // console.log(hours);
    if(parseInt(minutes) < 60)
    {
      return minutes.toString()+" Minutes ago"
    }
    else if(parseInt(hours)<24)
    {
      return hours.toString()+" Hours ago"
    }
    else
    {
    return this.datepipe.transform(createdTime,"MMMM d, y");
    }
  }

  MakeNotificationAsSeen(notificationId)
  {
    this.dasboardService.MarkNotificationSeen(notificationId).subscribe((data:any)=>{
      this.fetchNotifications();
    });
  }

}
