﻿using AppointmentAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AppointmentAPI.Service
{
   public interface IAppointment
    {
        IEnumerable<Visit> GetAppointmentsByUser(int UserId);

        IEnumerable<Visit> GetAllAppointmentsForCalender();
        IEnumerable<Visit> GetAllAppointmentsForCalenderByPhysicianId(int physicianId);
        IEnumerable<Visit> GetAppointments();
        Visit GetVisitDetailsById(int VisitId);

        bool AddAppointment(Visit visitData);

        bool UpdateAppointment(Visit visitData,int VisitId);

        bool DeleteAppointment(int VisitId);

        IEnumerable<staff> GetPhysicians();
       
        IEnumerable<Visit> GetAppointmentsByNurse(); 
        
        IEnumerable<Visit> GetAppointmentsByPhysician(int physicianId);

        bool ConfigureNotification(string NotificationDescription, int userId,string Username);

        bool UpdateNotificationStatus(int notificationId);

        bool UpdateAppointmentStatus(int appointmentId, string visitStatus);

        List<Notification> GetNotificationByUserId(int userId);

        bool MarkNotificationAsSeen(int notificationId);

        Patient GetPatientDetailsByID(int patientId);

        VisitDetail GetPatientHealthInformationByID(int patientId);
    }

    public class AppointmentRepository : IAppointment
    {
        private PMSContext _appcontext;
        private bool result = false;
        private int id = 0;
        Visit visitDetails = new Visit();
        string NotificationDescription = string.Empty;
        string Username = string.Empty;

        public AppointmentRepository(PMSContext appcontext)
        {
            this._appcontext = appcontext;
        }

        //To display all appoitnments for that patient User
        public IEnumerable<Visit> GetAppointmentsByUser(int UserId)
        {
            return this._appcontext.Visits.Where(x => x.PatientId == UserId).OrderBy(use => use.VisitDate).ThenBy(x => x.VisitTime).ToList<Visit>();
        }

        //Get All Appointments to be shown in calender in Calender Page
        public IEnumerable<Visit> GetAllAppointmentsForCalender()
        {
            return this._appcontext.Visits.ToList<Visit>();
        }

        public IEnumerable<Visit> GetAllAppointmentsForCalenderByPhysicianId(int physicianId)
        {
            return this._appcontext.Visits.Where(x => x.StaffId == physicianId).ToList<Visit>();
        }


        //Get Specific appointment by AppointmentId to edit the details
        public Visit GetVisitDetailsById(int VisitId)
        {
            return this._appcontext.Visits.Where(x => x.VisitId == VisitId).FirstOrDefault();
        }

        //Add Appointment
        public bool AddAppointment(Visit visitData)
        {
            try
            {
                this._appcontext.Add(visitData);
                id = this._appcontext.SaveChanges();
                result = id >= 1 ? true : false;

                //Configure Notification for physician 
                Patient patientData= this._appcontext.Patients.Where(x => x.PatientId == visitData.PatientId).FirstOrDefault();
                NotificationDescription = patientData.FirstName+" "+ patientData.LastName+ " Scheduled the appointment on "+ visitData.CreatedDate +" at "+ visitData.VisitTime;
                Username = patientData.FirstName + " " + patientData.LastName;
                this.ConfigureNotification(NotificationDescription, visitData.StaffId??0,Username);
            }
            catch (Exception ex)
            { }
            return result;
        }

        //Update Appointment         
         public bool UpdateAppointment(Visit visitData, int visitId) 
         {
            try 
            {
                visitDetails = this._appcontext.Visits.Find(visitId);
                if (visitDetails != null)
                {
                    visitDetails.PatientId = visitData.PatientId;
                    visitDetails.StaffId = visitData.StaffId;
                    visitDetails.VisitTitle = visitData.VisitTitle;
                    visitDetails.VisitDate = visitData.VisitDate;
                    visitDetails.VisitTime = visitData.VisitTime;
                    visitDetails.VisitStatus = visitData.VisitStatus;
                    visitDetails.Reason = visitData.Reason;
                    visitDetails.IsPatientScheduled = visitData.IsPatientScheduled;
                    visitDetails.IsNurseScheduled = visitData.IsNurseScheduled;
                    visitDetails.CreatedBy = visitData.CreatedBy;
                    visitDetails.IsActive = visitData.IsActive;
                    visitDetails.CreatedDate = visitData.CreatedDate;
                    id = this._appcontext.SaveChanges();
                    result = id >= 1 ? true : false;

                    //Configure Notification for physician 
                    Patient patientData = this._appcontext.Patients.Where(x => x.PatientId == visitData.PatientId).FirstOrDefault();
                    NotificationDescription = patientData.FirstName + " " + patientData.LastName + " Update the appointment on " + visitData.CreatedDate + " at " + visitData.VisitTime;
                    Username = patientData.FirstName + " " + patientData.LastName;
                    this.ConfigureNotification(NotificationDescription, visitData.StaffId ?? 0,Username);
                }
            }
            catch(Exception ex)
            { }
            return result;
        }

        //Remove Appointment
        public bool DeleteAppointment(int VisitId)
        {
            try 
            {
                visitDetails = this._appcontext.Visits.Find(VisitId);
                if(visitDetails != null)
                {
                    this._appcontext.Remove(visitDetails);
                    this._appcontext.SaveChanges();
                    return true;
                }
               
            }
            catch(Exception ex)
            { }
            return false;
        }

        //Get all active physicians
        public IEnumerable<staff> GetPhysicians()
        {
            return this._appcontext.staff.Where(x => x.IsActive == true && x.RoleId == 2).ToList<staff>();
        }

        public IEnumerable<Visit> GetAppointmentsByNurse()
        {
            return this._appcontext.Visits.OrderByDescending(x => x.VisitDate).ThenBy(x => x.VisitTime).ToList<Visit>();
        }

        public IEnumerable<Visit> GetAppointmentsByPhysician(int physicianId)
        {
            return this._appcontext.Visits.Where(x => x.StaffId == physicianId && x.VisitDate >= DateTime.Today).OrderBy(x => x.VisitDate).ThenBy(x => x.VisitTime).ToList<Visit>();
        }

        public bool ConfigureNotification(string NotificationDescription, int userId,string Username="") 
        {
            try 
            {
                Notification data = new Notification();
                data.Description = NotificationDescription;
                data.UserId = userId;
                data.CreatedDate = DateTime.Now.ToString("MM/dd/yyyy hh:mm tt");
                data.IsSeen = false;
                if (Username != "")
                {
                    data.UserName = Username;
                }
                this._appcontext.Notifications.Add(data);
                id = this._appcontext.SaveChanges();
                result = id >= 1 ? true : false;
            }
            catch (Exception ex) 
            {
               
            }
            return result;
        }

        public bool UpdateNotificationStatus(int notificationId) 
        {
            try 
            {
                Notification data = this._appcontext.Notifications.Find(notificationId);
                if (data != null)
                {
                    data.IsSeen = true;
                    data.ModifiedDate=DateTime.Now.ToString("MM/dd/yyyy hh:mm tt");
                    id = this._appcontext.SaveChanges();
                    result = id >= 1 ? true : false;
                }
            }
            catch (Exception ex) 
            {
            }
            return result;
        }

        public bool UpdateAppointmentStatus(int appointmentId,string visitStatus)
        {
            try
            {
                Visit data = this._appcontext.Visits.Find(appointmentId);
                if (data != null)
                {
                    data.VisitStatus = visitStatus;
                    data.VisitId = appointmentId;
                    id = this._appcontext.SaveChanges();
                    result = id >= 1 ? true : false;

                    //Configure Notification
                    if (visitStatus.ToLower() == "confirmed" || visitStatus.ToLower() == "rejected")
                    {
                        Visit visitData = this._appcontext.Visits.Where(x => x.VisitId == appointmentId).FirstOrDefault();
                        Patient patientData = this._appcontext.Patients.Where(x => x.PatientId == visitData.PatientId).FirstOrDefault();
                        NotificationDescription = "Appointment for patient " + patientData.FirstName + " " + patientData.LastName + " is " + visitStatus + " on " + Convert.ToDateTime(visitData.CreatedDate).ToString("dddd, dd MMMM yyyy HH:mm:ss").Substring(0, 21) + " at " + visitData.VisitTime;
                        int[] NurseList = this._appcontext.staff.Where(x => x.RoleId == 3).Select(x => x.StaffId).ToArray();
                        Username = patientData.FirstName + " " + patientData.LastName;
                        //Configure Notification for Nurse 
                        foreach (int userId in NurseList)
                        {
                            this.ConfigureNotification(NotificationDescription, userId,Username);
                        }
                        //Configure Notification for Patient 
                        int PatientId = patientData.PatientId;
                        this.ConfigureNotification(NotificationDescription, PatientId, Username);
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return result;
        }
        
        public List<Notification> GetNotificationByUserId(int userId) 
        {
            List<Notification> NotificationData = new List<Notification>();
            try 
            {
               NotificationData = this._appcontext.Notifications.Where(x => x.UserId == userId).OrderByDescending(d=>d.CreatedDate).ToList();
            }
            catch(Exception ex) 
            {
            }
            return NotificationData;
        }


        public bool MarkNotificationAsSeen(int notificationId)
        {
            try
            {
                Notification data = this._appcontext.Notifications.Find(notificationId);
                if (data != null)
                {
                    data.IsSeen = true;
                    id = this._appcontext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
            }
            return true;
        }

        public Patient GetPatientDetailsByID(int patientId)
        {
            Patient patientDetails = new Patient();
            try
            {
                patientDetails = this._appcontext.Patients.Where(x => x.PatientId == patientId).FirstOrDefault();
            }
            catch (Exception ex) { }

            return patientDetails;
        }

        public VisitDetail GetPatientHealthInformationByID(int patientId)
        {
            VisitDetail patientVisitDetails = new VisitDetail();
            try
            {
                List<Visit> visitDetails = this._appcontext.Visits.Where(x => x.PatientId == patientId).ToList();
                int visitId = this._appcontext.Visits.Select(x => x.VisitId).Max();
                patientVisitDetails = (from t1 in this._appcontext.Visits
                                       join t2 in this._appcontext.VisitDetails on t1.VisitId equals t2.VisitId
                                       where t2.VisitId == visitId
                                       select new VisitDetail
                                       {
                                           Height = t2.Height,
                                           Weight = t2.Weight,
                                           BloodPressure = t2.BloodPressure,
                                           BodyTemprature = t2.BodyTemprature,
                                           RespirationRate = t2.RespirationRate
                                       }).FirstOrDefault();

            }
            catch (Exception ex) { }

            return patientVisitDetails;
        }



        public IEnumerable<Visit> GetAppointments()
        {
            IEnumerable<Visit> data = null;
            try 
            {
                data = this._appcontext.Visits.Where(x => x.VisitDate >= DateTime.Today).OrderBy(x => x.VisitDate).ToList<Visit>();
            }
            catch(Exception ex) { }
          return data;
        }
    }
}
