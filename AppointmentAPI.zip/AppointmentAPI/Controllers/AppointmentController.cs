﻿using AppointmentAPI.Models;
using AppointmentAPI.Service;
using Microsoft.AspNetCore.Mvc;
using System;

namespace AppointmentAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppointmentController : ControllerBase
    {
        private IAppointment _repAppointment;
        private bool IsResult;
        public AppointmentController(IAppointment repository)
        {
            this._repAppointment = repository;
        }

        [HttpGet]
        public IActionResult GetAllAppointments(int userId)
        {
            try
            {
                var data = _repAppointment.GetAppointmentsByUser(userId);
                return Ok(data);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        [HttpGet("GetNurseCalendar")]
        public IActionResult GetAllAppointments()
        {
            try
            {
                var data = _repAppointment.GetAllAppointmentsForCalender();
                return Ok(data);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        [HttpGet("GetPhysicianCalendar")]
        public IActionResult GetPhysicianAppointments(int physicianId)
        {
            try
            {
                var data = _repAppointment.GetAllAppointmentsForCalenderByPhysicianId(physicianId);
                return Ok(data);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        [HttpGet("GetAllPhysicians")]
        public IActionResult GetAllPhysicians()
        {
            try
            {
                var data = _repAppointment.GetPhysicians();
                return Ok(data);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        //[HttpGet]
        //public IActionResult GetAllAppointmentsForAdmin()
        //{
        //    try
        //    {
        //        var data = _repAppointment.GetAllAppointmentsForCalender();
        //        return Ok(data);
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    return BadRequest();
        //}

        //[HttpGet]
        //public IActionResult GetAppointmentById(int VisitId)
        //{
        //    try
        //    {
        //        var data = _repAppointment.GetVisitDetailsById(VisitId);
        //        return Ok(data);
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    return BadRequest();
        //}

        [HttpPost]
        public IActionResult AddAppointmentDetails([FromBody] Visit AppointmentData)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Visit visitDetails = new Visit();
                    visitDetails.PatientId = AppointmentData.PatientId;
                    visitDetails.StaffId = AppointmentData.StaffId;
                    visitDetails.VisitTitle = AppointmentData.VisitTitle;
                    visitDetails.VisitDate = ((DateTime)AppointmentData.VisitDate).AddDays(+1);
                    visitDetails.VisitTime = AppointmentData.VisitTime;
                    visitDetails.VisitStatus = AppointmentData.VisitStatus;
                    visitDetails.VisitDescription = AppointmentData.VisitDescription;
                    visitDetails.Reason = AppointmentData.Reason;
                    visitDetails.IsPatientScheduled = AppointmentData.IsPatientScheduled;
                    visitDetails.IsNurseScheduled = AppointmentData.IsNurseScheduled;
                    visitDetails.CreatedBy = AppointmentData.CreatedBy;
                    visitDetails.IsActive = AppointmentData.IsActive;
                    visitDetails.CreatedDate = AppointmentData.CreatedDate;

                    IsResult = this._repAppointment.AddAppointment(visitDetails);
                    if (IsResult)
                    {
                        return Ok();
                    }
                }
                else
                {
                    return new BadRequestObjectResult(ModelState);
                }
            }
            catch (Exception ex)
            {

            }
            return BadRequest();
        }

        [HttpPut]
        public IActionResult UpdateAppointmentDetails([FromBody] Visit AppointmentData)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (AppointmentData.VisitDate != null)
                        AppointmentData.VisitDate = ((DateTime)AppointmentData.VisitDate).AddDays(+1);
                    IsResult = this._repAppointment.UpdateAppointment(AppointmentData, AppointmentData.VisitId);
                    if (IsResult)
                    {
                        return Ok();
                    }
                }
                else
                {
                    return new BadRequestObjectResult(ModelState);
                }
            }
            catch (Exception ex)
            {

            }
            return NotFound();
        }

        [HttpDelete]
        public IActionResult DeleteAppointmentDetails(int appointmentId)
        {
            try
            {
                IsResult = _repAppointment.DeleteAppointment(appointmentId);
                if (IsResult)
                {
                    return Ok();
                }
            }
            catch (Exception ex)
            {

            }
            return NotFound();
        }

        [HttpGet("GetAllAppointmentsForNurseDashboard")]
        public IActionResult GetAllAppointmentsForNurseDashboard()
        {
            try
            {
                var data = _repAppointment.GetAppointmentsByNurse();
                return Ok(data);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        [HttpGet("GetAllAppointmentsForPhysicianDashboard")]
        public IActionResult GetAllAppointmentsForPhysicianDashboard(int physicianId)
        {
            try
            {
                var data = _repAppointment.GetAppointmentsByPhysician(physicianId);
                return Ok(data);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        [HttpPut("ModifyNotificationStatus")]
        public IActionResult UpdateNotificationDetails(int notificationId)
        {
            try
            {
                if (notificationId > 0)
                {
                    IsResult = this._repAppointment.UpdateNotificationStatus(notificationId);
                    if (IsResult)
                    {
                        return Ok();
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return NotFound();
        }


        [HttpPut("ModifyAppointmentStatus")]
        public IActionResult UpdateAppointmentStatus([FromBody] Visit data)
        {
            try
            {
                if (data.VisitId > 0)
                {
                    IsResult = this._repAppointment.UpdateAppointmentStatus(data.VisitId, data.VisitStatus);
                    if (IsResult)
                    {
                        return Ok();
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return NotFound();
        }

        [HttpGet("GetAllNotifications")]
        public IActionResult GetAllNotifications(int userId)
        {
            try
            {
                if (userId > 0)
                {
                    var data = this._repAppointment.GetNotificationByUserId(userId);
                    return Ok(data);
                }
            }
            catch (Exception ex)
            {

            }
            return NotFound();
        }

        [HttpGet("MarkNotificationAsSeen")]
        public IActionResult MarkNotificationAsSeen(int notificationId)
        {
            try
            {
                if (notificationId > 0)
                {
                    IsResult = this._repAppointment.MarkNotificationAsSeen(notificationId);
                    if (IsResult)
                    {
                        return Ok(IsResult);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return NotFound();
        }

        [HttpGet("GetPatientDetailsByID")]
        public IActionResult GetPatientDetailsByID(int patientId)
        {
            try
            {
                if (patientId > 0)
                {
                    var data = this._repAppointment.GetPatientDetailsByID(patientId);
                    return Ok(data);
                }
            }
            catch (Exception ex)
            {

            }
            return NotFound();
        }

        [HttpGet("GetPatientHealthInformationByID")]
        public IActionResult GetPatientHealthInformationByID(int patientId)
        {
            try
            {
                if (patientId > 0)
                {
                    var data = this._repAppointment.GetPatientHealthInformationByID(patientId);
                    return Ok(data);
                }
            }
            catch (Exception ex)
            {

            }
            return NotFound();
        }

        [HttpGet("GetAllPatientAppointments")]
        public IActionResult GetAllPatientAppointments()
        {
            var data = this._repAppointment.GetAppointments();
            return Ok(data);
        }
    }
}
