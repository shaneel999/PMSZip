﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AppointmentAPI.Models
{
    public partial class Gender
    {
        public Gender()
        {
            Patients = new HashSet<Patient>();
        }

        public int GenderId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<Patient> Patients { get; set; }
    }
}
