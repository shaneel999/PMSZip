﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace AppointmentAPI.Models
{
    public partial class PMSContext : DbContext
    {
        public PMSContext()
        {
        }

        public PMSContext(DbContextOptions<PMSContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Allergy> Allergies { get; set; }
        public virtual DbSet<Diagnosis> Diagnoses { get; set; }
        public virtual DbSet<Drug> Drugs { get; set; }
        public virtual DbSet<Ethinicity> Ethinicities { get; set; }
        public virtual DbSet<Gender> Genders { get; set; }
        public virtual DbSet<Note> Notes { get; set; }
        public virtual DbSet<NoteReply> NoteReplies { get; set; }
        public virtual DbSet<Notification> Notifications { get; set; }
        public virtual DbSet<Patient> Patients { get; set; }
        public virtual DbSet<PatientAllergy> PatientAllergies { get; set; }
        public virtual DbSet<PatientEmergencyContact> PatientEmergencyContacts { get; set; }
        public virtual DbSet<Procedure> Procedures { get; set; }
        public virtual DbSet<Race> Races { get; set; }
        public virtual DbSet<Relationship> Relationships { get; set; }
        public virtual DbSet<UserLogin> UserLogins { get; set; }
        public virtual DbSet<UserRole> UserRoles { get; set; }
        public virtual DbSet<Visit> Visits { get; set; }
        public virtual DbSet<VisitDetail> VisitDetails { get; set; }
        public virtual DbSet<staff> staff { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Allergy>(entity =>
            {
                entity.ToTable("Allergy");

                entity.Property(e => e.AllergyClinicalInformation)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.AllergyDescription)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.AllergyName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.AllergyType)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Diagnosis>(entity =>
            {
                entity.ToTable("Diagnosis");

                entity.Property(e => e.DiagnosisCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.DiagnosisDescription)
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Drug>(entity =>
            {
                entity.ToTable("Drug");

                entity.Property(e => e.DrugForm)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DrugGenericName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DrugManufacturerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DrugName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DrugStrength)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Ethinicity>(entity =>
            {
                entity.ToTable("Ethinicity");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Gender>(entity =>
            {
                entity.ToTable("Gender");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Note>(entity =>
            {
                entity.ToTable("Note");

                entity.Property(e => e.NoteId).HasColumnName("NoteID");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.NoteDescription)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.NoteTitle)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.NoteCreatedByNavigations)
                    .HasForeignKey(d => d.CreatedBy)
                    .HasConstraintName("FK__Note__CreatedBy__3D5E1FD2");

                entity.HasOne(d => d.NotesClosedByNavigation)
                    .WithMany(p => p.NoteNotesClosedByNavigations)
                    .HasForeignKey(d => d.NotesClosedBy)
                    .HasConstraintName("FK__Note__NotesClose__3E52440B");
            });

            modelBuilder.Entity<NoteReply>(entity =>
            {
                entity.ToTable("NoteReply");

                entity.Property(e => e.NoteReplyId).HasColumnName("NoteReplyID");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.NoteId).HasColumnName("NoteID");

                entity.Property(e => e.ReplyNote)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.HasOne(d => d.Note)
                    .WithMany(p => p.NoteReplies)
                    .HasForeignKey(d => d.NoteId)
                    .HasConstraintName("FK__NoteReply__NoteI__32E0915F");

                entity.HasOne(d => d.RepliedByNavigation)
                    .WithMany(p => p.NoteReplies)
                    .HasForeignKey(d => d.RepliedBy)
                    .HasConstraintName("FK__NoteReply__Repli__4222D4EF");
            });

            modelBuilder.Entity<Notification>(entity =>
            {
                entity.Property(e => e.CreatedDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Patient>(entity =>
            {
                entity.ToTable("Patient");

                entity.Property(e => e.ContactNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Dob)
                    .HasColumnType("date")
                    .HasColumnName("DOB");

                entity.Property(e => e.Email)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.EthnicityId).HasColumnName("EthnicityID");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HomeAddress)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.LanguagesKnown)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.RaceId).HasColumnName("RaceID");

                entity.Property(e => e.Status)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Title)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Ethnicity)
                    .WithMany(p => p.Patients)
                    .HasForeignKey(d => d.EthnicityId)
                    .HasConstraintName("FK__Patient__Ethnici__267ABA7A");

                entity.HasOne(d => d.GenderNavigation)
                    .WithMany(p => p.Patients)
                    .HasForeignKey(d => d.Gender)
                    .HasConstraintName("FK__Patient__Gender__24927208");

                entity.HasOne(d => d.Race)
                    .WithMany(p => p.Patients)
                    .HasForeignKey(d => d.RaceId)
                    .HasConstraintName("FK__Patient__RaceID__25869641");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.Patients)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK__Patient__RoleId__276EDEB3");
            });

            modelBuilder.Entity<PatientAllergy>(entity =>
            {
                entity.ToTable("PatientAllergy");

                entity.Property(e => e.PatientAllergyId).HasColumnName("PatientAllergyID");

                entity.Property(e => e.AllergyId).HasColumnName("AllergyID");

                entity.Property(e => e.PatientId).HasColumnName("PatientID");

                entity.HasOne(d => d.Allergy)
                    .WithMany(p => p.PatientAllergies)
                    .HasForeignKey(d => d.AllergyId)
                    .HasConstraintName("FK__PatientAl__Aller__38996AB5");

                entity.HasOne(d => d.Patient)
                    .WithMany(p => p.PatientAllergies)
                    .HasForeignKey(d => d.PatientId)
                    .HasConstraintName("FK__PatientAl__Patie__2D27B809");
            });

            modelBuilder.Entity<PatientEmergencyContact>(entity =>
            {
                entity.HasKey(e => e.PatientEmergencyId);

                entity.ToTable("PatientEmergencyContact");

                entity.Property(e => e.PatientEmergencyId).HasColumnName("PatientEmergencyID");

                entity.Property(e => e.ContactNumber)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PatientAddress)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.PatientId).HasColumnName("PatientID");

                entity.Property(e => e.RelationshipId).HasColumnName("RelationshipID");

                entity.Property(e => e.VisitDescription)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.HasOne(d => d.Patient)
                    .WithMany(p => p.PatientEmergencyContacts)
                    .HasForeignKey(d => d.PatientId)
                    .HasConstraintName("FK__PatientEm__Patie__29572725");

                entity.HasOne(d => d.Relationship)
                    .WithMany(p => p.PatientEmergencyContacts)
                    .HasForeignKey(d => d.RelationshipId)
                    .HasConstraintName("FK__PatientEm__Relat__3B75D760");
            });

            modelBuilder.Entity<Procedure>(entity =>
            {
                entity.Property(e => e.ProcedureCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ProcedureDescription)
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Race>(entity =>
            {
                entity.ToTable("Race");

                entity.Property(e => e.Name)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Relationship>(entity =>
            {
                entity.ToTable("Relationship");

                entity.Property(e => e.RelationshipName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<UserLogin>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PK__UserLogi__1788CCAC58E97D12");

                entity.ToTable("UserLogin");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoginFailedDate).HasColumnType("datetime");

                entity.Property(e => e.UserPassword).HasMaxLength(500);

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.UserLogins)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK__UserLogin__RoleI__3A81B327");
            });

            modelBuilder.Entity<UserRole>(entity =>
            {
                entity.HasKey(e => e.RoleId)
                    .HasName("PK__UserRole__8AFACE1A51A549CF");

                entity.Property(e => e.RoleName)
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Visit>(entity =>
            {
                entity.ToTable("Visit");

                entity.Property(e => e.VisitId).HasColumnName("VisitID");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.PatientId).HasColumnName("PatientID");

                entity.Property(e => e.Reason)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.StaffId).HasColumnName("StaffID");

                entity.Property(e => e.VisitDate).HasColumnType("date");

                entity.Property(e => e.VisitDescription)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.VisitStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.VisitTime)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.VisitTitle)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.HasOne(d => d.Patient)
                    .WithMany(p => p.Visits)
                    .HasForeignKey(d => d.PatientId)
                    .HasConstraintName("FK__Visit__PatientID__30F848ED");

                entity.HasOne(d => d.Staff)
                    .WithMany(p => p.Visits)
                    .HasForeignKey(d => d.StaffId)
                    .HasConstraintName("FK__Visit__StaffID__31EC6D26");
            });

            modelBuilder.Entity<VisitDetail>(entity =>
            {
                entity.HasKey(e => e.VisitDetailsid)
                    .HasName("PK__VisitDet__BCA68F2B5CC7E9A5");

                entity.ToTable("VisitDetail");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.DiagnosisId).HasColumnName("DiagnosisID");

                entity.Property(e => e.DrugId).HasColumnName("DrugID");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.ProcedureId).HasColumnName("ProcedureID");

                entity.Property(e => e.VisitId).HasColumnName("VisitID");

                entity.HasOne(d => d.Diagnosis)
                    .WithMany(p => p.VisitDetails)
                    .HasForeignKey(d => d.DiagnosisId)
                    .HasConstraintName("FK__VisitDeta__Diagn__403A8C7D");

                entity.HasOne(d => d.Drug)
                    .WithMany(p => p.VisitDetails)
                    .HasForeignKey(d => d.DrugId)
                    .HasConstraintName("FK__VisitDeta__DrugI__412EB0B6");

                entity.HasOne(d => d.Procedure)
                    .WithMany(p => p.VisitDetails)
                    .HasForeignKey(d => d.ProcedureId)
                    .HasConstraintName("FK__VisitDeta__Proce__4222D4EF");

                entity.HasOne(d => d.Visit)
                    .WithMany(p => p.VisitDetails)
                    .HasForeignKey(d => d.VisitId)
                    .HasConstraintName("FK__VisitDeta__Visit__4316F928");
            });

            modelBuilder.Entity<staff>(entity =>
            {
                entity.ToTable("Staff");

                entity.Property(e => e.ContactNumber)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Dob)
                    .HasColumnType("date")
                    .HasColumnName("DOB");

                entity.Property(e => e.Email)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EmployeeId)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Status)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Title)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.staff)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("FK__Staff__RoleId__21B6055D");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
