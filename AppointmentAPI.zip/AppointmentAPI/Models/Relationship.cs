﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AppointmentAPI.Models
{
    public partial class Relationship
    {
        public Relationship()
        {
            PatientEmergencyContacts = new HashSet<PatientEmergencyContact>();
        }

        public int RelationshipId { get; set; }
        public string RelationshipName { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<PatientEmergencyContact> PatientEmergencyContacts { get; set; }
    }
}
