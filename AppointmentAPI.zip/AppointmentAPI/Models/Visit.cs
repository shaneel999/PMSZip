﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AppointmentAPI.Models
{
    public partial class Visit
    {
        public Visit()
        {
            VisitDetails = new HashSet<VisitDetail>();
        }

        public int VisitId { get; set; }
        public int? PatientId { get; set; }
        public int? StaffId { get; set; }
        public string VisitTitle { get; set; }
        public DateTime? VisitDate { get; set; }
        public string VisitTime { get; set; }
        public string VisitStatus { get; set; }
        public string VisitDescription { get; set; }
        public string Reason { get; set; }
        public bool? IsPatientScheduled { get; set; }
        public bool? IsNurseScheduled { get; set; }
        public int? CreatedBy { get; set; }
        public bool? IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }

        public virtual Patient Patient { get; set; }
        public virtual staff Staff { get; set; }
        public virtual ICollection<VisitDetail> VisitDetails { get; set; }
    }
}
