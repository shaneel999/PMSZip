﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AppointmentAPI.Models
{
    public partial class PatientAllergy
    {
        public int PatientAllergyId { get; set; }
        public int? PatientId { get; set; }
        public int? AllergyId { get; set; }
        public bool? IsFatalAllergy { get; set; }
        public bool? IsActive { get; set; }

        public virtual Allergy Allergy { get; set; }
        public virtual Patient Patient { get; set; }
    }
}
