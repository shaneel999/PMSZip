﻿using System;
using System.Collections.Generic;

#nullable disable

namespace AppointmentAPI.Models
{
    public partial class UserLogin
    {
        public int UserId { get; set; }
        public string Email { get; set; }
        public string UserPassword { get; set; }
        public int? RoleId { get; set; }
        public bool? IsLocked { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? LoginFailedDate { get; set; }
        public int? LoginFailedAttempts { get; set; }
        public bool? IsActive { get; set; }

        public virtual UserRole Role { get; set; }
    }
}
