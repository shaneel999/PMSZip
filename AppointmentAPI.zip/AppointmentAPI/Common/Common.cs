﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AppointmentAPI.Common
{
    public class Common
    {
    }
    public enum Roles
    {
        Patient = 1,
        Physician = 2,
        Nurse = 3,
        Admin = 4
    }

    public enum Status
    {
        Active = 1,
        DeActivate = 2,
        Block = 3,
        Activate = 4,
        InActive = 5,
        Blocked = 6
    }
}
