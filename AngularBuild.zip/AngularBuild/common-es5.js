(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"], {
    /***/
    "r4p4":
    /*!**************************************!*\
      !*** ./src/app/core/Enums/Status.ts ***!
      \**************************************/

    /*! exports provided: Status */

    /***/
    function r4p4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Status", function () {
        return Status;
      });

      var Status;

      (function (Status) {
        Status[Status["Active"] = 1] = "Active";
        Status[Status["DeActivate"] = 2] = "DeActivate";
        Status[Status["Block"] = 3] = "Block";
        Status[Status["Activate"] = 4] = "Activate";
        Status[Status["InActive"] = 5] = "InActive";
        Status[Status["Blocked"] = 6] = "Blocked";
      })(Status || (Status = {}));
      /***/

    }
  }]);
})();
//# sourceMappingURL=common-es5.js.map