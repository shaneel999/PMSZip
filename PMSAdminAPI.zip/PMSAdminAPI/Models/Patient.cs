﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAdminAPI.Models
{
    public partial class Patient
    {
        public Patient()
        {
            PatientAllergies = new HashSet<PatientAllergy>();
            PatientEmergencyContacts = new HashSet<PatientEmergencyContact>();
            Visits = new HashSet<Visit>();
        }

        public int PatientId { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public DateTime? Dob { get; set; }
        public string ContactNumber { get; set; }
        public int? Gender { get; set; }
        public int? RaceId { get; set; }
        public int? EthnicityId { get; set; }
        public string LanguagesKnown { get; set; }
        public string HomeAddress { get; set; }
        public string Status { get; set; }
        public bool? IsActive { get; set; }
        public int? RoleId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public int? ModifiedBy { get; set; }

        public virtual Ethinicity Ethnicity { get; set; }
        public virtual Gender GenderNavigation { get; set; }
        public virtual Race Race { get; set; }
        public virtual UserRole Role { get; set; }
        public virtual ICollection<PatientAllergy> PatientAllergies { get; set; }
        public virtual ICollection<PatientEmergencyContact> PatientEmergencyContacts { get; set; }
        public virtual ICollection<Visit> Visits { get; set; }
    }
}
