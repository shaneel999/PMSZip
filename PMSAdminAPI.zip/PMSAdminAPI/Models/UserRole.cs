﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAdminAPI.Models
{
    public partial class UserRole
    {
        public UserRole()
        {
            Patients = new HashSet<Patient>();
            UserLogins = new HashSet<UserLogin>();
            staff = new HashSet<staff>();
        }

        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<Patient> Patients { get; set; }
        public virtual ICollection<UserLogin> UserLogins { get; set; }
        public virtual ICollection<staff> staff { get; set; }
    }
}
