﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAdminAPI.Models
{
    public partial class Drug
    {
        public Drug()
        {
            VisitDetails = new HashSet<VisitDetail>();
        }

        public int DrugId { get; set; }
        public string DrugName { get; set; }
        public string DrugGenericName { get; set; }
        public string DrugManufacturerName { get; set; }
        public string DrugForm { get; set; }
        public string DrugStrength { get; set; }

        public virtual ICollection<VisitDetail> VisitDetails { get; set; }
    }
}
