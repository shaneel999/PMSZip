﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAdminAPI.Models
{
    public class PieChartData
    {
        public int PendingAppointments { get; set; }
        public int ConfirmedAppointments { get; set; }
        public int RejectedAppointments { get; set; }

    }
}
