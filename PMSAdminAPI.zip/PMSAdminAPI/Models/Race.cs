﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAdminAPI.Models
{
    public partial class Race
    {
        public Race()
        {
            Patients = new HashSet<Patient>();
        }

        public int RaceId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<Patient> Patients { get; set; }
    }
}
