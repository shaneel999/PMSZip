﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAdminAPI.Models
{
    public partial class NoteReply
    {
        public int NoteReplyId { get; set; }
        public int? NoteId { get; set; }
        public string ReplyNote { get; set; }
        public int? RepliedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public bool? IsActive { get; set; }

        public virtual Note Note { get; set; }
        public virtual staff RepliedByNavigation { get; set; }
    }
}
