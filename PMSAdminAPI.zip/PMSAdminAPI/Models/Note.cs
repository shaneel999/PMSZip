﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAdminAPI.Models
{
    public partial class Note
    {
        public Note()
        {
            NoteReplies = new HashSet<NoteReply>();
        }

        public int NoteId { get; set; }
        public string NoteTitle { get; set; }
        public string NoteDescription { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public bool? IsActive { get; set; }
        public int? NotesClosedBy { get; set; }

        public virtual staff CreatedByNavigation { get; set; }
        public virtual staff NotesClosedByNavigation { get; set; }
        public virtual ICollection<NoteReply> NoteReplies { get; set; }
    }
}
