﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAdminAPI.Models
{
    public partial class Allergy
    {
        public Allergy()
        {
            PatientAllergies = new HashSet<PatientAllergy>();
        }

        public int AllergyId { get; set; }
        public string AllergyType { get; set; }
        public string AllergyName { get; set; }
        public string AllergyDescription { get; set; }
        public string AllergyClinicalInformation { get; set; }

        public virtual ICollection<PatientAllergy> PatientAllergies { get; set; }
    }
}
