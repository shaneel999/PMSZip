﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAdminAPI.Models
{
    public partial class PatientEmergencyContact
    {
        public int PatientEmergencyId { get; set; }
        public int? PatientId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? RelationshipId { get; set; }
        public string Email { get; set; }
        public string ContactNumber { get; set; }
        public string PatientAddress { get; set; }
        public bool? AccessToPatientPortal { get; set; }
        public string VisitDescription { get; set; }

        public virtual Patient Patient { get; set; }
        public virtual Relationship Relationship { get; set; }
    }
}
