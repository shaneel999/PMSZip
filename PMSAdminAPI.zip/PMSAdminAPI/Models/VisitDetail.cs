﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAdminAPI.Models
{
    public partial class VisitDetail
    {
        public int VisitDetailsid { get; set; }
        public int? VisitId { get; set; }
        public int? Height { get; set; }
        public int? Weight { get; set; }
        public int? BloodPressure { get; set; }
        public double? BodyTemprature { get; set; }
        public int? RespirationRate { get; set; }
        public int? ProcedureId { get; set; }
        public int? DiagnosisId { get; set; }
        public int? DrugId { get; set; }
        public bool? IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public int? ModifiedBy { get; set; }

        public virtual Diagnosis Diagnosis { get; set; }
        public virtual Drug Drug { get; set; }
        public virtual Procedure Procedure { get; set; }
        public virtual Visit Visit { get; set; }
    }
}
