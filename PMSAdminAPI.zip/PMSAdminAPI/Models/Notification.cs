﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAdminAPI.Models
{
    public partial class Notification
    {
        public int NotificationId { get; set; }
        public string Description { get; set; }
        public int? UserId { get; set; }
        public bool? IsSeen { get; set; }
        public string CreatedDate { get; set; }
        public string ModifiedDate { get; set; }
        public string UserName { get; set; }
    }
}
