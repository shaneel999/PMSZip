﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PMSAdminAPI.Models;
using PMSAdminAPI.Services;
using PMSAPI.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAdminAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {

        private IAdminRepository _adminRepo;

        public AdminController(IAdminRepository repo)
        {
            _adminRepo = repo;
        }

        [HttpGet]
        public IActionResult GetAllPatients()
        {
            var data = _adminRepo.GetAllPatients();
            return Ok(data);
        }

        [HttpGet]
        [Route("Staff")]
        public IActionResult GetAllStaff()
        {
            var data = _adminRepo.GetAllStaff();
            
            return Ok(data);
        }

        [HttpPatch]
        public IActionResult UpdatePatientStatus(Patient patient)
        {
            if(ModelState.IsValid)
            {
                var data = _adminRepo.UpdatePatientStatus(patient);
                if (data != null)
                    return Ok(data);
                else
                    return new BadRequestObjectResult(ModelState);
            }
            return new BadRequestObjectResult(ModelState);
        }

        [HttpPost]
        public IActionResult CreateStaff(staff staffUser)
        {
            if(ModelState.IsValid)
            {
                staffUser.Status = Status.Active.ToString();
                staffUser.CreatedDate = DateTime.Now;
                staffUser.CreatedBy = Convert.ToInt32(Roles.Admin);
                staffUser.IsActive = true;
                staffUser.EmployeeId = staffUser.EmployeeId;
                int count = this._adminRepo.CreateStaffUser(staffUser);
                if(count>0)
                {
                    UserLogin user = new UserLogin();
                    user.Email = staffUser.Email;
                    user.UserPassword = Common.CreateRandomPassword(8);
                    user.IsActive = true;
                    user.CreatedDate = DateTime.Now;
                    //Roles role = staffUser.Role.ToString() == "Physician" ? Roles.Physician : Roles.Nurse;
                    user.RoleId = staffUser.RoleId;
                    user.IsLocked = false;
                    user.LoginFailedAttempts = 0;
                    int loginCount = this._adminRepo.InsertLoginDetailsStaff(user);
                    if(loginCount > 0)
                    {
                        return Ok();
                    }
                }
                return new BadRequestObjectResult(ModelState);
            }

            return new BadRequestObjectResult(ModelState);
        }

        [HttpPatch]
        [Route("StaffStatus")]
        public IActionResult UpdateStaffStatus(staff staffUser)
        {
            if (ModelState.IsValid)
            {
                var data = _adminRepo.UpdateStaffStatus(staffUser);
                if (data != null)
                    return Ok(data);
                else
                    return new BadRequestObjectResult(ModelState);
            }
            return new BadRequestObjectResult(ModelState);
        }

        [HttpPut]
        public IActionResult UpdateStaff(staff user)
        {
            staff staffToUpdate = _adminRepo.UpdateStaff(user);
            if (staffToUpdate != null)
                return Ok(staffToUpdate);
            else
                return new BadRequestObjectResult(ModelState);
        }

        [HttpGet("GetPieChartData")]
        public IActionResult GetPieChartData()
        {
            try 
            {
                var data = _adminRepo.GetPieChartData();
                return Ok(data);
            }
            catch(Exception ex) { }
            return BadRequest();
        }

        [HttpGet("GetBarChartData")]
        public IActionResult GetBarChartData()
        {
            try
            {
                var data = _adminRepo.GetBarChartData();
                return Ok(data);
            }
            catch (Exception ex) { }
            return BadRequest();
        }
    }
}
