﻿using PMSAdminAPI.Models;
using PMSAPI.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAdminAPI.Services
{
    public interface IAdminRepository
    {
        IEnumerable<Patient> GetAllPatients();
        IEnumerable<staff> GetAllStaff();
        Patient UpdatePatientStatus(Patient patient);
        staff UpdateStaffStatus(staff staffUser);
        int CreateStaffUser(staff staffUser);
        int InsertLoginDetailsStaff(UserLogin user);
        staff UpdateStaff(staff staffUser);
        PieChartData GetPieChartData();
        BarChartData GetBarChartData();
    }

    public class AdminDbRepository : IAdminRepository
    {
        private PMSContext _appcontext;
        public AdminDbRepository(PMSContext appcontext)
        {
            this._appcontext = appcontext;
        }

        public IEnumerable<Patient> GetAllPatients()
        {
            return this._appcontext.Patients.ToList<Patient>();
        }

        public IEnumerable<staff> GetAllStaff()
        {
            return this._appcontext.staff.Where(x => x.RoleId == 2 || x.RoleId == 3).ToList<staff>();
        }

        public Patient UpdatePatientStatus(Patient patient)
        {
            Patient selectedPatient = this._appcontext.Patients.FirstOrDefault(pat => pat.Email == patient.Email);
            if (selectedPatient != null)
            {
                selectedPatient.Status = patient.Status;
                if (patient.Status == Status.Active.ToString())
                    ResetBlockedStatusByEmail(selectedPatient.Email);
                this._appcontext.SaveChanges();
            }

            return selectedPatient;
        }

        public staff UpdateStaffStatus(staff staffUser)
        {
            staff selectedStaff = this._appcontext.staff.FirstOrDefault(sta => sta.Email == staffUser.Email);
            if (selectedStaff != null)
            {
                selectedStaff.Status = staffUser.Status;
                if (staffUser.Status == Status.Active.ToString())
                    ResetBlockedStatusByEmail(selectedStaff.Email);
                this._appcontext.SaveChanges();
            }

            return selectedStaff;
        }

        public staff UpdateStaff(staff staffUser)
        {
            staff staffToUpdate = this._appcontext.staff.FirstOrDefault(u => u.Email == staffUser.Email);
            if (staffToUpdate != null)
            {
                //values to update in the db
                staffToUpdate.FirstName = staffUser.FirstName;
                staffToUpdate.LastName = staffUser.LastName;
                staffToUpdate.ModifiedDate = DateTime.Now;
                staffToUpdate.ModifiedBy = Convert.ToInt32(Roles.Admin);
            }

            staffUser = staffToUpdate;

            this._appcontext.staff.Attach(staffUser);

            this._appcontext.Entry<staff>(staffUser).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

            this._appcontext.SaveChanges();

            //this._appcontext.Update(loggedUser);
            return this._appcontext.staff.FirstOrDefault(u => u.Email == staffUser.Email);
        }

        public int CreateStaffUser(staff staffUser)
        {
            this._appcontext.staff.Add(staffUser);
            return this._appcontext.SaveChanges();
        }

        public int InsertLoginDetailsStaff(UserLogin user)
        {
            this._appcontext.UserLogins.Add(user);
            return this._appcontext.SaveChanges();
        }

        public void ResetBlockedStatusByEmail(string email)
        {
            UserLogin loggedUser = this._appcontext.UserLogins.FirstOrDefault(u => u.Email == email);
            if (loggedUser != null)
            {
                loggedUser.IsLocked = false;
                loggedUser.LoginFailedAttempts = 0;

                this._appcontext.UserLogins.Attach(loggedUser);

                this._appcontext.Entry<UserLogin>(loggedUser).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

                this._appcontext.SaveChanges();
            }
        }

        public PieChartData GetPieChartData() 
        {
            PieChartData data = new PieChartData();
            try 
            {
                List<Visit> visitData = this._appcontext.Visits.ToList();
                data.ConfirmedAppointments = visitData.Count(x => x.VisitStatus.ToLower() == "confirmed");
                data.PendingAppointments = visitData.Count(x => x.VisitStatus.ToLower() == "pending");
                data.RejectedAppointments = visitData.Count(x => x.VisitStatus.ToLower() == "rejected");
            }
            catch(Exception ex) { }
            return data;
        }

        public BarChartData GetBarChartData()
        {
            BarChartData data = new BarChartData();
            try
            {
                List<Patient> patientData = this._appcontext.Patients.ToList();
                data.January = patientData.Count(x => Convert.ToDateTime(x.CreatedDate).ToString("MMM").ToLower() == "jan");
                data.February = patientData.Count(x => Convert.ToDateTime(x.CreatedDate).ToString("MMM").ToLower() == "feb");
                data.March = patientData.Count(x => Convert.ToDateTime(x.CreatedDate).ToString("MMM").ToLower() == "mar");
                data.April = patientData.Count(x => Convert.ToDateTime(x.CreatedDate).ToString("MMM").ToLower() == "apr");
                data.May = patientData.Count(x => Convert.ToDateTime(x.CreatedDate).ToString("MMM").ToLower() == "may");
                data.June = patientData.Count(x => Convert.ToDateTime(x.CreatedDate).ToString("MMM").ToLower() == "jun");
                data.July = patientData.Count(x => Convert.ToDateTime(x.CreatedDate).ToString("MMM").ToLower() == "jul");
                data.August = patientData.Count(x => Convert.ToDateTime(x.CreatedDate).ToString("MMM").ToLower() == "aug");
                data.September = patientData.Count(x => Convert.ToDateTime(x.CreatedDate).ToString("MMM").ToLower() == "sep");
                data.October = patientData.Count(x => Convert.ToDateTime(x.CreatedDate).ToString("MMM").ToLower() == "oct");
                data.November = patientData.Count(x => Convert.ToDateTime(x.CreatedDate).ToString("MMM").ToLower() == "nov");
                data.December = patientData.Count(x => Convert.ToDateTime(x.CreatedDate).ToString("MMM").ToLower() == "dec");
             }
            catch (Exception ex) { }
            return data;
        }
        
    }
}
