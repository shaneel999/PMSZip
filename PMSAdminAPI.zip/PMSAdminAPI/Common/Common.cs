﻿using MailKit.Net.Smtp;
using MimeKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAPI.Common
{
    public class Common
    {
        public static string CreateRandomPassword(int length = 8)
        {
            // Create a string of characters, numbers, special characters that allowed in the password  
            string validChars = "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            Random random = new Random();

            // Select one random character at a time from the string  
            // and create an array of chars  
            char[] chars = new char[length];
            for (int i = 0; i < length; i++)
            {
                chars[i] = validChars[random.Next(0, validChars.Length)];
            }
            return new string(chars);
        }

        public static void SendEmail()
        {
            MimeMessage message = new MimeMessage();

            MailboxAddress from = new MailboxAddress("Admin",
            "shaneel999@gmail.com");
            message.From.Add(from);

            MailboxAddress to = new MailboxAddress("User",
            "shaneel999@gmail.com");
            message.To.Add(to);

            message.Subject = "This is Test Email";


            BodyBuilder bodyBuilder = new BodyBuilder();
            bodyBuilder.HtmlBody = "<h1>Hello World!</h1>";
            bodyBuilder.TextBody = "Hello World!";

            message.Body = bodyBuilder.ToMessageBody();

            SmtpClient client = new SmtpClient();
            client.Connect("smtp.gmail.com", 465, true);
            client.Authenticate("shaneel999@gmail.com", "revathi@1989");

            client.Send(message);
            client.Disconnect(true);
            client.Dispose();
        }
    }

    public enum Roles
    {
        Patient = 1,
        Physician = 2,
        Nurse = 3,
        Admin = 4
    }

    public enum Status
    {
        Active = 1,
        DeActivate = 2,
        Block = 3,
        Activate = 4,
        InActive = 5,
        Blocked = 6
    }
}
