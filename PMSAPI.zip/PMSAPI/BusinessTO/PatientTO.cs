﻿using PMSAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAPI.BusinessTO
{
    public class PatientTO : Patient, IResponseBase
    {
        public string ErrorMessage { get ; set ; }
        public bool ErrorStatus { get ; set ; }
    }
}
