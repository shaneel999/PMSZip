﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAPI.Common
{
    public class Common
    {
        public static int GetIdByRoleName(string role)
        {
            int roleId = 0;
            switch (role)
            {
                case "Patient":
                    roleId = Convert.ToInt32(Roles.Patient);
                    break;
                case "Physician":
                    roleId = Convert.ToInt32(Roles.Physician);
                    break;
                case "Nurse":
                    roleId = Convert.ToInt32(Roles.Nurse);
                    break;
                case "Admin":
                    roleId = Convert.ToInt32(Roles.Admin);
                    break;
                default:
                    break;
            }

            return roleId;
        }

        public static string EncodePasswordToBase64(string password)
        {
            try
            {
                byte[] encData_byte = new byte[password.Length];
                encData_byte = System.Text.Encoding.UTF8.GetBytes(password);
                string encodedData = Convert.ToBase64String(encData_byte);
                return encodedData;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in base64Encode" + ex.Message);
            }
        } //this function Convert to Decord your Password
        public string DecodeFrom64(string encodedData)
        {
            System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
            System.Text.Decoder utf8Decode = encoder.GetDecoder();
            byte[] todecode_byte = Convert.FromBase64String(encodedData);
            int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
            char[] decoded_char = new char[charCount];
            utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
            string result = new String(decoded_char);
            return result;
        }
    }

    public enum Roles
    {
        Patient = 1,
        Physician = 2,
        Nurse = 3,
        Admin = 4
    }

    public enum Status
    {
        Active = 1,
        DeActivate = 2,
        Block = 3,
        Activate = 4,
        InActive = 5,
        Blocked = 6
    }


}
