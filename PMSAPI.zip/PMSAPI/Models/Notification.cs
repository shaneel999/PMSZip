﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAPI.Models
{
    public partial class Notification
    {
        public int NotificationId { get; set; }
        public string Description { get; set; }
        public int? UserId { get; set; }
        public bool? IsSeen { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}
