﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAPI.Models
{
    public partial class Procedure
    {
        public Procedure()
        {
            VisitDetails = new HashSet<VisitDetail>();
        }

        public int ProcedureId { get; set; }
        public string ProcedureCode { get; set; }
        public string ProcedureDescription { get; set; }
        public bool? ProcedureIsDepricated { get; set; }

        public virtual ICollection<VisitDetail> VisitDetails { get; set; }
    }
}
