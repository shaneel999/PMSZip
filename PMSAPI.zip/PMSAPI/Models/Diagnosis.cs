﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAPI.Models
{
    public partial class Diagnosis
    {
        public Diagnosis()
        {
            VisitDetails = new HashSet<VisitDetail>();
        }

        public int DiagnosisId { get; set; }
        public string DiagnosisCode { get; set; }
        public string DiagnosisDescription { get; set; }
        public bool? DiagnosisIsDepricated { get; set; }

        public virtual ICollection<VisitDetail> VisitDetails { get; set; }
    }
}
