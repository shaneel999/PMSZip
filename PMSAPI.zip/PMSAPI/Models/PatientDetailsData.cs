﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAPI.Models
{
    public class PatientDetailsData
    {
        public int PatientId { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public DateTime? Dob { get; set; }
        public string ContactNumber { get; set; }
        public int? Gender { get; set; }
        public int? RaceId { get; set; }
        public int? EthnicityId { get; set; }
        public string LanguagesKnown { get; set; }
        public string HomeAddress { get; set; }

        public int PatientEmergencyId { get; set; }
        public string EmergencyFirstName { get; set; }
        public string EmergencyLastName { get; set; }
        public int? RelationshipId { get; set; }
        public string EmergencyEmail { get; set; }
        public string EmergencyContactNumber { get; set; }
        public string EmergencyPatientAddress { get; set; }
        public bool? AccessToPatientPortal { get; set; }
    }
}
