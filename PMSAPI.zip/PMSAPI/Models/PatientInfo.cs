﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAPI.Models
{
    public class PatientInfo
    {
        public int PatientId { set; get; }
        public int StaffId { set; get; }
        public string Title { set; get; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public DateTime? Dob { get; set; }
        public string ContactNumber { get; set; }
        public string Password { set; get; }
        public string Token { set; get; }
        public string Status { set; get; }
        public string Role { set; get; }
        public string ErrorMessage { set; get; }
        public int? LoginFailedAttempts { set; get; }

    }
}
