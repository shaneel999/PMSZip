﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAPI.Models
{
    public partial class Ethinicity
    {
        public Ethinicity()
        {
            Patients = new HashSet<Patient>();
        }

        public int EthinicityId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<Patient> Patients { get; set; }
    }
}
