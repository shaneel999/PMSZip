﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAPI.Models
{
    public class StaffDashboardData
    {
        public int StaffId { get; set; }
        public string StaffName { get; set; }
        public string StaffAddress { get; set; }
        public string ContactNumber { get; set; }
        public int TotalAppointments { get; set; }
        public int PendingAppointments { get; set; }
        public int ScheduledAppointments { get; set; }
        public int RejectedAppointments { get; set; }
    }
}
