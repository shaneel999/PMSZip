﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAPI.Models
{
    public class PatientDashboardData
    {
        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public string PatientAddress { get; set; }
        public string ContactNumber{ get; set; }
        public int Height { get; set; }
        public int Weight { get; set; }
        public int BloodPressure { get; set; }
        public int TotalVisits { get; set; }
        public string UpcomingAppointment { get; set; }
        public List<string> VisitHistory { get; set; }

    }
}
