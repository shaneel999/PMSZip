﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PMSAPI.Models
{
    public partial class staff
    {
        public staff()
        {
            NoteCreatedByNavigations = new HashSet<Note>();
            NoteNotesClosedByNavigations = new HashSet<Note>();
            NoteReplies = new HashSet<NoteReply>();
            Visits = new HashSet<Visit>();
        }

        public int StaffId { get; set; }
        public string EmployeeId { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public DateTime? Dob { get; set; }
        public string ContactNumber { get; set; }
        public string Status { get; set; }
        public int? RoleId { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public int? CreatedBy { get; set; }
        public int? ModifiedBy { get; set; }
        public bool? IsActive { get; set; }

        public virtual UserRole Role { get; set; }
        public virtual ICollection<Note> NoteCreatedByNavigations { get; set; }
        public virtual ICollection<Note> NoteNotesClosedByNavigations { get; set; }
        public virtual ICollection<NoteReply> NoteReplies { get; set; }
        public virtual ICollection<Visit> Visits { get; set; }
    }
}
