﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PMSAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PMSAPI.Common;
using PMSAPI.Services;

namespace PMSAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private IPatientRepository _repPatient;
        public PatientController(IPatientRepository repository)
        {
            this._repPatient = repository;
        }

        [HttpPut]
        public IActionResult UpdatePassword(UserLogin user)
        {
            UserLogin userLogged  = _repPatient.UpdatePassword(user);
            if (userLogged != null)
                return Ok(userLogged);
            else
                return new BadRequestObjectResult(ModelState);

        }

        [HttpPost]
        //[Authorize]
        public IActionResult Patient([FromBody] PatientInfo patientInfo)
        {
            if(ModelState.IsValid)
            {
                Patient p = new Patient();
                p.Title = patientInfo.Title;
                p.Email = patientInfo.Email;
                p.FirstName = patientInfo.FirstName;
                p.LastName = patientInfo.LastName;
                p.RoleId = Convert.ToInt32(Roles.Patient);
                p.Dob = ((DateTime)patientInfo.Dob).AddDays(+1);
                p.ContactNumber = patientInfo.ContactNumber;
                p.IsActive = true;
                p.CreatedDate = DateTime.Now;
                p.Status = Status.Active.ToString();

                UserLogin user = new UserLogin();
                user.Email = patientInfo.Email;
                user.UserPassword = patientInfo.Password;
                user.IsActive = true;
                user.CreatedDate = DateTime.Now;
                user.RoleId = Convert.ToInt32(Roles.Patient);
                user.LoginFailedAttempts = 0;
                user.IsLocked = false;

                this._repPatient.RegisterPatient(p);
                this._repPatient.InsertLoginDetailsPatient(user);
                return Ok();
            }
            else
            {
                return new BadRequestObjectResult(ModelState);
            }
            
        }
    }
}
