﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using PMSAPI.Models;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

using PMSAPI.Services;
using PMSAPI.Common;

namespace PMSAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private ILoginRepository _logRepo;

        public LoginController(ILoginRepository config)
        {
            _logRepo = config;
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Login([FromBody] PatientInfo login)
        {
            try
            {
                bool credentialsExists = false;
                UserLogin loggedUser = new UserLogin();
                PatientInfo info = new PatientInfo();
                if (login == null)
                {
                    return BadRequest("Invalid client request");
                }
                else
                {
                    UserLogin user = new UserLogin();
                    user.Email = login.Email;
                    user.UserPassword = login.Password;
                    if (login.Role == "Staff")
                    {
                        loggedUser = _logRepo.GetUserByCredentials(user);
                        if (loggedUser != null)
                            user.RoleId = loggedUser.RoleId;
                        else
                            return Ok(info);
                    }
                    else
                    {
                        user.RoleId = Common.Common.GetIdByRoleName(login.Role);
                    }

                    loggedUser = _logRepo.ValidateUsernameAndPassword(user);
                    if (loggedUser != null)
                    {
                        if (loggedUser.Email != null && loggedUser.UserPassword != null)
                        {
                            credentialsExists = true;
                        }
                        else
                        {
                            info.LoginFailedAttempts = loggedUser.LoginFailedAttempts;
                            return Ok(info);
                        }
                    }
                    else
                    {
                        info.ErrorMessage = "Credentials With this Role Not Found!!";
                        return Ok(info);
                    }
                }

                if (credentialsExists)
                {
                    var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("superSecretKey@345"));
                    var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);
                    var tokeOptions = new JwtSecurityToken(
                        issuer: "http://localhost:4200",
                        audience: "http://localhost:4200",
                        claims: new List<Claim>(),
                        expires: DateTime.Now.AddMinutes(5),
                        signingCredentials: signinCredentials
                    );

                    var tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);

                    Patient patient = new Patient();
                    staff staff = new staff();
                    if (login.Role == Roles.Patient.ToString())
                    {
                        patient = _logRepo.GetPatientByEmail(loggedUser.Email);
                        if (patient != null)
                        {
                            info.PatientId = patient.PatientId;
                            info.Title = patient.Title;
                            info.FirstName = patient.FirstName;
                            info.LastName = patient.LastName;
                            info.Email = patient.Email;
                            info.Dob = patient.Dob;
                            info.ContactNumber = patient.ContactNumber;
                            info.Token = tokenString;
                            info.Status = patient.Status;
                            info.Password = loggedUser.UserPassword;
                            info.Role = ((Roles)loggedUser.RoleId).ToString();
                        }
                    }
                    else
                    {
                        staff = _logRepo.GetStaffByEmail(loggedUser.Email);
                        if (staff != null)
                        {
                            info.StaffId = staff.StaffId;
                            info.Title = staff.Title;
                            info.FirstName = staff.FirstName;
                            info.LastName = staff.LastName;
                            info.Email = staff.Email;
                            info.Dob = staff.Dob;
                            info.ContactNumber = staff.ContactNumber;
                            info.Token = tokenString;
                            info.Status = staff.Status;
                            info.Password = loggedUser.UserPassword;
                            info.Role = ((Roles)loggedUser.RoleId).ToString();
                        }
                    }

                    return Ok(info);
                }
                else
                {
                    return new BadRequestObjectResult(ModelState);
                }
            }
            catch(Exception ee)
            {
                throw new Exception("Something Went Wrong", ee);
            }
            finally
            {
               
            }
        }

        [HttpGet]
        public IActionResult GetUser(string email)
        {
            UserLogin user = _logRepo.CheckUserExists(email);
            return Ok(user);
        }
    }

}
