﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using PMSAPI.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PMSAPI.Services;

namespace PMSAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientDetailsController : ControllerBase
    {
        private IPatientDetailsRepository _repPatientVisit;
        public PatientDetailsController(IPatientDetailsRepository repository)
        {
            this._repPatientVisit = repository;
        }
        [HttpGet]
        public IActionResult GetAllPatientVisitDetails()
        {
            var data = _repPatientVisit.GetVitals();
            return Ok(data);
        }

        [HttpGet("GetAllRaceDetails")]
        public IActionResult GetAllRaceDetails()
        {
            var data = _repPatientVisit.RaceDetails();
            return Ok(data);
        }
        [HttpGet("GetAllRelationshipDetails")]
        public IActionResult GetAllRelationshipDetails()
        {
            var data = _repPatientVisit.RelationshipDetails();
            return Ok(data);
        }

        [HttpGet("GetAllEthinicityDetails")]
        public IActionResult GetAllEthinicityDetails()
        {
            var data = _repPatientVisit.EthinicityDetails();
            return Ok(data);
        }

        [HttpGet("GetAllPatientDetails")]
        public IActionResult GetAllPatientDetails()
        {
            var data = _repPatientVisit.GetPatientDetails();
            return Ok(data);
        }


        [HttpGet("GetAllPatientDiagnosis")]
        public IActionResult GetAllPatientDiagnosis()
        {
            var data = _repPatientVisit.GetDiagnosis();
            return Ok(data);
        }

        [HttpGet("GetAllPatientProcedure")]
        public IActionResult GetAllPatientProcedure()
        {
            var data = _repPatientVisit.GetProcedure();
            return Ok(data);
        }
        [HttpGet("GetAllPatientAllergy")]
        public IActionResult GetAllPatientAllergy()
        {
            var data = _repPatientVisit.GetAllergy();
            return Ok(data);
        }
        [HttpPost]
        public IActionResult PatientVisit(VisitDetail visitdetail)
        {
            if (ModelState.IsValid)
            {
                visitdetail.CreatedDate = DateTime.Now;
                this._repPatientVisit.AddPatientVisit(visitdetail);
                return Ok();
            }
            else
            {
                return new BadRequestObjectResult(ModelState);
            }

        }

        [Route("PatientDiagnosis")]
        [HttpPost]
        public IActionResult PatientDiagnosis(Diagnosis diagnosis)
        {
            if (ModelState.IsValid)
            {
                this._repPatientVisit.AddPatientDiagnosis(diagnosis);
                return Ok();
            }
            else
            {
                return new BadRequestObjectResult(ModelState);
            }
        }
        [HttpPost("PatientAllergy")]
        public IActionResult PatientAllergy(Allergy allergy)
        {
            if (ModelState.IsValid)
            {
                this._repPatientVisit.AddPatientAllergy(allergy);
                return Ok();
            }
            else
            {
                return new BadRequestObjectResult(ModelState);
            }
        }

        [HttpPost("PatientEmergencyDetails")]
        public IActionResult PatientEmergencyDetails(PatientEmergencyContact patientemergencycontact)
        {
            if (ModelState.IsValid)
            {
                this._repPatientVisit.AddPatientEmergencyDetails(patientemergencycontact);
                return Ok();
            }
            else
            {
                return new BadRequestObjectResult(ModelState);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult RemoveDiagnosisById([FromRoute] int id)
        {
            if (ModelState.IsValid)
            {
                this._repPatientVisit.DeleteDiagnosis(id);
                return Ok("Diagnosis Deleted");
            }
            else
            {
                return new BadRequestObjectResult(ModelState);
            }
        }
        [HttpDelete("RemoveProcedureById/{id}")]
        public IActionResult RemoveProcedureById([FromRoute] int id)
        {
            if (ModelState.IsValid)
            {
                this._repPatientVisit.DeleteProcedure(id);
                return Ok("Procedure Deleted");
            }
            else
            {
                return new BadRequestObjectResult(ModelState);
            }
        }
        [HttpPost("PatientDetails")]
        public IActionResult PatientDetails(Patient patient)
        {
            if (ModelState.IsValid)
            {
                this._repPatientVisit.AddPatientDetails(patient);
                return Ok();
            }
            else
            {
                return new BadRequestObjectResult(ModelState);
            }
        }
        [HttpPost("PatientProcedure")]
        public IActionResult PatientProcedure(Procedure procedure)
        {
            if (ModelState.IsValid)
            {
                this._repPatientVisit.AddPatientProcedure(procedure);
                return Ok();
            }
            else
            {
                return new BadRequestObjectResult(ModelState);
            }
        }
        [HttpGet("{email}")]
        public IActionResult GetPatientById(string email)
        {
            var data = _repPatientVisit.GetPatientByEmail(email);
            if (data != null)
                return Ok(data);
            else
                return NotFound();
        }

        [HttpGet("GetPatientDashboardDetailsById")]
        public IActionResult GetPatientDashboardDetailsById(int patientId)
        {
            try
            {
                if (patientId > 0)
                {
                    var data = _repPatientVisit.PatientDetailsDataByPatientId(patientId);
                    return Ok(data);
                }
            }
            catch(Exception ex)
            {

            }
         return NotFound();  
        }
    }
}
