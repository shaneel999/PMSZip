﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PMSAPI.Models;
using PMSAPI.Services;

namespace PMSAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DashboardController : ControllerBase
    {
        private IDashboardRepository _repDashboard;
        public DashboardController(IDashboardRepository repository)
        {
            this._repDashboard = repository;
        }

        [HttpGet("GetPatientDashboardDetails")]
        public IActionResult GetPatientDetails(int patientId)
        {
            try
            {
                var data = this._repDashboard.GetPatientDashboardData(patientId);
                return Ok(data);
            }
            catch (Exception ex)
            { }
            return BadRequest();
        }

        [HttpGet("GetNurseDashboardDetails")]
        public IActionResult GetStaffDashboardData(int nurseId)
        {
            try
            {
                var data = this._repDashboard.GetNurseDashboardData(nurseId);
                return Ok(data);
            }
            catch (Exception ex)
            { }
            return BadRequest();
        }


        [HttpGet("GetPhysicianDashboardDetails")]
        public IActionResult GetPhysicianDashboardData(int physicianId)
        {
            try
            {
                var data = this._repDashboard.GetPhysicianDashboardData(physicianId);
                return Ok(data);
            }
            catch (Exception ex)
            { }
            return BadRequest();
        }
    }
}
