﻿using PMSAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAPI.Services
{
    public interface IPatientDetailsRepository
    {
        IEnumerable<VisitDetail> GetVitals();
        IEnumerable<Diagnosis> GetDiagnosis();
        IEnumerable<Procedure> GetProcedure();
        IEnumerable<Allergy> GetAllergy();
        IEnumerable<Patient> GetPatientDetails();
        IEnumerable<Relationship> RelationshipDetails();
        IEnumerable<Ethinicity> EthinicityDetails();
        IEnumerable<Race> RaceDetails();

        Patient GetPatientByEmail(string email);
        void DeleteDiagnosis(int id);
        void DeleteProcedure(int id);
        void AddPatientVisit(VisitDetail visitdetail);
        void AddPatientEmergencyDetails(PatientEmergencyContact patientemergencycontact);
        void AddPatientDiagnosis(Diagnosis diagnosis);
        void AddPatientAllergy(Allergy allergy);
        void AddPatientProcedure(Procedure procedure);
        void AddPatientDetails(Patient patient);
        PatientDetailsData PatientDetailsDataByPatientId(int patientId);
    }
    public class PatientVisitDbRepsitory : IPatientDetailsRepository
    {
        private PMSContext _appcontext;

        public PatientVisitDbRepsitory(PMSContext appcontext)
        {
            this._appcontext = appcontext;
        }

        public void AddPatientAllergy(Allergy allergy)
        {
            this._appcontext.Allergies.Add(allergy);
            this._appcontext.SaveChanges();
        }

        public void AddPatientDetails(Patient patient)
        {
            try 
            {
                var PatientData = this._appcontext.Patients.Find(patient.PatientId);
                if (PatientData != null)
                {
                  PatientData.Title = patient.Title;
                  //PatientData.FirstName = patient.FirstName;
                  //PatientData.LastName = patient.LastName;
                  //PatientData.Email = patient.Email;
                  //PatientData.Dob = patient.Dob;
                  //PatientData.ContactNumber = patient.ContactNumber;
                  PatientData.Gender = patient.Gender;
                  PatientData.RaceId = patient.RaceId;
                  PatientData.EthnicityId = patient.EthnicityId;
                  PatientData.LanguagesKnown = patient.LanguagesKnown;
                  PatientData.HomeAddress = patient.HomeAddress;
                  this._appcontext.SaveChanges();
                }
            }
            catch(Exception ex) { }
        }

        public void AddPatientDiagnosis(Diagnosis diagnosis)
        {
            this._appcontext.Diagnoses.Add(diagnosis);
            this._appcontext.SaveChanges();
        }

        public void AddPatientEmergencyDetails(PatientEmergencyContact patientemergencycontact)
        {
            this._appcontext.PatientEmergencyContacts.Add(patientemergencycontact);
            this._appcontext.SaveChanges();
        }

        public void AddPatientProcedure(Procedure procedure)
        {
            this._appcontext.Procedures.Add(procedure);
            this._appcontext.SaveChanges();
        }

        public void AddPatientVisit(VisitDetail visitdetail)
        {
            this._appcontext.VisitDetails.Add(visitdetail);
            this._appcontext.SaveChanges();
        }

        public void DeleteDiagnosis(int id)
        {
            Diagnosis d= this._appcontext.Diagnoses.FirstOrDefault(d => d.DiagnosisId == id);
            if (d != null)
            {
                this._appcontext.Diagnoses.Remove(d);
                this._appcontext.SaveChanges();
            }
        }

        public void DeleteProcedure(int id)
        {
            Procedure p = this._appcontext.Procedures.FirstOrDefault(p => p.ProcedureId == id);
            if (p != null)
            {
                this._appcontext.Procedures.Remove(p);
                this._appcontext.SaveChanges();
            }
        }

        public IEnumerable<VisitDetail> GetVitals()
        {
            return this._appcontext.VisitDetails.ToList<VisitDetail>();
        }

        public IEnumerable<Allergy> GetAllergy()
        {
            return this._appcontext.Allergies.ToList<Allergy>();
        }

        public IEnumerable<Diagnosis> GetDiagnosis()
        {
            return this._appcontext.Diagnoses.ToList<Diagnosis>();
        }

        public IEnumerable<Procedure> GetProcedure()
        {
            return this._appcontext.Procedures.ToList<Procedure>();
        }

        public Patient GetPatientByEmail(string email)
        {
            return this._appcontext.Patients.FirstOrDefault(d => d.Email == email);
        }

        public IEnumerable<Patient> GetPatientDetails()
        {
            return this._appcontext.Patients.ToList<Patient>();
        }

        public IEnumerable<Race> RaceDetails()
        {
            return this._appcontext.Races.ToList<Race>();
        }

        public IEnumerable<Ethinicity> EthinicityDetails()
        {
            return this._appcontext.Ethinicities.ToList<Ethinicity>();
        }

        public IEnumerable<Relationship> RelationshipDetails()
        {
            return this._appcontext.Relationships.ToList<Relationship>();
        }

        public PatientDetailsData PatientDetailsDataByPatientId(int patientId)
        {
            PatientDetailsData patientDetails = new PatientDetailsData();
            try
            {
                Patient patientData = this._appcontext.Patients.Find(patientId);
                if(patientData!=null)
                {
                    patientDetails.Title = Convert.ToString(patientData.Title);
                    patientDetails.FirstName = Convert.ToString(patientData.FirstName);
                    patientDetails.LastName = Convert.ToString(patientData.LastName);
                    patientDetails.Email = Convert.ToString(patientData.Email);
                    patientDetails.Dob = patientData.Dob;
                    patientDetails.ContactNumber = Convert.ToString(patientData.ContactNumber);
                    patientDetails.Gender = Convert.ToInt32(patientData.Gender);
                    patientDetails.RaceId = Convert.ToInt32(patientData.RaceId);
                    patientDetails.EthnicityId = Convert.ToInt32(patientData.EthnicityId);
                    patientDetails.LanguagesKnown = Convert.ToString(patientData.LanguagesKnown);
                    patientDetails.HomeAddress = Convert.ToString(patientData.HomeAddress);
                }

                PatientEmergencyContact patientEmergencyData = this._appcontext.PatientEmergencyContacts.Where(x=>x.PatientId == patientId).FirstOrDefault();
                if (patientEmergencyData != null)
                {
                    patientDetails.EmergencyFirstName = Convert.ToString(patientEmergencyData.FirstName);
                    patientDetails.EmergencyLastName = Convert.ToString(patientEmergencyData.LastName);
                    patientDetails.RelationshipId = Convert.ToInt32(patientEmergencyData.RelationshipId);
                    patientDetails.EmergencyEmail = Convert.ToString(patientEmergencyData.Email);
                    patientDetails.EmergencyContactNumber = Convert.ToString(patientEmergencyData.ContactNumber);
                    patientDetails.EmergencyPatientAddress = Convert.ToString(patientEmergencyData.PatientAddress);
                    patientDetails.AccessToPatientPortal = Convert.ToBoolean(patientEmergencyData.AccessToPatientPortal);
                }

            }
            catch(Exception ex)
            {

            }

            return patientDetails;
        }

    }
}
