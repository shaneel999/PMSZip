﻿using PMSAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAPI.Services
{
    public interface IPatientDetailsRepository
    {
        IEnumerable<VisitDetail> GetVitals();
        IEnumerable<Diagnosis> GetDiagnosis();
        IEnumerable<Procedure> GetProcedure();
        IEnumerable<Allergy> GetAllergy();
        IEnumerable<Patient> GetPatientDetails();
        IEnumerable<Relationship> RelationshipDetails();
        IEnumerable<Ethinicity> EthinicityDetails();
        IEnumerable<Race> RaceDetails();

        Patient GetPatientByEmail(string email);
        void DeleteDiagnosis(int id);
        void DeleteProcedure(int id);
        void AddPatientVisit(VisitDetail visitdetail);
        void AddPatientEmergencyDetails(PatientEmergencyContact patientemergencycontact);
        void AddPatientDiagnosis(Diagnosis diagnosis);
        void AddPatientAllergy(Allergy allergy);
        void AddPatientProcedure(Procedure procedure);
        void AddPatientDetails(Patient patient);
    }
    public class PatientVisitDbRepsitory : IPatientDetailsRepository
    {
        private PMSContext _appcontext;

        public PatientVisitDbRepsitory(PMSContext appcontext)
        {
            this._appcontext = appcontext;
        }

        public void AddPatientAllergy(Allergy allergy)
        {
            this._appcontext.Allergies.Add(allergy);
            this._appcontext.SaveChanges();
        }

        public void AddPatientDetails(Patient patient)
        {
            
                this._appcontext.Patients.Add(patient);
                this._appcontext.SaveChanges();
            
        }

        public void AddPatientDiagnosis(Diagnosis diagnosis)
        {
            this._appcontext.Diagnoses.Add(diagnosis);
            this._appcontext.SaveChanges();
        }

        public void AddPatientEmergencyDetails(PatientEmergencyContact patientemergencycontact)
        {
            this._appcontext.PatientEmergencyContacts.Add(patientemergencycontact);
            this._appcontext.SaveChanges();
        }

        public void AddPatientProcedure(Procedure procedure)
        {
            this._appcontext.Procedures.Add(procedure);
            this._appcontext.SaveChanges();
        }

        public void AddPatientVisit(VisitDetail visitdetail)
        {
            this._appcontext.VisitDetails.Add(visitdetail);
            this._appcontext.SaveChanges();
        }

        public void DeleteDiagnosis(int id)
        {
            Diagnosis d= this._appcontext.Diagnoses.FirstOrDefault(d => d.DiagnosisId == id);
            if (d != null)
            {
                this._appcontext.Diagnoses.Remove(d);
                this._appcontext.SaveChanges();
            }
        }

        public void DeleteProcedure(int id)
        {
            Procedure p = this._appcontext.Procedures.FirstOrDefault(p => p.ProcedureId == id);
            if (p != null)
            {
                this._appcontext.Procedures.Remove(p);
                this._appcontext.SaveChanges();
            }
        }

        public IEnumerable<VisitDetail> GetVitals()
        {
            return this._appcontext.VisitDetails.ToList<VisitDetail>();
        }

        public IEnumerable<Allergy> GetAllergy()
        {
            return this._appcontext.Allergies.ToList<Allergy>();
        }

        public IEnumerable<Diagnosis> GetDiagnosis()
        {
            return this._appcontext.Diagnoses.ToList<Diagnosis>();
        }

        public IEnumerable<Procedure> GetProcedure()
        {
            return this._appcontext.Procedures.ToList<Procedure>();
        }

        public Patient GetPatientByEmail(string email)
        {
            return this._appcontext.Patients.FirstOrDefault(d => d.Email == email);
        }

        public IEnumerable<Patient> GetPatientDetails()
        {
            return this._appcontext.Patients.ToList<Patient>();
        }

        public IEnumerable<Race> RaceDetails()
        {
            return this._appcontext.Races.ToList<Race>();
        }

        public IEnumerable<Ethinicity> EthinicityDetails()
        {
            return this._appcontext.Ethinicities.ToList<Ethinicity>();
        }

        public IEnumerable<Relationship> RelationshipDetails()
        {
            return this._appcontext.Relationships.ToList<Relationship>();
        }

    }
}
