﻿using PMSAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAPI.Services
{
    public interface IPatientRepository
    {
        

        void RegisterPatient(Patient patient);

        void InsertLoginDetailsPatient(UserLogin user);

        UserLogin UpdatePassword(UserLogin user);
    }

    public class PatientDbRepository : IPatientRepository
    {
        private PMSContext _appcontext;

        public PatientDbRepository(PMSContext appcontext)
        {
            this._appcontext = appcontext;
        }

        public void RegisterPatient(Patient patient)
        {
            this._appcontext.Patients.Add(patient);
            this._appcontext.SaveChanges();
        }

        public void InsertLoginDetailsPatient(UserLogin user)
        {
            this._appcontext.UserLogins.Add(user);
            this._appcontext.SaveChanges();
        }

        public UserLogin UpdatePassword(UserLogin user)
        {
            UserLogin loggedUser =  this._appcontext.UserLogins.FirstOrDefault(u => u.Email == user.Email);
            if(loggedUser != null)
            {
                loggedUser.UserPassword = user.UserPassword;
            }

            user = loggedUser;

            this._appcontext.UserLogins.Attach(user);

            this._appcontext.Entry<UserLogin>(user).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

            this._appcontext.SaveChanges();

            //this._appcontext.Update(loggedUser);
            return this._appcontext.UserLogins.FirstOrDefault(u => u.Email == user.Email);
        }
    }
}
