﻿using PMSAPI.Common;
using PMSAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMSAPI.Services
{
    public interface ILoginRepository
    {
        UserLogin ValidateUsernameAndPassword(UserLogin user);
        UserLogin GetUserByCredentials(UserLogin user);
        Patient GetPatientByEmail(string email);
        staff GetStaffByEmail(string email);
        UserLogin CheckUserExists(string email);
    }

    public class LoginDbRepository : ILoginRepository
    {
        private PMSContext _appcontext;
        public LoginDbRepository(PMSContext appcontext)
        {
            this._appcontext = appcontext;
        }

        public Patient GetPatientByEmail(string email)
        {

            return this._appcontext.Patients.FirstOrDefault(pa => pa.Email == email);

        }

        public staff GetStaffByEmail(string email)
        {

            return this._appcontext.staff.FirstOrDefault(sta => sta.Email == email);

        }

        public UserLogin ValidateUsernameAndPassword(UserLogin userLogin)
        {
            UserLogin user = this._appcontext.UserLogins.FirstOrDefault(u => u.Email == userLogin.Email &&
          u.UserPassword == userLogin.UserPassword && u.RoleId == userLogin.RoleId);
            if (user != null && (user.UserPassword.Contains(userLogin.UserPassword)))
            {
                this.ResetLoginFailedAttempts(userLogin.Email);
                return user;
            }
            else
            {
                user = this.UpdateLoginFailedAttempts(userLogin.Email);
                user.UserPassword = null;//password is wrong
                return user;
            }
        }

        public UserLogin GetUserByCredentials(UserLogin userLogin)
        {

            return this._appcontext.UserLogins.FirstOrDefault(u => u.Email == userLogin.Email &&
        u.UserPassword == userLogin.UserPassword);

        }

        public UserLogin CheckUserExists(string email)
        {

            return this._appcontext.UserLogins.FirstOrDefault(pa => pa.Email == email);

        }

        public UserLogin UpdateLoginFailedAttempts(string email)
        {
            UserLogin loggedUser = this._appcontext.UserLogins.FirstOrDefault(u => u.Email == email);
            if (loggedUser != null)
            {
                if (loggedUser.IsLocked == false)
                {
                    if (loggedUser.LoginFailedAttempts == 0 && loggedUser.LoginFailedDate != DateTime.Now.Date)
                    {
                        loggedUser.LoginFailedDate = DateTime.Now;
                        loggedUser.LoginFailedAttempts = loggedUser.LoginFailedAttempts + 1;
                    }
                    else
                    {
                        loggedUser.LoginFailedAttempts = loggedUser.LoginFailedAttempts + 1;
                        if (loggedUser.LoginFailedAttempts > 2)
                        {
                            loggedUser.IsLocked = true;
                            SetBlockedStatusByEmail(email);
                        }
                    }
                    this._appcontext.UserLogins.Attach(loggedUser);

                    this._appcontext.Entry<UserLogin>(loggedUser).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

                    this._appcontext.SaveChanges();

                    //this._appcontext.Update(loggedUser);
                    return this._appcontext.UserLogins.FirstOrDefault(u => u.Email == email);
                }
                else
                {
                    return loggedUser;
                }



            }
            else
            {
                return loggedUser;
            }

        }

        public void ResetLoginFailedAttempts(string email)
        {
            UserLogin loggedUser = this._appcontext.UserLogins.FirstOrDefault(u => u.Email == email);
            if (loggedUser != null)
            {
                loggedUser.IsLocked = false;
                loggedUser.LoginFailedAttempts = 0;
                loggedUser.LoginFailedDate = null;

                this._appcontext.UserLogins.Attach(loggedUser);

                this._appcontext.Entry<UserLogin>(loggedUser).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

                this._appcontext.SaveChanges();
            }
        }

        public void SetBlockedStatusByEmail(string email)
        {
            UserLogin loggedUser = this._appcontext.UserLogins.FirstOrDefault(u => u.Email == email);
            if (loggedUser != null)
            {
                if(loggedUser.RoleId == Convert.ToInt32(Roles.Patient))
                {
                    Patient pat = this._appcontext.Patients.FirstOrDefault(u => u.Email == email);
                    pat.Status = Status.Blocked.ToString();

                    this._appcontext.Patients.Attach(pat);

                    this._appcontext.Entry<Patient>(pat).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

                    this._appcontext.SaveChanges();
                }
                else
                {
                    staff staff = this._appcontext.staff.FirstOrDefault(u => u.Email == email);
                    staff.Status = Status.Blocked.ToString();

                    this._appcontext.staff.Attach(staff);

                    this._appcontext.Entry<staff>(staff).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

                    this._appcontext.SaveChanges();
                }

               
            }
        }
    }
}

