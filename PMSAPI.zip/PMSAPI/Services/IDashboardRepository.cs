﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using PMSAPI.Models;

namespace PMSAPI.Services
{
    public interface IDashboardRepository
    {
        PatientDashboardData GetPatientDashboardData(int patientId);
        StaffDashboardData GetNurseDashboardData(int staffId);
        StaffDashboardData GetPhysicianDashboardData(int physicianId);
    }

    public class DashboardDbRepository : IDashboardRepository
    {
        private PMSContext _appcontext;
        public DashboardDbRepository(PMSContext appcontext)
        {
            this._appcontext = appcontext;
        }

        public PatientDashboardData GetPatientDashboardData(int patientId)
        {
            PatientDashboardData patientDashboardData = new PatientDashboardData();
            VisitDetail visitDetailsData = new VisitDetail();
            Patient patientData = this._appcontext.Patients.Where(x => x.PatientId == patientId).FirstOrDefault();
            PatientEmergencyContact patientEmergencyContactData = this._appcontext.PatientEmergencyContacts.Where(x => x.PatientId == patientId).FirstOrDefault();
            if (patientData != null)
            {
                patientDashboardData.PatientId = patientData.PatientId;
                patientDashboardData.PatientName = patientData.FirstName + " " + patientData.LastName;
                patientDashboardData.PatientAddress = patientData.HomeAddress;
                patientDashboardData.ContactNumber = patientData.ContactNumber;
            }
            if(patientEmergencyContactData != null)
            {
                patientDashboardData.patientEmergencyContactName = patientEmergencyContactData.FirstName + " " + patientEmergencyContactData.LastName;
                patientDashboardData.relationName = this._appcontext.Relationships.Where(x => x.RelationshipId == patientEmergencyContactData.RelationshipId).Select(n => n.RelationshipName).FirstOrDefault() == "" ? "" : this._appcontext.Relationships.Where(x => x.RelationshipId == patientEmergencyContactData.RelationshipId).Select(n => n.RelationshipName).FirstOrDefault();
                patientDashboardData.patientEmergencyContactAddress = patientEmergencyContactData.PatientAddress;
                patientDashboardData.patientEmergencyContactNumber = patientEmergencyContactData.ContactNumber;
            }
            List<Visit> visitData = this._appcontext.Visits.Where(x => x.PatientId == patientId).ToList();
            if(visitData.Count > 0)
            {
                int visitId = visitData.Max(x => x.VisitId);
                visitDetailsData = this._appcontext.VisitDetails.Where(x => x.VisitId == visitId).FirstOrDefault();

                patientDashboardData.Height = visitDetailsData == null ? 0 : visitDetailsData.Height ?? 0;
                patientDashboardData.Weight = visitDetailsData == null ? 0 : visitDetailsData.Weight ?? 0;
                patientDashboardData.BloodPressure = visitDetailsData == null ? 0 : visitDetailsData.BloodPressure ?? 0; ;
                patientDashboardData.TotalVisits = visitDetailsData == null ? 0 : visitData.Count(x => x.PatientId == patientId);
                patientDashboardData.UpcomingAppointment = visitData.Where(x => x.VisitDate >= DateTime.Today).Select(x=> x.VisitDate.ToString()).Take(1).FirstOrDefault();
                patientDashboardData.VisitHistory = visitData.Where(x=>x.VisitDate <= DateTime.Today).OrderByDescending(x => x.VisitDate.ToString()).Select(x => x.VisitDate.ToString()).Take(4).ToList();
            }
            
            return patientDashboardData;
        }

        public StaffDashboardData GetNurseDashboardData(int staffId)
        {
            StaffDashboardData staffDashboardData = new StaffDashboardData();
            staff staffData = this._appcontext.staff.Where(x => x.StaffId == staffId).FirstOrDefault();
            //List<Visit> visitData = this._appcontext.Visits.Where(x => x.VisitDate == DateTime.Today).ToList();

            List<Visit> visitData = this._appcontext.Visits.ToList();

            staffDashboardData.StaffId = staffData.StaffId;
            staffDashboardData.StaffName = staffData.FirstName + " " + staffData.LastName;
            staffDashboardData.StaffAddress = "";
            staffDashboardData.ContactNumber = staffData.ContactNumber;
            staffDashboardData.TotalAppointments = visitData.Count();
            staffDashboardData.PendingAppointments = visitData.Count(x=>x.VisitStatus.ToLower() == "pending");
            staffDashboardData.RejectedAppointments = visitData.Count(x => x.VisitStatus.ToLower() == "rejected");
            staffDashboardData.ScheduledAppointments = visitData.Count(x => x.VisitStatus.ToLower() == "confirmed");
            return staffDashboardData;
        }

        public StaffDashboardData GetPhysicianDashboardData(int physicianId)
        {
            StaffDashboardData staffDashboardData = new StaffDashboardData();
            staff staffData = this._appcontext.staff.Where(x => x.StaffId == physicianId).FirstOrDefault();
            List<Visit> visitData = this._appcontext.Visits.Where(x =>x.StaffId == physicianId).ToList();

            staffDashboardData.StaffId = staffData.StaffId;
            staffDashboardData.StaffName = staffData.FirstName + " " + staffData.LastName;
            staffDashboardData.ContactNumber = staffData.ContactNumber;
            staffDashboardData.TotalAppointments = visitData.Count();
            staffDashboardData.PendingAppointments = visitData.Count(x => x.VisitStatus.ToLower() == "pending");
            staffDashboardData.RejectedAppointments = visitData.Count(x => x.VisitStatus.ToLower() == "rejected");
            staffDashboardData.ScheduledAppointments = visitData.Count(x => x.VisitStatus.ToLower() == "confirmed");
            return staffDashboardData;
        }
    }
}
